# Figure 7RV_s4: agreement between FIE estimates and XGB predictions

required_packages <- c("ggplot2", "ggpmisc", "svglite", "ragg")
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
]
if (length(missing_packages) > 0L) {
  stop(
    paste("Install required package(s):", paste(missing_packages, collapse = ", ")),
    call. = FALSE
  )
}

suppressPackageStartupMessages({
  library(ggplot2)
  library(ggpmisc)
})

required_objects <- c("XGB_OP", "XGB_OP_f")
missing_objects <- required_objects[
  !vapply(required_objects, exists, logical(1), inherits = TRUE)
]
if (length(missing_objects) > 0L) {
  stop(
    paste("Missing required object(s):", paste(missing_objects, collapse = ", ")),
    call. = FALSE
  )
}

required_columns <- function(data, columns, object_name) {
  missing_columns <- setdiff(columns, names(data))
  if (length(missing_columns) > 0L) {
    stop(
      paste(object_name, "is missing:", paste(missing_columns, collapse = ", ")),
      call. = FALSE
    )
  }
}
required_columns(XGB_OP, c("fxm_est", "xgb_Pre", "level", "var_hdw"), "XGB_OP")
required_columns(XGB_OP_f, c("fxm_est", "xgb_Pre", "level", "var_hdw"), "XGB_OP_f")

# Preserve the original combination rule.
XGB_OP_df <- rbind(XGB_OP, XGB_OP_f)
if (nrow(XGB_OP_df) < 3L) {
  stop("XGB_OP_df must contain at least three rows.", call. = FALSE)
}

# Linear fits require finite paired values. Record rather than silently drop them.
finite_pair <- is.finite(XGB_OP_df$fxm_est) & is.finite(XGB_OP_df$xgb_Pre)
XGB_OP_plot <- XGB_OP_df[finite_pair, , drop = FALSE]
filter_manifest <- data.frame(
  source_rows = nrow(XGB_OP_df),
  plotted_rows = nrow(XGB_OP_plot),
  excluded_rows = sum(!finite_pair),
  rule = "Retain finite fxm_est/xgb_Pre pairs",
  stringsAsFactors = FALSE
)
if (nrow(XGB_OP_plot) < 3L) {
  stop("Fewer than three finite paired observations remain.", call. = FALSE)
}

level_values <- unique(as.character(XGB_OP_plot$level))
if (length(level_values) > 2L) {
  stop(
    "The supplied two-colour scale supports at most two level values.",
    call. = FALSE
  )
}
level_colours <- setNames(c("#1f77b4", "#1a57b0")[seq_along(level_values)], level_values)

# Publication font: Arial-compatible Helvetica/sans-serif fallback.
figure_font_family <- "sans"

Figure_7RV_s4_gg <- ggplot(
  XGB_OP_plot,
  aes(x = fxm_est, y = xgb_Pre, colour = level)
) +
  geom_point(alpha = 0.30, size = 1.0) +
  geom_abline(
    intercept = 0,
    slope = 1,
    colour = "black",
    linetype = "dashed",
    linewidth = 0.65
  ) +
  # Draw the panel-specific fitted line only once.
  geom_smooth(
    aes(group = 1),
    method = "lm",
    formula = y ~ x,
    se = FALSE,
    colour = "red3",
    linewidth = 0.75
  ) +
  stat_poly_eq(
    aes(
      group = 1,
      label = paste(
        after_stat(eq.label),
        after_stat(rr.label),
        sep = "~~~"
      )
    ),
    formula = y ~ x,
    parse = TRUE,
    label.x = "right",
    label.y = "top",
    hjust = 1,
    vjust = 1,
    size = 3.0,
    colour = "black"
  ) +
  facet_wrap(level ~ var_hdw, scales = "free") +
  scale_colour_manual(values = level_colours, name = NULL) +
  labs(
    # Plain Unicode units remain correctly spaced after SVG import into Word.
    x = "FIE estimation\u00A0(kg ha\u207B\u00B9 hour\u207B\u00B9)",
    y = "XGB prediction\u00A0(kg ha\u207B\u00B9 hour\u207B\u00B9)"
  ) +
  theme_bw(base_family = figure_font_family, base_size = 9) +
  theme(
    strip.text = element_text(size = 9, colour = "black"),
    text = element_text(size = 9, colour = "black"),
    axis.text.x = element_text(size = 9, angle = 0, vjust = 0.5),
    axis.text.y = element_text(size = 9),
    axis.title = element_text(size = 10),
    legend.position = "none",
    panel.spacing = grid::unit(0.20, "cm"),
    strip.background = element_rect(colour = "transparent"),
    plot.background = element_rect(fill = "transparent", colour = NA),
    plot.margin = margin(4, 5, 4, 4, unit = "mm")
  )

skip_figure_export <- identical(Sys.getenv("HDW_SKIP_EXPORT"), "1")
if (!skip_figure_export) {
  output_dir <- Sys.getenv(
    "HDW_FIGURE_OUTPUT_DIR",
    unset = "D:/Crop yield loss at DHW/Figures/Figures_prof"
  )
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  source_data_dir <- file.path(output_dir, "Source data")
  dir.create(source_data_dir, recursive = TRUE, showWarnings = FALSE)

  save(
    XGB_OP,
    XGB_OP_f,
    XGB_OP_df,
    XGB_OP_plot,
    filter_manifest,
    file = file.path(source_data_dir, "Figure 7RV_s4_source_data.RData"),
    version = 2
  )

  # Keep the uploaded figure number and filename unchanged.
  output_prefix <- file.path(output_dir, "Figure 7RV_s4")
  fig_width_cm <- 24
  fig_height_cm <- 18
  fig_width_in <- fig_width_cm / 2.54
  fig_height_in <- fig_height_cm / 2.54

  svglite::svglite(
    paste0(output_prefix, ".svg"),
    width = fig_width_in,
    height = fig_height_in,
    bg = "transparent"
  )
  print(Figure_7RV_s4_gg)
  dev.off()

  grDevices::cairo_pdf(
    paste0(output_prefix, ".pdf"),
    width = fig_width_in,
    height = fig_height_in,
    family = figure_font_family,
    bg = "transparent",
    fallback_resolution = 600
  )
  print(Figure_7RV_s4_gg)
  dev.off()

  ragg::agg_tiff(
    paste0(output_prefix, ".tiff"),
    width = fig_width_cm,
    height = fig_height_cm,
    units = "cm",
    res = 600,
    compression = "lzw",
    background = "white"
  )
  print(Figure_7RV_s4_gg)
  dev.off()

  word_dpi <- 450
  ragg::agg_png(
    paste0(output_prefix, "_word_", word_dpi, "dpi.png"),
    width = fig_width_cm,
    height = fig_height_cm,
    units = "cm",
    res = word_dpi,
    background = "white"
  )
  print(Figure_7RV_s4_gg)
  dev.off()

  if (requireNamespace("devEMF", quietly = TRUE)) {
    devEMF::emf(
      paste0(output_prefix, ".emf"),
      width = fig_width_in,
      height = fig_height_in,
      family = figure_font_family,
      pointsize = 11,
      coordDPI = 600,
      emfPlus = TRUE
    )
    print(Figure_7RV_s4_gg)
    dev.off()
  }
}
