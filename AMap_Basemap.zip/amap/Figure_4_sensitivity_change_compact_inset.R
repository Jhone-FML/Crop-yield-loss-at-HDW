# Figure 5: temporal changes in yield sensitivity and their spatial patterns

required_packages <- c(
  "ggplot2", "ggdist", "cowplot", "sf", "RColorBrewer",
  "scales", "svglite", "ragg"
)
missing_packages <- required_packages[!vapply(
  required_packages,
  requireNamespace,
  logical(1),
  quietly = TRUE
)]

if (length(missing_packages) > 0) {
  stop(
    paste0(
      "Install the required R package(s) first: ",
      paste(missing_packages, collapse = ", "),
      ".\nRun: install.packages(c(",
      paste(sprintf('"%s"', missing_packages), collapse = ", "),
      "))"
    ),
    call. = FALSE
  )
}

suppressPackageStartupMessages({
  library(ggplot2)
  library(cowplot)
  library(sf)
})

# -----------------------------------------------------------------------------
# Input checks
# -----------------------------------------------------------------------------

required_objects <- c(
  "summarized_df_filtered",
  "sum_Pro_sen_stats_jion_sf"
)
missing_objects <- required_objects[!vapply(
  required_objects,
  exists,
  logical(1),
  inherits = TRUE
)]

if (length(missing_objects) > 0) {
  stop(
    paste(
      "Missing required object(s):",
      paste(missing_objects, collapse = ", ")
    ),
    call. = FALSE
  )
}

required_columns <- function(data, columns, object_name) {
  missing_columns <- setdiff(columns, names(data))
  if (length(missing_columns) > 0) {
    stop(
      paste(
        object_name, "is missing:",
        paste(missing_columns, collapse = ", ")
      ),
      call. = FALSE
    )
  }
}

required_columns(
  summarized_df_filtered,
  c("varbs", "Y_levle", "value", "Model"),
  "summarized_df_filtered"
)
required_columns(
  sum_Pro_sen_stats_jion_sf,
  c("mean_value.y", "Type"),
  "sum_Pro_sen_stats_jion_sf"
)

if (!inherits(sum_Pro_sen_stats_jion_sf, "sf")) {
  stop("sum_Pro_sen_stats_jion_sf must be an sf object.", call. = FALSE)
}

# Retain the exact filtering rule from the supplied code.
county_sensitivity_data <- summarized_df_filtered[
  summarized_df_filtered$varbs != "DTWD" &
    summarized_df_filtered$Y_levle == "County",
  ,
  drop = FALSE
]

if (nrow(county_sensitivity_data) == 0) {
  stop("No county-level non-DTWD observations remain after filtering.", call. = FALSE)
}

# -----------------------------------------------------------------------------
# Shared typography
# -----------------------------------------------------------------------------

figure_font_family <- "Arial"
font_panel_label <- 9
font_strip <- 7.5
font_axis_text <- 7
font_axis_title <- 8
font_legend <- 6.5

# Display PRWD as PRGW without modifying either source object.
display_prgw <- function(x) {
  gsub("PRWD", "PRGW", as.character(x), fixed = TRUE)
}

# -----------------------------------------------------------------------------
# Panel (a): county-level sensitivity-change distributions
# -----------------------------------------------------------------------------

county_sens_change_sum_gg <- ggplot(
  county_sensitivity_data,
  aes(x = varbs, y = value)
) +
  ggdist::stat_halfeye(
    aes(fill = varbs),
    adjust = 0.6,
    width = 0.8,
    .width = 0,
    alpha = 0.6,
    position = position_dodge(width = 1),
    justification = -0.2,
    point_colour = NA
  ) +
  ggdist::stat_pointinterval(
    aes(colour = varbs),
    justification = 0.2,
    size = 0.65,
    position = position_dodge(width = 1),
    alpha = 0.6
  ) +
  stat_summary(
    aes(
      label = after_stat(round(y, 1)),
      colour = varbs
    ),
    fun = median,
    geom = "label",
    size = 2.35,
    position = position_dodge(width = 0.8),
    hjust = 1.15,
    vjust = -0.9,
    linewidth = 0.15,
    fill = "white",
    label.r = grid::unit(0.15, "lines")
  ) +
  geom_hline(
    yintercept = 0,
    linewidth = 0.45,
    linetype = "dashed",
    colour = "black"
  ) +
  scale_colour_manual(
    name = NULL,
    values = RColorBrewer::brewer.pal(8, "Set2")
  ) +
  scale_fill_manual(
    name = NULL,
    values = RColorBrewer::brewer.pal(8, "Set2")
  ) +
  scale_x_discrete(
    labels = function(x) display_prgw(x)
  ) +
  facet_wrap(~Model, ncol = 2) +
  labs(
    x = "Types of HDW",
    y = expression(
      "Changes in yield sensitivity to HDW"~(kg~ha^-1~hour^-1)
    ),
    subtitle = "(a)"
  ) +
  theme_bw(base_family = figure_font_family, base_size = font_axis_text) +
  theme(
    plot.subtitle = element_text(
      size = font_panel_label,
      hjust = 0.02,
      vjust = 1.2,
    ),
    strip.text = element_text(size = font_strip),
    axis.text.x = element_text(
      size = font_axis_text,
      angle = 0,
      vjust = 1,
      hjust = 0.5
    ),
    axis.text.y = element_text(size = font_axis_text),
    axis.title = element_text(size = font_axis_title),
    legend.position = "none",
    panel.spacing = grid::unit(0.55, "lines"),
    strip.background = element_rect(colour = "transparent"),
    plot.background = element_rect(fill = "transparent", colour = NA),
    plot.margin = margin(1.5, 1.5, 1.5, 1.5, unit = "mm")
  )

# -----------------------------------------------------------------------------
# Panel (b): load and prepare the new public basemap
# -----------------------------------------------------------------------------

amap_dir <- "D:/Crop yield loss at DHW/amap"
amap_country_file <- file.path(amap_dir, "land", "100000.geojson")
amap_province_dir <- file.path(amap_dir, "province_land")
amap_maritime_file <- file.path(amap_dir, "maritime", "100000.geojson")

required_map_paths <- c(
  amap_country_file,
  amap_province_dir,
  amap_maritime_file
)
missing_map_paths <- required_map_paths[!file.exists(required_map_paths)]
if (length(missing_map_paths) > 0) {
  stop(
    paste(
      "The new basemap is incomplete. Missing:",
      paste(missing_map_paths, collapse = "; ")
    ),
    call. = FALSE
  )
}

amap_province_files <- sort(list.files(
  amap_province_dir,
  pattern = "[.]geojson$",
  full.names = TRUE
))
if (length(amap_province_files) != 34L) {
  stop(
    paste("Expected 34 province files; found", length(amap_province_files)),
    call. = FALSE
  )
}

amap_country_wgs84 <- sf::st_read(amap_country_file, quiet = TRUE)
amap_provinces_wgs84 <- do.call(
  rbind,
  lapply(amap_province_files, sf::st_read, quiet = TRUE)
)
amap_maritime_wgs84 <- sf::st_read(amap_maritime_file, quiet = TRUE)

assert_sf_layer <- function(x, object_name) {
  if (!inherits(x, "sf") || nrow(x) == 0) {
    stop(paste(object_name, "is empty or is not an sf object."), call. = FALSE)
  }
  if (is.na(sf::st_crs(x))) {
    stop(paste(object_name, "has no CRS."), call. = FALSE)
  }
  if (!all(sf::st_is_valid(x))) {
    stop(paste(object_name, "contains invalid geometry."), call. = FALSE)
  }
  invisible(TRUE)
}

assert_sf_layer(amap_country_wgs84, "amap_country_wgs84")
assert_sf_layer(amap_provinces_wgs84, "amap_provinces_wgs84")
assert_sf_layer(amap_maritime_wgs84, "amap_maritime_wgs84")
assert_sf_layer(sum_Pro_sen_stats_jion_sf, "sum_Pro_sen_stats_jion_sf")

map_crs <- sf::st_crs(sum_Pro_sen_stats_jion_sf)
if (is.na(map_crs) || sf::st_is_longlat(map_crs)) {
  stop(
    "sum_Pro_sen_stats_jion_sf must use the projected CRS of the main map.",
    call. = FALSE
  )
}

map_units <- tolower(sf::st_crs(map_crs)$units_gdal)
if (is.null(map_units) || is.na(map_units) ||
    !map_units %in% c("metre", "meter", "metres", "meters")) {
  stop("The map CRS must use metre units.", call. = FALSE)
}

amap_country_map <- sf::st_transform(amap_country_wgs84, map_crs)
amap_province_map <- sf::st_transform(amap_provinces_wgs84, map_crs)
amap_maritime_map <- sf::st_transform(amap_maritime_wgs84, map_crs)

# Simplification applies only to plotting copies to control SVG/EMF size.
plot_simplify_tolerance_m <- 1500
simplify_for_plot <- function(x, tolerance_m) {
  simplified <- suppressWarnings(sf::st_simplify(
    x,
    dTolerance = tolerance_m,
    preserveTopology = TRUE
  ))
  if (!all(sf::st_is_valid(simplified))) {
    stop("Simplification created invalid plotting geometry.", call. = FALSE)
  }
  simplified
}

sensitivity_map_plot <- simplify_for_plot(
  sum_Pro_sen_stats_jion_sf,
  plot_simplify_tolerance_m
)

# The supplied map object uses a missing Type value for the HTLH layer.
# Repair only the plotting copy, so the original sf object remains unchanged.
type_text <- trimws(as.character(sensitivity_map_plot$Type))
missing_type <- is.na(sensitivity_map_plot$Type) |
  type_text == "" |
  toupper(type_text) == "NA"
type_text[missing_type] <- "HTLH"
type_text <- display_prgw(type_text)

expected_map_types <- c("HTLH", "PRGW")
unexpected_map_types <- setdiff(unique(type_text), expected_map_types)
if (length(unexpected_map_types) > 0) {
  stop(
    paste(
      "Unexpected map Type value(s):",
      paste(unexpected_map_types, collapse = ", ")
    ),
    call. = FALSE
  )
}
sensitivity_map_plot$Type_display <- factor(
  type_text,
  levels = expected_map_types
)

country_map_plot <- simplify_for_plot(
  amap_country_map,
  plot_simplify_tolerance_m
)
province_map_plot <- simplify_for_plot(
  amap_province_map,
  plot_simplify_tolerance_m
)
maritime_map_plot <- simplify_for_plot(
  amap_maritime_map,
  plot_simplify_tolerance_m
)

country_boundary_plot <- sf::st_boundary(country_map_plot)
province_boundary_plot <- sf::st_boundary(province_map_plot)

# -----------------------------------------------------------------------------
# Build one combined southern-land and maritime inset for every map facet
# -----------------------------------------------------------------------------

map_x_limits <- c(-2700000, 2700000)
map_y_limits <- c(3750000, 6400000)

full_reference_layers <- list(
  country_boundary_plot,
  province_boundary_plot,
  maritime_map_plot
)
full_bbox_matrix <- do.call(
  rbind,
  lapply(full_reference_layers, function(x) as.numeric(sf::st_bbox(x)))
)
full_map_bbox <- c(
  xmin = min(full_bbox_matrix[, 1], na.rm = TRUE),
  ymin = min(full_bbox_matrix[, 2], na.rm = TRUE),
  xmax = max(full_bbox_matrix[, 3], na.rm = TRUE),
  ymax = max(full_bbox_matrix[, 4], na.rm = TRUE)
)

omitted_extent <- c(
  xmin = unname(full_map_bbox["xmin"]),
  ymin = unname(full_map_bbox["ymin"]),
  xmax = unname(full_map_bbox["xmax"]),
  ymax = map_y_limits[1]
)

crop_to_extent <- function(x, extent) {
  cropped <- suppressWarnings(sf::st_crop(
    x,
    xmin = unname(extent["xmin"]),
    ymin = unname(extent["ymin"]),
    xmax = unname(extent["xmax"]),
    ymax = unname(extent["ymax"])
  ))
  cropped[!sf::st_is_empty(cropped), , drop = FALSE]
}

country_south <- crop_to_extent(country_boundary_plot, omitted_extent)
province_south <- crop_to_extent(province_boundary_plot, omitted_extent)
maritime_south <- crop_to_extent(maritime_map_plot, omitted_extent)

inset_source_layers <- Filter(
  function(x) nrow(x) > 0,
  list(country_south, province_south, maritime_south)
)
if (length(inset_source_layers) == 0) {
  stop("No southern or maritime geometry is available for the inset.", call. = FALSE)
}

inset_bbox_matrix <- do.call(
  rbind,
  lapply(inset_source_layers, function(x) as.numeric(sf::st_bbox(x)))
)
inset_source_bbox <- c(
  xmin = min(inset_bbox_matrix[, 1], na.rm = TRUE),
  ymin = min(inset_bbox_matrix[, 2], na.rm = TRUE),
  xmax = max(inset_bbox_matrix[, 3], na.rm = TRUE),
  ymax = max(inset_bbox_matrix[, 4], na.rm = TRUE)
)

main_map_width <- diff(map_x_limits)
main_map_height <- diff(map_y_limits)
inset_source_width <- unname(
  inset_source_bbox["xmax"] - inset_source_bbox["xmin"]
)
inset_source_height <- unname(
  inset_source_bbox["ymax"] - inset_source_bbox["ymin"]
)
inset_source_aspect <- inset_source_width / inset_source_height

# Match the tighter inset geometry used in the reference map: a slightly
# larger frame, less internal padding, and small but visible panel margins.
inset_max_width_fraction <- 0.225
inset_max_height_fraction <- 0.27
inset_right_margin_fraction <- 0.012
inset_bottom_margin_fraction <- 0.03
inset_padding_fraction <- 0.025

inset_max_width <- inset_max_width_fraction * main_map_width
inset_max_height <- inset_max_height_fraction * main_map_height
if (inset_max_width / inset_max_height > inset_source_aspect) {
  inset_outer_height <- inset_max_height
  inset_outer_width <- inset_outer_height * inset_source_aspect
} else {
  inset_outer_width <- inset_max_width
  inset_outer_height <- inset_outer_width / inset_source_aspect
}

inset_xmax <- map_x_limits[2] -
  inset_right_margin_fraction * main_map_width
inset_ymin <- map_y_limits[1] +
  inset_bottom_margin_fraction * main_map_height
inset_outer_bbox <- c(
  xmin = inset_xmax - inset_outer_width,
  ymin = inset_ymin,
  xmax = inset_xmax,
  ymax = inset_ymin + inset_outer_height
)

inset_padding_x <- unname(
  inset_padding_fraction * diff(inset_outer_bbox[c("xmin", "xmax")])
)
inset_padding_y <- unname(
  inset_padding_fraction * diff(inset_outer_bbox[c("ymin", "ymax")])
)
inset_inner_bbox <- c(
  xmin = unname(inset_outer_bbox["xmin"]) + inset_padding_x,
  ymin = unname(inset_outer_bbox["ymin"]) + inset_padding_y,
  xmax = unname(inset_outer_bbox["xmax"]) - inset_padding_x,
  ymax = unname(inset_outer_bbox["ymax"]) - inset_padding_y
)

scale_sf_to_bbox <- function(x, source_bbox, target_bbox) {
  if (nrow(x) == 0) return(x)
  
  source_crs <- sf::st_crs(x)
  source_width <- as.numeric(source_bbox["xmax"] - source_bbox["xmin"])
  source_height <- as.numeric(source_bbox["ymax"] - source_bbox["ymin"])
  target_width <- as.numeric(target_bbox["xmax"] - target_bbox["xmin"])
  target_height <- as.numeric(target_bbox["ymax"] - target_bbox["ymin"])
  dimensions <- c(source_width, source_height, target_width, target_height)
  if (!all(is.finite(dimensions)) || any(dimensions <= 0)) {
    stop("Invalid inset extent.", call. = FALSE)
  }
  
  scale_factor <- min(
    target_width / source_width,
    target_height / source_height
  )
  source_center <- unname(c(
    mean(source_bbox[c("xmin", "xmax")]),
    mean(source_bbox[c("ymin", "ymax")])
  ))
  target_center <- unname(c(
    mean(target_bbox[c("xmin", "xmax")]),
    mean(target_bbox[c("ymin", "ymax")])
  ))
  
  geometry <- (sf::st_geometry(x) - source_center) *
    scale_factor + target_center
  geometry <- sf::st_set_crs(geometry, source_crs)
  sf::st_geometry(x) <- geometry
  x
}

make_bbox_sf <- function(bbox, crs) {
  coordinates <- matrix(
    c(
      bbox["xmin"], bbox["ymin"],
      bbox["xmax"], bbox["ymin"],
      bbox["xmax"], bbox["ymax"],
      bbox["xmin"], bbox["ymax"],
      bbox["xmin"], bbox["ymin"]
    ),
    ncol = 2,
    byrow = TRUE
  )
  sf::st_sf(
    geometry = sf::st_sfc(sf::st_polygon(list(coordinates)), crs = crs)
  )
}

country_south_inset <- scale_sf_to_bbox(
  country_south,
  inset_source_bbox,
  inset_inner_bbox
)
province_south_inset <- scale_sf_to_bbox(
  province_south,
  inset_source_bbox,
  inset_inner_bbox
)
maritime_south_inset <- scale_sf_to_bbox(
  maritime_south,
  inset_source_bbox,
  inset_inner_bbox
)
inset_outer_frame <- make_bbox_sf(inset_outer_bbox, map_crs)

# -----------------------------------------------------------------------------
# Panel (b): spatial sensitivity-change map
# -----------------------------------------------------------------------------

sensity_change_sp_gg <- ggplot() +
  geom_sf(
    data = sensitivity_map_plot,
    aes(fill = mean_value.y * 38),
    colour = "transparent",
    linewidth = 0
  ) +
  scale_fill_stepsn(
    colors = RColorBrewer::brewer.pal(11, "BrBG")[2:10],
    breaks = seq(-40, 40, 10),
    labels = seq(-40, 40, 10),
    limits = c(-40, 40),
    na.value = "white",
    values = scales::rescale(seq(-40, 40, 10)),
    name = NULL
  ) +
  geom_sf(
    data = province_boundary_plot,
    colour = "grey50",
    alpha = 0.9,
    linewidth = 0.10,
    inherit.aes = FALSE,
    show.legend = FALSE
  ) +
  geom_sf(
    data = country_boundary_plot,
    colour = "grey45",
    alpha = 0.95,
    linewidth = 0.18,
    inherit.aes = FALSE,
    show.legend = FALSE
  ) +
  geom_sf(
    data = inset_outer_frame,
    fill = "white",
    colour = NA,
    inherit.aes = FALSE,
    show.legend = FALSE
  ) +
  geom_sf(
    data = province_south_inset,
    fill = NA,
    colour = "grey55",
    linewidth = 0.08,
    inherit.aes = FALSE,
    show.legend = FALSE
  ) +
  geom_sf(
    data = country_south_inset,
    fill = NA,
    colour = "grey45",
    linewidth = 0.16,
    inherit.aes = FALSE,
    show.legend = FALSE
  ) +
  geom_sf(
    data = maritime_south_inset,
    colour = "grey45",
    linewidth = 0.14,
    inherit.aes = FALSE,
    show.legend = FALSE
  ) +
  geom_sf(
    data = inset_outer_frame,
    fill = NA,
    colour = "grey45",
    linewidth = 0.22,
    inherit.aes = FALSE,
    show.legend = FALSE
  ) +
  facet_wrap(
    ~Type_display,
    ncol = 1,
    drop = FALSE
  ) +
  coord_sf(
    xlim = map_x_limits,
    ylim = map_y_limits,
    expand = FALSE,
    datum = sf::st_crs(4326)
  ) +
  labs(
    y = expression(
      "Changes in yield sensitivity to HDW"~(kg~ha^-1~hour^-1)
    ),
    x = NULL,
    subtitle = "(b)"
  ) +
  theme_bw(base_family = figure_font_family, base_size = font_axis_text) +
  theme(
    plot.subtitle = element_text(
      size = font_panel_label,
      hjust = 0.02,
      vjust = 1.2
    ),
    strip.text = element_text(size = font_strip),
    axis.ticks = element_blank(),
    axis.text = element_blank(),
    axis.title = element_text(size = font_axis_title),
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.key.width = grid::unit(0.65, "cm"),
    legend.key.height = grid::unit(0.18, "cm"),
    legend.text = element_text(size = font_legend),
    legend.title = element_text(size = font_legend),
    legend.background = element_blank(),
    panel.grid.major = element_line(colour = "grey90", linewidth = 0.30),
    panel.grid.minor = element_blank(),
    strip.background = element_rect(colour = "transparent"),
    plot.background = element_rect(fill = "transparent", colour = NA),
    plot.margin = margin(1.5, 1.5, 1.5, 1.5, unit = "mm")
  )

# -----------------------------------------------------------------------------
# Assemble the two panels with matched top and bottom edges
# -----------------------------------------------------------------------------

# coord_sf() must preserve geographic proportions. Therefore increasing only
# the viewport height cannot enlarge panel (b); it merely moves its whitespace.
# Give the map the width required by its fixed aspect ratio, and let plot_grid()
# align the two complete grobs at both their top and bottom edges.
Figure_4_gg <- cowplot::plot_grid(
  county_sens_change_sum_gg,
  sensity_change_sp_gg,
  nrow = 1,
  rel_widths = c(0.525, 0.475),
  align = "h",
  axis = "tb"
)

# -----------------------------------------------------------------------------
# Source Data and consistent exports
# -----------------------------------------------------------------------------

skip_figure_export <- identical(Sys.getenv("HDW_SKIP_EXPORT"), "1")

if (!skip_figure_export) {
  output_dir <- Sys.getenv(
    "HDW_FIGURE_OUTPUT_DIR",
    unset = "D:/Crop yield loss at DHW/Figures/Figures_prof"
  )
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  
  source_data_dir <- file.path(output_dir, "Source data")
  dir.create(source_data_dir, recursive = TRUE, showWarnings = FALSE)
  
  amap_source_manifest <- data.frame(
    role = c("country_land", "province_land", "maritime_line"),
    path = c(
      amap_country_file,
      paste(amap_province_files, collapse = ";"),
      amap_maritime_file
    ),
    stringsAsFactors = FALSE
  )
  
  figure_4_source_objects <- c(
    "summarized_df_filtered",
    "sum_Pro_sen_stats_jion_sf",
    "amap_country_wgs84",
    "amap_provinces_wgs84",
    "amap_maritime_wgs84",
    "amap_source_manifest"
  )
  
  save(
    list = figure_4_source_objects,
    file = file.path(source_data_dir, "Figure_4_source_data.RData"),
    envir = environment(),
    version = 2
  )
  
  output_prefix <- file.path(output_dir, "Figure_4")
  fig_width_cm <- 14.6
  fig_height_cm <- 9
  fig_width_in <- fig_width_cm / 2.54
  fig_height_in <- fig_height_cm / 2.54
  
  svglite::svglite(
    paste0(output_prefix, ".svg"),
    width = fig_width_in,
    height = fig_height_in,
    bg = "transparent"
  )
  print(Figure_4_gg)
  dev.off()
  
  grDevices::cairo_pdf(
    paste0(output_prefix, ".pdf"),
    width = fig_width_in,
    height = fig_height_in,
    family = figure_font_family,
    bg = "transparent",
    fallback_resolution = 600
  )
  print(Figure_4_gg)
  dev.off()
  
  ragg::agg_tiff(
    paste0(output_prefix, ".tiff"),
    width = fig_width_cm,
    height = fig_height_cm,
    units = "cm",
    res = 600,
    compression = "lzw",
    background = "white"
  )
  print(Figure_4_gg)
  dev.off()
  
  word_dpi <- 450
  ragg::agg_png(
    paste0(output_prefix, "_word_", word_dpi, "dpi.png"),
    width = fig_width_cm,
    height = fig_height_cm,
    units = "cm",
    res = word_dpi,
    background = "white"
  )
  print(Figure_4_gg)
  dev.off()
  
  if (requireNamespace("devEMF", quietly = TRUE)) {
    devEMF::emf(
      paste0(output_prefix, ".emf"),
      width = fig_width_in,
      height = fig_height_in,
      family = figure_font_family,
      pointsize = 11,
      coordDPI = 600,
      emfPlus = TRUE
    )
    print(Figure_4_gg)
    dev.off()
  }
}
