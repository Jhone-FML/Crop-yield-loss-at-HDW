# Supplementary Figure 10: field-scale driver importance and partial dependence

required_packages <- c("ggplot2", "cowplot", "svglite", "ragg")
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
]
if (length(missing_packages) > 0) {
  stop(
    paste("Install required package(s):", paste(missing_packages, collapse = ", ")),
    call. = FALSE
  )
}
suppressPackageStartupMessages({
  library(ggplot2)
  library(cowplot)
})

required_objects <- c(
  "Importance2_f", "Response_f", "col", "cols",
  "legend_levels", "legend_labels_char"
)
missing_objects <- required_objects[
  !vapply(required_objects, exists, logical(1), inherits = TRUE)
]
if (length(missing_objects) > 0) {
  stop(
    paste("Missing required object(s):", paste(missing_objects, collapse = ", ")),
    call. = FALSE
  )
}

required_columns <- function(data, columns, object_name) {
  missing_columns <- setdiff(columns, names(data))
  if (length(missing_columns) > 0) {
    stop(
      paste(object_name, "is missing:", paste(missing_columns, collapse = ", ")),
      call. = FALSE
    )
  }
}
required_columns(Importance2_f, c("percentage", "Feature", "ID"), "Importance2_f")
required_columns(
  Response_f,
  c("Variables", "x", "y", "ID"),
  "Response_f"
)
if (nrow(Importance2_f) == 0L || nrow(Response_f) == 0L) {
  stop("Importance2_f and Response_f must both contain data.", call. = FALSE)
}

# Plotting copies and display labels; source objects remain unchanged.
field_id_levels <- if (is.factor(Importance2_f$ID)) {
  levels(droplevels(Importance2_f$ID))
} else {
  unique(as.character(Importance2_f$ID))
}
field_id_levels <- field_id_levels[
  field_id_levels %in% as.character(Importance2_f$ID)
]
field_display_levels <- c(
  "HTLH-E", "HTLH-M", "HTLH-L", "PRGW-M", "PRGW-L"
)
if (length(field_id_levels) != length(field_display_levels)) {
  stop(
    paste0(
      "Panel (a) requires five ID panels, but Importance2_f contains ",
      length(field_id_levels), "."
    ),
    call. = FALSE
  )
}
field_id_key <- data.frame(
  ID = field_id_levels,
  ID_display = field_display_levels,
  stringsAsFactors = FALSE
)
Importance2_f_plot <- Importance2_f
Importance2_f_plot$ID_display <- factor(
  field_display_levels[
    match(as.character(Importance2_f_plot$ID), field_id_levels)
  ],
  levels = field_display_levels
)

feature_label_map <- c(
  "Trends_HTLH_Early" = "HTLH-E",
  "Trends_HTLH_Middle" = "HTLH-M",
  "Trends_HTLH_Late" = "HTLH-L",
  "Trends_PRGW_Middle" = "PRGW-M",
  "Trends_PRGW_Late" = "PRGW-L"
)
feature_legend_labels <- function(x) {
  out <- as.character(x)
  replace <- out %in% names(feature_label_map)
  out[replace] <- unname(feature_label_map[out[replace]])
  out
}

top_variables <- c(
  "Trends_HTLH_Early", "Trends_HTLH_Middle", "Trends_HTLH_Late"
)
bottom_variables <- c("Trends_PRGW_Middle", "Trends_PRGW_Late")
response_variable_labels <- c(
  "Trends_HTLH_Early" = "HTLH-E",
  "Trends_HTLH_Middle" = "HTLH-M",
  "Trends_HTLH_Late" = "HTLH-L",
  "Trends_PRGW_Middle" = "PRGW-M",
  "Trends_PRGW_Late" = "PRGW-L"
)
Response_f_plot <- Response_f
Response_f_plot$Variables_display <- unname(
  response_variable_labels[as.character(Response_f_plot$Variables)]
)
Response_f_plot$Variables_display <- factor(
  Response_f_plot$Variables_display,
  levels = unname(response_variable_labels)
)

Response_f_top <- Response_f_plot[
  !is.na(Response_f_plot$Variables) &
    Response_f_plot$Variables %in% top_variables,
  ,
  drop = FALSE
]
Response_f_bottom <- Response_f_plot[
  !is.na(Response_f_plot$Variables) &
    Response_f_plot$Variables %in% bottom_variables,
  ,
  drop = FALSE
]
if (nrow(Response_f_top) == 0L || nrow(Response_f_bottom) == 0L) {
  stop("One or both panel (b) subsets contain no rows.", call. = FALSE)
}

filter_manifest <- data.frame(
  plotted_object = c("Importance2_f_plot", "Response_f_top", "Response_f_bottom"),
  source_object = c("Importance2_f", "Response_f", "Response_f"),
  input_rows = c(nrow(Importance2_f), nrow(Response_f), nrow(Response_f)),
  plotted_rows = c(
    nrow(Importance2_f_plot), nrow(Response_f_top), nrow(Response_f_bottom)
  ),
  rule = c(
    "All rows",
    paste("Variables in", paste(top_variables, collapse = ", ")),
    paste("Variables in", paste(bottom_variables, collapse = ", "))
  ),
  stringsAsFactors = FALSE
)

# Unified typography for the final 20 x 12 cm canvas.
# Publication font: Arial-compatible Helvetica/sans-serif fallback.
figure_font_family <- "sans"
font_panel_title <- 10.5
font_strip <- 8.5
font_axis_text <- 8
font_axis_title <- 9
font_legend <- 7.5
font_percentage <- 2.55

Importance_f_gg <- ggplot(
  Importance2_f_plot,
  aes(x = 1, y = percentage, fill = Feature)
) +
  geom_col(colour = "white", linewidth = 0.22, width = 1) +
  geom_text(
    aes(
      label = ifelse(
        percentage >= 1,
        paste0(round(percentage, 1), "%"),
        ""
      )
    ),
    position = position_stack(vjust = 0.5),
    colour = "white",
    size = font_percentage,
    lineheight = 0.95
  ) +
  facet_wrap(
    ~ID_display,
    ncol = 5,
    labeller = label_value,
    drop = FALSE
  ) +
  scale_fill_manual(
    name = NULL,
    values = c(
      col,
      c("gray66", "gray68", "gray70", "gray72", "gray74", "gray76")
    ),
    labels = feature_legend_labels,
    guide = guide_legend(ncol = 5, nrow = 2, byrow = TRUE)
  ) +
  labs(
    x = NULL,
    y = NULL,
    subtitle = paste0(
      "(a) Importance of drivers in XGBoost\n",
      "at the field scale"
    )
  ) +
  theme_bw(base_family = figure_font_family, base_size = font_axis_text) +
  theme(
    plot.subtitle = element_text(
      size = font_panel_title,
      lineheight = 0.95,
      margin = margin(b = 3)
    ),
    strip.text = element_text(
      size = font_strip,
      margin = margin(t = 2, b = 2)
    ),
    panel.spacing = grid::unit(0.10, "cm"),
    axis.text = element_blank(),
    axis.ticks = element_blank(),
    axis.title = element_blank(),
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.key.width = grid::unit(0.40, "cm"),
    legend.key.height = grid::unit(0.24, "cm"),
    legend.spacing.x = grid::unit(0.08, "cm"),
    legend.text = element_text(size = font_legend),
    legend.background = element_blank(),
    strip.background = element_rect(colour = "transparent"),
    plot.background = element_rect(fill = "transparent", colour = NA),
    plot.margin = margin(2, 3, 2, 3, unit = "mm")
  )

field_response_theme <- theme_bw(
  base_family = figure_font_family,
  base_size = font_axis_text
) +
  theme(
    strip.text = element_text(size = font_strip),
    axis.text.x = element_text(
      size = font_axis_text,
      angle = 45,
      vjust = 1,
      hjust = 1
    ),
    axis.text.y = element_text(size = font_axis_text),
    axis.title = element_text(size = font_axis_title),
    legend.position = "none",
    panel.spacing = grid::unit(0.20, "cm"),
    strip.background = element_rect(colour = "transparent"),
    plot.background = element_rect(fill = "transparent", colour = NA),
    plot.margin = margin(2, 2, 2, 2, unit = "mm")
  )

p_field_1_1 <- ggplot(
  Response_f_top,
  aes(x = x, y = y, colour = ID)
) +
  geom_line(linewidth = 0.65) +
  facet_wrap(
    ~Variables_display,
    scales = "free_x",
    labeller = label_value,
    ncol = 3
  ) +
  scale_colour_manual(
    name = NULL,
    values = cols,
    breaks = legend_levels,
    labels = parse(text = legend_labels_char)
  ) +
  labs(
    x = NULL,
    y = expression(
      italic(beta)[HDW %*% year]~(kg~ha^-1~hour^-1~year^-1)
    ),
    subtitle = paste0(
      "(b) Partial dependence of the drivers\n",
      "at the field scale"
    )
  ) +
  field_response_theme +
  theme(
    plot.subtitle = element_text(
      size = font_panel_title,
      lineheight = 0.95,
      margin = margin(b = 3)
    )
  )

p_field_1_2 <- ggplot(
  Response_f_bottom,
  aes(x = x, y = y, colour = ID)
) +
  geom_line(linewidth = 0.65) +
  facet_wrap(
    ~Variables_display,
    scales = "free_x",
    labeller = label_value,
    ncol = 2
  ) +
  scale_colour_manual(
    name = NULL,
    values = cols,
    breaks = legend_levels,
    labels = parse(text = legend_labels_char)
  ) +
  labs(
    # Non-breaking space prevents SVG-to-Word spacing loss.
    x = "Trend of HDW\u00A0(hour year\u207B\u00B9)",
    y = expression(
      italic(beta)[HDW %*% year]~(kg~ha^-1~hour^-1~year^-1)
    )
  ) +
  field_response_theme +
  theme(
    axis.text.x = element_text(
      size = font_axis_text,
      angle = 0,
      vjust = 0.5
    ),
    axis.title.y.left = element_text(hjust = -0.2),
    plot.margin = margin(1, 2, 3, 2, unit = "mm")
  )

# Preserve the original five-panel plus upper-three/lower-two composition.
# Avoid negative x offsets so titles, strips and legends remain inside canvas.
Supplementary_Figure_10_gg <- cowplot::ggdraw() +
  cowplot::draw_plot(
    Importance_f_gg,
    x = 0,
    y = 0,
    width = 0.46,
    height = 1
  ) +
  cowplot::draw_plot(
    p_field_1_1,
    x = 0.46,
    y = 0.50,
    width = 0.54,
    height = 0.50
  ) +
  cowplot::draw_plot(
    p_field_1_2,
    x = 0.46,
    y = 0,
    width = 0.54,
    height = 0.50
  )

# Source data and consistent exports.
skip_figure_export <- identical(Sys.getenv("HDW_SKIP_EXPORT"), "1")
if (!skip_figure_export) {
  output_dir <- Sys.getenv(
    "HDW_FIGURE_OUTPUT_DIR",
    unset = "D:/Crop yield loss at DHW/Figures/Figures_prof"
  )
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  source_data_dir <- file.path(output_dir, "Source data")
  dir.create(source_data_dir, recursive = TRUE, showWarnings = FALSE)

  plot_configuration <- list(
    col = col,
    cols = cols,
    legend_levels = legend_levels,
    legend_labels_char = legend_labels_char,
    field_id_key = field_id_key,
    top_variables = top_variables,
    bottom_variables = bottom_variables
  )
  save(
    Importance2_f,
    Importance2_f_plot,
    Response_f,
    Response_f_plot,
    Response_f_top,
    Response_f_bottom,
    filter_manifest,
    plot_configuration,
    file = file.path(
      source_data_dir,
      "Supplementary_Figure_10_source_data.RData"
    ),
    version = 2
  )

  output_prefix <- file.path(output_dir, "Supplementary_Figure_10")
  fig_width_cm <- 20
  fig_height_cm <- 12
  fig_width_in <- fig_width_cm / 2.54
  fig_height_in <- fig_height_cm / 2.54

  svglite::svglite(
    paste0(output_prefix, ".svg"),
    width = fig_width_in,
    height = fig_height_in,
    bg = "transparent"
  )
  print(Supplementary_Figure_10_gg)
  dev.off()

  grDevices::cairo_pdf(
    paste0(output_prefix, ".pdf"),
    width = fig_width_in,
    height = fig_height_in,
    family = figure_font_family,
    bg = "transparent",
    fallback_resolution = 600
  )
  print(Supplementary_Figure_10_gg)
  dev.off()

  ragg::agg_tiff(
    paste0(output_prefix, ".tiff"),
    width = fig_width_cm,
    height = fig_height_cm,
    units = "cm",
    res = 600,
    compression = "lzw",
    background = "white"
  )
  print(Supplementary_Figure_10_gg)
  dev.off()

  word_dpi <- 450
  ragg::agg_png(
    paste0(output_prefix, "_word_", word_dpi, "dpi.png"),
    width = fig_width_cm,
    height = fig_height_cm,
    units = "cm",
    res = word_dpi,
    background = "white"
  )
  print(Supplementary_Figure_10_gg)
  dev.off()

  if (requireNamespace("devEMF", quietly = TRUE)) {
    devEMF::emf(
      paste0(output_prefix, ".emf"),
      width = fig_width_in,
      height = fig_height_in,
      family = figure_font_family,
      pointsize = 10,
      coordDPI = 600,
      emfPlus = TRUE
    )
    print(Supplementary_Figure_10_gg)
    dev.off()
  }
}
