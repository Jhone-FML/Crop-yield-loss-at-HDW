# Supplementary Figure 14: changes in wheat yield sensitivity to climate

required_packages <- c("ggplot2", "ggdist", "RColorBrewer", "svglite", "ragg")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages)) {
  stop(
    "Install the required package(s): ", paste(missing_packages, collapse = ", "),
    "\nRun: install.packages(c(",
    paste(sprintf('"%s"', missing_packages), collapse = ", "), "))",
    call. = FALSE
  )
}

if (!exists("Sens_fit_df_TEF", inherits = TRUE)) {
  stop("Sens_fit_df_TEF is missing.", call. = FALSE)
}
required_columns <- c("cols", "value", "fact")
missing_columns <- setdiff(required_columns, names(Sens_fit_df_TEF))
if (length(missing_columns)) {
  stop("Sens_fit_df_TEF is missing: ", paste(missing_columns, collapse = ", "), call. = FALSE)
}
if (!is.numeric(Sens_fit_df_TEF$value)) {
  stop("Sens_fit_df_TEF$value must be numeric.", call. = FALSE)
}

# Keep the original data and factor ordering; do not recalculate or filter values.
plot_data <- Sens_fit_df_TEF
if (!is.factor(plot_data$cols)) {
  plot_data$cols <- factor(plot_data$cols, levels = unique(plot_data$cols))
}
if (!is.factor(plot_data$fact)) {
  plot_data$fact <- factor(plot_data$fact, levels = unique(plot_data$fact))
}

prgn <- RColorBrewer::brewer.pal(11, "PRGn")
original_palette <- c(
  "orangered3", "orangered",
  prgn[2], prgn[2], prgn[4], prgn[4],
  prgn[9], prgn[9], prgn[10], prgn[10]
)
colour_levels <- levels(plot_data$cols)
if (length(colour_levels) > length(original_palette)) {
  stop("The original palette supports at most 10 levels in 'cols'.", call. = FALSE)
}
tef_colours <- stats::setNames(original_palette[seq_along(colour_levels)], colour_levels)

x_labels <- c(
  "EDD_HD-MT" = expression(EDD["HD-MT"]),
  "EDD_JT-HD" = expression(EDD["JT-HD"]),
  "FDD_JT-HD" = expression(FDD["JT-HD"]),
  "FDD_PT-JT" = expression(FDD["PT-JT"])
)

# Publication font: Arial, with the device's sans-serif fallback when unavailable.
figure_font <- "Arial"

Supplementary_Figure_14_gg <- ggplot2::ggplot(
  plot_data,
  ggplot2::aes(x = cols, y = value, colour = cols)
) +
  ggplot2::geom_hline(
    yintercept = 0,
    linewidth = 0.5,
    linetype = "dashed",
    colour = "black"
  ) +
  ggdist::stat_pointinterval(
    size = 1.25,
    position = ggplot2::position_dodge(width = 0.7, preserve = "single")
  ) +
  ggplot2::stat_summary(
    ggplot2::aes(label = after_stat(round(y, 1))),
    fun = mean,
    geom = "text",
    hjust = -0.12,
    vjust = 1.35,
    size = 3.0,
    show.legend = FALSE
  ) +
  ggplot2::scale_colour_manual(values = tef_colours, drop = FALSE) +
  ggplot2::scale_x_discrete(name = NULL, labels = x_labels) +
  ggplot2::facet_wrap(~fact, scales = "free", ncol = 2) +
  ggplot2::labs(
    x = NULL,
    y = expression(
      atop(
        "Changes in yield sensitivity to weather",
        "(" * kg~ha^{-1}~day^{-1}~degree*C^{-1} * ")"
      )
    )
  ) +
  ggplot2::coord_cartesian(clip = "off") +
  ggplot2::theme_bw(base_family = figure_font, base_size = 9) +
  ggplot2::theme(
    strip.text = ggplot2::element_text(size = 9),
    strip.background = ggplot2::element_rect(fill = "grey85", colour = NA),
    axis.text.x = ggplot2::element_text(size = 8, angle = 45, hjust = 1, vjust = 1),
    axis.text.y = ggplot2::element_text(size = 8),
    axis.title.y = ggplot2::element_text(
      size = 9.5,
      lineheight = 1.05,
      margin = ggplot2::margin(r = 8)
    ),
    legend.position = "none",
    panel.spacing.x = grid::unit(0.55, "cm"),
    panel.spacing.y = grid::unit(0.40, "cm"),
    plot.margin = ggplot2::margin(5, 7, 5, 7, unit = "mm"),
    plot.background = ggplot2::element_rect(fill = "transparent", colour = NA)
  )

# The original figure is square; every format below uses exactly 16 x 16 cm.
output_dir <- Sys.getenv(
  "HDW_FIGURE_DIR",
  unset = "D:/Crop yield loss at DHW/Figures/Figures_prof"
)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
output_prefix <- file.path(output_dir, "Supplementary_Figure_14")
fig_width_cm <- 16
fig_height_cm <- 16

save(
  Sens_fit_df_TEF,
  plot_data,
  tef_colours,
  x_labels,
  file = paste0(output_prefix, "_source_data.RData")
)

if (!identical(Sys.getenv("HDW_SKIP_EXPORT"), "1")) {
  svglite::svglite(
    paste0(output_prefix, ".svg"),
    width = fig_width_cm / 2.54,
    height = fig_height_cm / 2.54,
    bg = "transparent",
    system_fonts = list(Arial = "Arial")
  )
  print(Supplementary_Figure_14_gg)
  grDevices::dev.off()

  grDevices::cairo_pdf(
    paste0(output_prefix, ".pdf"),
    width = fig_width_cm / 2.54,
    height = fig_height_cm / 2.54,
    family = "sans",
    bg = "transparent"
  )
  print(Supplementary_Figure_14_gg)
  grDevices::dev.off()

  ragg::agg_tiff(
    paste0(output_prefix, ".tiff"),
    width = fig_width_cm,
    height = fig_height_cm,
    units = "cm",
    res = 600,
    compression = "lzw",
    background = "white"
  )
  print(Supplementary_Figure_14_gg)
  grDevices::dev.off()

  ragg::agg_png(
    paste0(output_prefix, "_word_450dpi.png"),
    width = fig_width_cm,
    height = fig_height_cm,
    units = "cm",
    res = 450,
    background = "white"
  )
  print(Supplementary_Figure_14_gg)
  grDevices::dev.off()

  if (requireNamespace("devEMF", quietly = TRUE)) {
    devEMF::emf(
      paste0(output_prefix, ".emf"),
      units = "cm",
      width = fig_width_cm,
      height = fig_height_cm,
      pointsize = 11,
      family = figure_font
    )
    print(Supplementary_Figure_14_gg)
    grDevices::dev.off()
  }
}

Supplementary_Figure_14_gg
