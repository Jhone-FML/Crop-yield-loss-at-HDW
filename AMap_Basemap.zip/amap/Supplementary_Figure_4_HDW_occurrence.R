# Supplementary Figure 4: timing of HDW occurrence and wheat growth stages

required_packages <- c(
  "ggplot2", "ggridges", "dplyr", "tidyr", "svglite", "ragg"
)
missing_packages <- required_packages[!vapply(
  required_packages, requireNamespace, logical(1), quietly = TRUE
)]
if (length(missing_packages) > 0) {
  stop(
    "Install the required package(s): ", paste(missing_packages, collapse = ", "),
    "\nRun: install.packages(c(",
    paste(sprintf('"%s"', missing_packages), collapse = ", "), "))",
    call. = FALSE
  )
}

required_objects <- c("Wheat_DHW", "Wheat_county_merged_final")
missing_objects <- required_objects[!vapply(
  required_objects, exists, logical(1), inherits = TRUE
)]
if (length(missing_objects) > 0) {
  stop("Missing required object(s): ", paste(missing_objects, collapse = ", "), call. = FALSE)
}

if (ncol(Wheat_DHW) < 16) {
  stop("Wheat_DHW must contain at least 16 columns; column 16 is the year field.", call. = FALSE)
}
county_columns <- c("site", "year", "JTdate", "HDdate", "MTdate", "PTdate")
missing_county_columns <- setdiff(county_columns, names(Wheat_county_merged_final))
if (length(missing_county_columns) > 0) {
  stop(
    "Wheat_county_merged_final is missing: ",
    paste(missing_county_columns, collapse = ", "),
    call. = FALSE
  )
}

# -----------------------------------------------------------------------------
# Original data construction and classifications
# -----------------------------------------------------------------------------

Wheat_DHW_temp <- Wheat_DHW
names(Wheat_DHW_temp)[16] <- "year"
if (!all(c("site", "year", "Date", "Type") %in% names(Wheat_DHW_temp))) {
  stop("Wheat_DHW must provide site, year (column 16), Date and Type.", call. = FALSE)
}
Wheat_DHW_temp$site <- as.character(Wheat_DHW_temp$site)

Data_HDW_PY <- Wheat_county_merged_final[, county_columns, drop = FALSE] |>
  dplyr::left_join(Wheat_DHW_temp, by = c("site", "year"))

Data_HDW_PY <- Data_HDW_PY |>
  dplyr::mutate(
    HDW_occurrence = Date - PTdate,
    JT = JTdate - PTdate,
    HD = HDdate - PTdate,
    MT = MTdate - PTdate,
    group = ifelse(year > 2008, "2009-2018", "1981-2008")
  )

# Preserve the original complete-case rule and report its effect below.
Data_HDW_PY_nao <- stats::na.omit(Data_HDW_PY)
if (nrow(Data_HDW_PY_nao) == 0) {
  stop("No complete observations remain after na.omit(Data_HDW_PY).", call. = FALSE)
}

df_long <- Data_HDW_PY_nao |>
  dplyr::mutate(
    dplyr::across(
      c(HDW_occurrence, JT, HD, MT),
      ~as.numeric(.)
    )
  ) |>
  tidyr::pivot_longer(
    cols = c(HDW_occurrence, JT, HD, MT),
    names_to = "Variable",
    values_to = "Days"
  ) |>
  dplyr::mutate(
    wtype = dplyr::case_when(
      Variable == "MT" & Days < 150 ~ "Spring wheat",
      Variable == "HDW_occurrence" & Days < 150 ~ "Spring wheat",
      Variable == "HD" & Days < 150 ~ "Spring wheat",
      Variable == "JT" & Days < 100 ~ "Spring wheat",
      TRUE ~ "Winter wheat"
    ),
    Type = dplyr::recode(
      Type,
      "HighTempLowHumidity" = "HDWHTLH",
      "PostRainScorch" = "HDWPRGW",
      "DryWind" = "HDWDTWD"
    ),
    Type_label = dplyr::case_when(
      Type == "HDWHTLH" ~ "HDW[HTLH]",
      Type == "HDWPRGW" ~ "HDW[PRGW]",
      Type == "HDWDTWD" ~ "HDW[DTWD]",
      TRUE ~ NA_character_
    ),
    # Rename before computing medians so labels use the same categories as ridges.
    Variable = dplyr::recode(
      Variable,
      "HDW_occurrence" = "HDW occurrence",
      "JT" = "JT",
      "HD" = "HD",
      "MT" = "MT"
    ),
    Variable = factor(
      Variable,
      levels = c("HDW occurrence", "JT", "HD", "MT")
    ),
    Type_label = factor(
      Type_label,
      levels = c("HDW[HTLH]", "HDW[PRGW]", "HDW[DTWD]")
    ),
    wtype = factor(wtype, levels = c("Spring wheat", "Winter wheat")),
    group = factor(group, levels = c("1981-2008", "2009-2018"))
  ) |>
  dplyr::filter(!is.na(Type_label))

if (nrow(df_long) == 0) {
  stop("No recognized HDW types remain for plotting.", call. = FALSE)
}

# Retain the original fixed label positions shown in Supplementary Figure 4.
median_df <- df_long |>
  dplyr::group_by(Type_label, Variable, group, wtype) |>
  dplyr::summarise(value = stats::median(Days, na.rm = TRUE), .groups = "drop") |>
  dplyr::mutate(
    x_pos = dplyr::case_when(
      wtype == "Spring wheat" & group == "1981-2008" ~ 140,
      wtype == "Spring wheat" & group == "2009-2018" ~ 40,
      wtype == "Winter wheat" & group == "1981-2008" ~ 280,
      wtype == "Winter wheat" & group == "2009-2018" ~ 150,
      TRUE ~ NA_real_
    ),
    hjust = dplyr::if_else(group == "1981-2008", 0, 1)
  )

my_cols <- c("1981-2008" = "#1b9e77", "2009-2018" = "#e55f09")
ridge_scale <- 0.7
figure_font <- "Arial"

Supplementary_Figure_4_gg <- ggplot2::ggplot(
  df_long,
  ggplot2::aes(
    x = Days,
    y = factor(Variable, levels = rev(levels(Variable))),
    fill = group,
    colour = group
  )
) +
  ggridges::geom_density_ridges(
    alpha = 0.4,
    scale = ridge_scale,
    quantile_lines = TRUE,
    quantiles = 2,
    linewidth = 0.45
  ) +
  ggplot2::geom_text(
    data = median_df,
    ggplot2::aes(
      x = x_pos,
      y = as.numeric(factor(Variable, levels = rev(levels(df_long$Variable)))) + 0.30,
      label = value,
      colour = group,
      hjust = hjust
    ),
    inherit.aes = FALSE,
    size = 2.8,
    show.legend = FALSE
  ) +
  ggplot2::facet_grid(
    Type_label ~ wtype,
    scales = "free",
    labeller = ggplot2::labeller(Type_label = ggplot2::label_parsed)
  ) +
  ggplot2::scale_fill_manual(values = my_cols, name = NULL) +
  ggplot2::scale_colour_manual(values = my_cols, name = NULL) +
  ggplot2::guides(
    fill = ggplot2::guide_legend(nrow = 1, byrow = TRUE),
    colour = ggplot2::guide_legend(nrow = 1, byrow = TRUE)
  ) +
  ggplot2::labs(x = "Day after planting (days)", y = NULL) +
  ggplot2::theme_bw(base_family = figure_font, base_size = 9) +
  ggplot2::theme(
    strip.text = ggplot2::element_text(size = 9),
    strip.background = ggplot2::element_rect(fill = "grey85", colour = NA),
    axis.text.x = ggplot2::element_text(size = 8.5),
    axis.text.y = ggplot2::element_text(size = 8.5),
    axis.title.x = ggplot2::element_text(size = 10, margin = ggplot2::margin(t = 5)),
    legend.position = "bottom",
    legend.justification = "center",
    legend.direction = "horizontal",
    legend.key.height = grid::unit(0.25, "cm"),
    legend.key.width = grid::unit(0.45, "cm"),
    legend.margin = ggplot2::margin(t = 1, r = 0, b = 0, l = 0, unit = "mm"),
    legend.background = ggplot2::element_blank(),
    legend.text = ggplot2::element_text(size = 8),
    panel.spacing = grid::unit(0.35, "cm"),
    plot.margin = ggplot2::margin(4, 5, 4, 5, unit = "mm"),
    plot.background = ggplot2::element_rect(fill = "transparent", colour = NA)
  )

# -----------------------------------------------------------------------------
# Reproducible output bundle: 18 x 14 cm in every format
# -----------------------------------------------------------------------------

output_dir <- Sys.getenv(
  "HDW_FIGURE_DIR",
  unset = "D:/Crop yield loss at DHW/Figures/Figures_prof"
)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
output_prefix <- file.path(output_dir, "Supplementary_Figure_4")
fig_width_cm <- 18
fig_height_cm <- 14

filter_manifest <- data.frame(
  stage = c("joined", "complete cases", "recognized HDW types in long data"),
  rows = c(nrow(Data_HDW_PY), nrow(Data_HDW_PY_nao), nrow(df_long)),
  rule = c(
    "left_join by site and year",
    "na.omit across all joined columns, as in the original code",
    "Type mapped to HTLH, PRGW or DTWD"
  ),
  stringsAsFactors = FALSE
)

utils::write.csv(
  median_df,
  paste0(output_prefix, "_median_check.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)
save(
  Wheat_DHW,
  Wheat_county_merged_final,
  Data_HDW_PY,
  Data_HDW_PY_nao,
  df_long,
  median_df,
  filter_manifest,
  file = paste0(output_prefix, "_source_data.RData")
)

if (!identical(Sys.getenv("HDW_SKIP_EXPORT"), "1")) {
  svglite::svglite(
    paste0(output_prefix, ".svg"),
    width = fig_width_cm / 2.54,
    height = fig_height_cm / 2.54,
    bg = "transparent",
    system_fonts = list(Arial = "Arial")
  )
  print(Supplementary_Figure_4_gg)
  grDevices::dev.off()

  grDevices::cairo_pdf(
    paste0(output_prefix, ".pdf"),
    width = fig_width_cm / 2.54,
    height = fig_height_cm / 2.54,
    family = "sans",
    bg = "transparent"
  )
  print(Supplementary_Figure_4_gg)
  grDevices::dev.off()

  ragg::agg_tiff(
    paste0(output_prefix, ".tiff"),
    width = fig_width_cm,
    height = fig_height_cm,
    units = "cm",
    res = 600,
    compression = "lzw",
    background = "white"
  )
  print(Supplementary_Figure_4_gg)
  grDevices::dev.off()

  ragg::agg_png(
    paste0(output_prefix, "_word_450dpi.png"),
    width = fig_width_cm,
    height = fig_height_cm,
    units = "cm",
    res = 450,
    background = "white"
  )
  print(Supplementary_Figure_4_gg)
  grDevices::dev.off()

  if (requireNamespace("devEMF", quietly = TRUE)) {
    devEMF::emf(
      paste0(output_prefix, ".emf"),
      units = "cm",
      width = fig_width_cm,
      height = fig_height_cm,
      pointsize = 11,
      family = figure_font
    )
    print(Supplementary_Figure_4_gg)
    grDevices::dev.off()
  }
}

Supplementary_Figure_4_gg
