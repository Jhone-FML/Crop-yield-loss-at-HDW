# Supplementary Figure 11: partial dependence of cost-related drivers

required_packages <- c("ggplot2", "cowplot", "svglite", "ragg")
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
]
if (length(missing_packages) > 0L) {
  stop(
    paste("Install required package(s):", paste(missing_packages, collapse = ", ")),
    call. = FALSE
  )
}
suppressPackageStartupMessages({
  library(ggplot2)
  library(cowplot)
})

required_objects <- c("Response", "Response_f")
missing_objects <- required_objects[
  !vapply(required_objects, exists, logical(1), inherits = TRUE)
]
if (length(missing_objects) > 0L) {
  stop(
    paste("Missing required object(s):", paste(missing_objects, collapse = ", ")),
    call. = FALSE
  )
}

required_columns <- function(data, columns, object_name) {
  missing_columns <- setdiff(columns, names(data))
  if (length(missing_columns) > 0L) {
    stop(
      paste(object_name, "is missing:", paste(missing_columns, collapse = ", ")),
      call. = FALSE
    )
  }
}
required_columns(Response, c("x", "y", "Variables", "ID"), "Response")
required_columns(Response_f, c("x", "y", "Variables", "ID"), "Response_f")

# Variables and order visible in the original Supplementary Figure 11.
cost_variables <- c("Fertilizer", "Irrigation", "Mechanization", "Seed")
curve_id_levels <- c(
  "HTLH_Early_change",
  "HTLH_Middle_change",
  "HTLH_Late_change",
  "PRGW_Early_change",
  "PRGW_Middle_change",
  "PRGW_Late_change"
)
curve_labels <- c(
  "HTLH-E", "HTLH-M", "HTLH-L",
  "PRGW-E", "PRGW-M", "PRGW-L"
)
curve_colours <- c(
  "#66C2A5", "#FC8D62", "#8DA0CB",
  "#E78AC3", "#A6D854", "#FFD92F"
)
names(curve_labels) <- curve_id_levels
names(curve_colours) <- curve_id_levels

prepare_response_data <- function(data, source_name) {
  keep_variable <- !is.na(data$Variables) &
    data$Variables %in% cost_variables
  selected <- data[keep_variable, , drop = FALSE]

  finite_pair <- is.finite(selected$x) & is.finite(selected$y)
  plotted <- selected[finite_pair, , drop = FALSE]
  plotted$Variables_display <- factor(
    as.character(plotted$Variables),
    levels = cost_variables
  )
  plotted$ID_display <- factor(
    unname(curve_labels[as.character(plotted$ID)]),
    levels = unname(curve_labels)
  )

  unmatched_ids <- unique(
    as.character(plotted$ID)[is.na(plotted$ID_display)]
  )
  unmatched_ids <- unmatched_ids[!is.na(unmatched_ids)]
  if (length(unmatched_ids) > 0L) {
    stop(
      paste(
        source_name,
        "contains unmapped ID value(s):",
        paste(unmatched_ids, collapse = ", ")
      ),
      call. = FALSE
    )
  }
  if (nrow(plotted) == 0L) {
    stop(paste(source_name, "has no plottable rows."), call. = FALSE)
  }

  list(
    data = plotted,
    manifest = data.frame(
      source_object = source_name,
      input_rows = nrow(data),
      selected_cost_rows = nrow(selected),
      plotted_rows = nrow(plotted),
      excluded_other_variables = sum(!keep_variable),
      excluded_non_finite = sum(!finite_pair),
      variable_rule = paste(cost_variables, collapse = ", "),
      stringsAsFactors = FALSE
    )
  )
}

county_prepared <- prepare_response_data(Response, "Response")
field_prepared <- prepare_response_data(Response_f, "Response_f")
Response_county_plot <- county_prepared$data
Response_field_plot <- field_prepared$data
filter_manifest <- rbind(
  county_prepared$manifest,
  field_prepared$manifest
)

# Publication font: Arial-compatible Helvetica/sans-serif fallback.
figure_font_family <- "sans"
font_panel_title <- 10
font_strip <- 9
font_axis_text <- 8.5
font_axis_title <- 9.5
font_legend <- 8

common_colour_scale <- scale_colour_manual(
  name = NULL,
  values = setNames(curve_colours, curve_labels),
  breaks = curve_labels,
  drop = FALSE
)

common_theme <- theme_bw(
  base_family = figure_font_family,
  base_size = font_axis_text
) +
  theme(
    strip.text = element_text(size = font_strip, colour = "black"),
    axis.text.x = element_text(size = font_axis_text),
    axis.text.y = element_text(size = font_axis_text),
    axis.title = element_text(size = font_axis_title, colour = "black"),
    panel.spacing.x = grid::unit(0.22, "cm"),
    strip.background = element_rect(colour = "transparent"),
    plot.background = element_rect(fill = "transparent", colour = NA),
    plot.margin = margin(2, 3, 2, 3, unit = "mm")
  )

county_base <- ggplot(
  Response_county_plot,
  aes(x = x, y = y, colour = ID_display, group = ID_display)
) +
  geom_line(linewidth = 0.70) +
  facet_wrap(
    ~Variables_display,
    ncol = 4,
    scales = "free_x",
    drop = FALSE
  ) +
  common_colour_scale +
  labs(
    x = "Trend of cost\u00A0(CNY year\u207B\u00B9 kg\u207B\u00B9 ha)",
    y = expression(
      italic(beta)[HDW %*% year]~(kg~ha^-1~hour^-1~year^-1)
    ),
    title = "(a) Partial dependence of the drivers at the county scale"
  ) +
  common_theme +
  theme(
    plot.title = element_text(
      size = font_panel_title,
      hjust = 0,
      margin = margin(b = 3)
    )
  )

field_base <- ggplot(
  Response_field_plot,
  aes(x = x, y = y, colour = ID_display, group = ID_display)
) +
  geom_line(linewidth = 0.70) +
  facet_wrap(
    ~Variables_display,
    ncol = 4,
    scales = "free_x",
    drop = FALSE
  ) +
  common_colour_scale +
  labs(
    x = "Trend of cost\u00A0(CNY year\u207B\u00B9 kg\u207B\u00B9 ha)",
    y = expression(
      italic(beta)[HDW %*% year]~(kg~ha^-1~hour^-1~year^-1)
    ),
    title = "(b) Partial dependence of the drivers at the field scale"
  ) +
  common_theme +
  theme(
    plot.title = element_text(
      size = font_panel_title,
      hjust = 0,
      margin = margin(b = 3)
    ),
    legend.position = "none"
  )

shared_legend <- cowplot::get_legend(
  county_base +
    guides(
      colour = guide_legend(
        nrow = 1,
        byrow = TRUE,
        override.aes = list(linewidth = 0.9)
      )
    ) +
    theme(
      legend.position = "top",
      legend.direction = "horizontal",
      legend.justification = "center",
      legend.text = element_text(size = font_legend),
      legend.key.width = grid::unit(0.42, "cm"),
      legend.key.height = grid::unit(0.22, "cm"),
      legend.margin = margin(0, 0, 0, 0),
      plot.margin = margin(0, 0, 0, 0)
    )
)

county_panel <- county_base + theme(legend.position = "none")

Supplementary_Figure_11_gg <- cowplot::plot_grid(
  shared_legend,
  county_panel,
  field_base,
  ncol = 1,
  rel_heights = c(0.075, 0.4625, 0.4625),
  align = "v",
  axis = "lr"
)

skip_figure_export <- identical(Sys.getenv("HDW_SKIP_EXPORT"), "1")
if (!skip_figure_export) {
  output_dir <- Sys.getenv(
    "HDW_FIGURE_OUTPUT_DIR",
    unset = "D:/Crop yield loss at DHW/Figures/Figures_prof"
  )
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  source_data_dir <- file.path(output_dir, "Source data")
  dir.create(source_data_dir, recursive = TRUE, showWarnings = FALSE)

  plot_configuration <- list(
    cost_variables = cost_variables,
    curve_id_levels = curve_id_levels,
    curve_labels = curve_labels,
    curve_colours = curve_colours
  )
  save(
    Response,
    Response_f,
    Response_county_plot,
    Response_field_plot,
    filter_manifest,
    plot_configuration,
    file = file.path(
      source_data_dir,
      "Supplementary_Figure_11_source_data.RData"
    ),
    version = 2
  )

  output_prefix <- file.path(output_dir, "Supplementary_Figure_11")
  fig_width_cm <- 18
  fig_height_cm <- 17
  fig_width_in <- fig_width_cm / 2.54
  fig_height_in <- fig_height_cm / 2.54

  svglite::svglite(
    paste0(output_prefix, ".svg"),
    width = fig_width_in,
    height = fig_height_in,
    bg = "transparent"
  )
  print(Supplementary_Figure_11_gg)
  dev.off()

  grDevices::cairo_pdf(
    paste0(output_prefix, ".pdf"),
    width = fig_width_in,
    height = fig_height_in,
    family = figure_font_family,
    bg = "transparent",
    fallback_resolution = 600
  )
  print(Supplementary_Figure_11_gg)
  dev.off()

  ragg::agg_tiff(
    paste0(output_prefix, ".tiff"),
    width = fig_width_cm,
    height = fig_height_cm,
    units = "cm",
    res = 600,
    compression = "lzw",
    background = "white"
  )
  print(Supplementary_Figure_11_gg)
  dev.off()

  word_dpi <- 450
  ragg::agg_png(
    paste0(output_prefix, "_word_", word_dpi, "dpi.png"),
    width = fig_width_cm,
    height = fig_height_cm,
    units = "cm",
    res = word_dpi,
    background = "white"
  )
  print(Supplementary_Figure_11_gg)
  dev.off()

  if (requireNamespace("devEMF", quietly = TRUE)) {
    devEMF::emf(
      paste0(output_prefix, ".emf"),
      width = fig_width_in,
      height = fig_height_in,
      family = figure_font_family,
      pointsize = 11,
      coordDPI = 600,
      emfPlus = TRUE
    )
    print(Supplementary_Figure_11_gg)
    dev.off()
  }
}
