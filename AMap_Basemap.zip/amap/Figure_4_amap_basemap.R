library(ggplot2)
library(grid)
library(RColorBrewer)
library(sf)

# -----------------------------------------------------------------------------
# Figure settings retained from the current user version
# -----------------------------------------------------------------------------

figure_font_family <- "Arial"
font_subtitle <- 10
font_strip <- 8
font_legend <- 7

# Display PRWD as PRGW in facet strips without modifying the source data.
HDW_map_facet_labeller <- function(labels) {
  labels[] <- lapply(
    labels,
    function(x) gsub("PRWD", "PRGW", as.character(x), fixed = TRUE)
  )
  label_value(labels)
}

# -----------------------------------------------------------------------------
# Read the new public basemap
# -----------------------------------------------------------------------------

amap_dir <- "D:/Crop yield loss at DHW/amap"
amap_country_file <- file.path(amap_dir, "land", "100000.geojson")
amap_province_dir <- file.path(amap_dir, "province_land")
amap_maritime_file <- file.path(amap_dir, "maritime", "100000.geojson")

required_map_paths <- c(
  amap_country_file,
  amap_province_dir,
  amap_maritime_file
)
missing_map_paths <- required_map_paths[!file.exists(required_map_paths)]

if (length(missing_map_paths) > 0) {
  stop(
    paste(
      "The new basemap is incomplete. Missing:",
      paste(missing_map_paths, collapse = "; ")
    ),
    call. = FALSE
  )
}

amap_province_files <- sort(list.files(
  amap_province_dir,
  pattern = "[.]geojson$",
  full.names = TRUE
))

if (length(amap_province_files) != 34L) {
  stop(
    paste(
      "Expected 34 province-level GeoJSON files, but found",
      length(amap_province_files),
      "in", amap_province_dir
    ),
    call. = FALSE
  )
}

amap_country_wgs84 <- sf::st_read(amap_country_file, quiet = TRUE)
amap_provinces_wgs84 <- do.call(
  rbind,
  lapply(amap_province_files, sf::st_read, quiet = TRUE)
)
amap_maritime_wgs84 <- sf::st_read(amap_maritime_file, quiet = TRUE)

assert_map_layer <- function(x, object_name) {
  if (!inherits(x, "sf") || nrow(x) == 0) {
    stop(paste(object_name, "is empty or is not an sf object."), call. = FALSE)
  }
  if (is.na(sf::st_crs(x))) {
    stop(paste(object_name, "has no CRS."), call. = FALSE)
  }
  if (!all(sf::st_is_valid(x))) {
    stop(paste(object_name, "contains invalid geometry."), call. = FALSE)
  }
  invisible(TRUE)
}

assert_map_layer(amap_country_wgs84, "amap_country_wgs84")
assert_map_layer(amap_provinces_wgs84, "amap_provinces_wgs84")
assert_map_layer(amap_maritime_wgs84, "amap_maritime_wgs84")

# -----------------------------------------------------------------------------
# Align the new basemap with the yield-effect data
# -----------------------------------------------------------------------------

if (!exists("CMFD_freqs_means_sf_jion", inherits = TRUE)) {
  stop(
    "CMFD_freqs_means_sf_jion is not present in the current R session.",
    call. = FALSE
  )
}

if (!inherits(CMFD_freqs_means_sf_jion, "sf")) {
  stop("CMFD_freqs_means_sf_jion must be an sf object.", call. = FALSE)
}

required_effect_columns <- c("effects", "Model", "Type")
missing_effect_columns <- setdiff(
  required_effect_columns,
  names(CMFD_freqs_means_sf_jion)
)

if (length(missing_effect_columns) > 0) {
  stop(
    paste(
      "CMFD_freqs_means_sf_jion is missing:",
      paste(missing_effect_columns, collapse = ", ")
    ),
    call. = FALSE
  )
}

map_crs <- sf::st_crs(CMFD_freqs_means_sf_jion)

if (is.na(map_crs)) {
  stop("CMFD_freqs_means_sf_jion has no CRS.", call. = FALSE)
}

if (sf::st_is_longlat(map_crs)) {
  stop(
    "The inset transformation requires the projected CRS used by the main map.",
    call. = FALSE
  )
}

effects_map <- CMFD_freqs_means_sf_jion
amap_country_map <- sf::st_transform(amap_country_wgs84, map_crs)
amap_province_map <- sf::st_transform(amap_provinces_wgs84, map_crs)
amap_maritime_map <- sf::st_transform(amap_maritime_wgs84, map_crs)

# SVG stores every boundary vertex as text. The new high-resolution basemap is
# therefore simplified only in temporary plotting copies. Attribute values and
# the original geometries saved as Source Data remain unchanged.
map_units <- tolower(sf::st_crs(map_crs)$units_gdal)
if (is.null(map_units) || is.na(map_units) ||
    !map_units %in% c("metre", "meter", "metres", "meters")) {
  stop(
    "The plotting CRS must use metre units before geometry simplification.",
    call. = FALSE
  )
}

plot_simplify_tolerance_m <- 1500

simplify_for_plot <- function(x, tolerance_m) {
  simplified <- suppressWarnings(sf::st_simplify(
    x,
    dTolerance = tolerance_m,
    preserveTopology = TRUE
  ))

  if (!all(sf::st_is_valid(simplified))) {
    stop(
      "Geometry simplification created an invalid plotting geometry.",
      call. = FALSE
    )
  }
  simplified
}

effects_plot_map <- simplify_for_plot(
  effects_map,
  plot_simplify_tolerance_m
)
amap_country_plot_map <- simplify_for_plot(
  amap_country_map,
  plot_simplify_tolerance_m
)
amap_province_plot_map <- simplify_for_plot(
  amap_province_map,
  plot_simplify_tolerance_m
)
amap_maritime_plot_map <- simplify_for_plot(
  amap_maritime_map,
  plot_simplify_tolerance_m
)

# Boundary lines are created before cropping. This preserves the real coast and
# avoids producing an artificial horizontal line at the crop boundary.
amap_country_boundary_map <- sf::st_boundary(amap_country_plot_map)
amap_province_boundary_map <- sf::st_boundary(amap_province_plot_map)

# -----------------------------------------------------------------------------
# Keep the data-bearing region large in the main panels
# -----------------------------------------------------------------------------

main_x_limits <- c(-2700000, 2900000)
main_y_upper_limit <- 6400000
main_y_padding <- 100000

finite_effect_rows <- is.finite(effects_map$effects)
if (!any(finite_effect_rows)) {
  stop("No finite yield-effect values are available for the map.", call. = FALSE)
}

effects_bbox <- sf::st_bbox(
  effects_map[finite_effect_rows, , drop = FALSE]
)

main_y_lower_limit <- max(
  3750000,
  unname(effects_bbox["ymin"]) - main_y_padding
)

if (!is.finite(main_y_lower_limit) || main_y_lower_limit >= main_y_upper_limit) {
  stop("Unable to determine a valid main-map y extent.", call. = FALSE)
}

main_y_limits <- c(main_y_lower_limit, main_y_upper_limit)

# -----------------------------------------------------------------------------
# Build one lower-right inset: omitted southern land + maritime line
# -----------------------------------------------------------------------------

full_reference_layers <- list(
  amap_country_boundary_map,
  amap_province_boundary_map,
  amap_maritime_plot_map
)

full_bbox_matrix <- do.call(
  rbind,
  lapply(full_reference_layers, function(x) as.numeric(sf::st_bbox(x)))
)

full_map_bbox <- c(
  xmin = min(full_bbox_matrix[, 1], na.rm = TRUE),
  ymin = min(full_bbox_matrix[, 2], na.rm = TRUE),
  xmax = max(full_bbox_matrix[, 3], na.rm = TRUE),
  ymax = max(full_bbox_matrix[, 4], na.rm = TRUE)
)

omitted_source_extent <- c(
  xmin = unname(full_map_bbox["xmin"]),
  ymin = unname(full_map_bbox["ymin"]),
  xmax = unname(full_map_bbox["xmax"]),
  ymax = main_y_limits[1]
)

crop_to_extent <- function(x, extent) {
  cropped <- suppressWarnings(sf::st_crop(
    x,
    xmin = unname(extent["xmin"]),
    ymin = unname(extent["ymin"]),
    xmax = unname(extent["xmax"]),
    ymax = unname(extent["ymax"])
  ))
  cropped[!sf::st_is_empty(cropped), , drop = FALSE]
}

country_south <- crop_to_extent(
  amap_country_boundary_map,
  omitted_source_extent
)
province_south <- crop_to_extent(
  amap_province_boundary_map,
  omitted_source_extent
)
maritime_south <- crop_to_extent(
  amap_maritime_plot_map,
  omitted_source_extent
)

inset_source_layers <- Filter(
  function(x) nrow(x) > 0,
  list(country_south, province_south, maritime_south)
)

if (length(inset_source_layers) == 0) {
  stop("No southern or maritime geometry was found for the inset.", call. = FALSE)
}

inset_bbox_matrix <- do.call(
  rbind,
  lapply(inset_source_layers, function(x) as.numeric(sf::st_bbox(x)))
)

inset_source_bbox <- c(
  xmin = min(inset_bbox_matrix[, 1], na.rm = TRUE),
  ymin = min(inset_bbox_matrix[, 2], na.rm = TRUE),
  xmax = max(inset_bbox_matrix[, 3], na.rm = TRUE),
  ymax = max(inset_bbox_matrix[, 4], na.rm = TRUE)
)

# Size the inset from the actual southern-map aspect ratio. This tightens the
# frame around its contents without changing the main-map x or y limits.
main_panel_width <- diff(main_x_limits)
main_panel_height <- diff(main_y_limits)
inset_source_width <- unname(
  inset_source_bbox["xmax"] - inset_source_bbox["xmin"]
)
inset_source_height <- unname(
  inset_source_bbox["ymax"] - inset_source_bbox["ymin"]
)

if (
  !all(is.finite(c(inset_source_width, inset_source_height))) ||
  inset_source_width <= 0 || inset_source_height <= 0
) {
  stop("Invalid source extent for the inset.", call. = FALSE)
}

inset_max_width_fraction <- 0.225
inset_max_height_fraction <- 0.27
inset_right_margin_fraction <- 0.012
inset_bottom_margin_fraction <- 0.03
inset_padding_fraction <- 0.025

inset_source_aspect <- inset_source_width / inset_source_height
inset_outer_aspect <- inset_source_aspect

inset_max_width <- inset_max_width_fraction * main_panel_width
inset_max_height <- inset_max_height_fraction * main_panel_height

# Fit the outer frame within both maxima while preserving the content aspect.
if (inset_max_width / inset_max_height > inset_outer_aspect) {
  inset_outer_height <- inset_max_height
  inset_outer_width <- inset_outer_height * inset_outer_aspect
} else {
  inset_outer_width <- inset_max_width
  inset_outer_height <- inset_outer_width / inset_outer_aspect
}

inset_xmax <- main_x_limits[2] -
  inset_right_margin_fraction * main_panel_width
inset_ymin <- main_y_limits[1] +
  inset_bottom_margin_fraction * main_panel_height

inset_outer_bbox <- c(
  xmin = inset_xmax - inset_outer_width,
  ymin = inset_ymin,
  xmax = inset_xmax,
  ymax = inset_ymin + inset_outer_height
)

inset_padding_x <- unname(
  inset_padding_fraction * diff(inset_outer_bbox[c("xmin", "xmax")])
)
inset_padding_y <- unname(
  inset_padding_fraction * diff(inset_outer_bbox[c("ymin", "ymax")])
)

inset_inner_bbox <- c(
  xmin = unname(inset_outer_bbox["xmin"]) + inset_padding_x,
  ymin = unname(inset_outer_bbox["ymin"]) + inset_padding_y,
  xmax = unname(inset_outer_bbox["xmax"]) - inset_padding_x,
  ymax = unname(inset_outer_bbox["ymax"]) - inset_padding_y
)

scale_sf_to_bbox <- function(x, source_bbox, target_bbox) {
  if (nrow(x) == 0) return(x)

  source_crs <- sf::st_crs(x)
  if (is.na(source_crs)) {
    stop("An inset source layer has no CRS.", call. = FALSE)
  }

  source_width <- as.numeric(source_bbox["xmax"] - source_bbox["xmin"])
  source_height <- as.numeric(source_bbox["ymax"] - source_bbox["ymin"])
  target_width <- as.numeric(target_bbox["xmax"] - target_bbox["xmin"])
  target_height <- as.numeric(target_bbox["ymax"] - target_bbox["ymin"])

  dimensions <- c(source_width, source_height, target_width, target_height)
  if (!all(is.finite(dimensions)) || any(dimensions <= 0)) {
    stop(
      paste(
        "Invalid source or target extent for the inset:",
        paste(signif(dimensions, 6), collapse = ", ")
      ),
      call. = FALSE
    )
  }

  scale_factor <- min(
    target_width / source_width,
    target_height / source_height
  )

  source_center <- unname(c(
    mean(source_bbox[c("xmin", "xmax")]),
    mean(source_bbox[c("ymin", "ymax")])
  ))
  target_center <- unname(c(
    mean(target_bbox[c("xmin", "xmax")]),
    mean(target_bbox[c("ymin", "ymax")])
  ))

  transformed_geometry <-
    (sf::st_geometry(x) - source_center) * scale_factor + target_center

  # Affine arithmetic can drop CRS metadata; coordinates remain in map_crs.
  transformed_geometry <- sf::st_set_crs(transformed_geometry, source_crs)
  sf::st_geometry(x) <- transformed_geometry
  x
}

make_bbox_sf <- function(bbox, crs) {
  coordinates <- matrix(
    c(
      bbox["xmin"], bbox["ymin"],
      bbox["xmax"], bbox["ymin"],
      bbox["xmax"], bbox["ymax"],
      bbox["xmin"], bbox["ymax"],
      bbox["xmin"], bbox["ymin"]
    ),
    ncol = 2,
    byrow = TRUE
  )

  sf::st_sf(
    geometry = sf::st_sfc(sf::st_polygon(list(coordinates)), crs = crs)
  )
}

country_south_inset <- scale_sf_to_bbox(
  country_south,
  inset_source_bbox,
  inset_inner_bbox
)
province_south_inset <- scale_sf_to_bbox(
  province_south,
  inset_source_bbox,
  inset_inner_bbox
)
maritime_south_inset <- scale_sf_to_bbox(
  maritime_south,
  inset_source_bbox,
  inset_inner_bbox
)
inset_outer_frame <- make_bbox_sf(inset_outer_bbox, map_crs)

inset_map_objects <- list(
  country_south_inset = country_south_inset,
  province_south_inset = province_south_inset,
  maritime_south_inset = maritime_south_inset,
  inset_outer_frame = inset_outer_frame
)

inset_objects_without_crs <- names(inset_map_objects)[vapply(
  inset_map_objects,
  function(x) is.na(sf::st_crs(x)),
  logical(1)
)]

if (length(inset_objects_without_crs) > 0) {
  stop(
    paste(
      "Inset objects without CRS:",
      paste(inset_objects_without_crs, collapse = ", ")
    ),
    call. = FALSE
  )
}

# -----------------------------------------------------------------------------
# Plot: original data, palette, facets and typography are retained
# -----------------------------------------------------------------------------

HDW_effects_sp_gg <- ggplot() +
  geom_sf(
    data = effects_plot_map,
    aes(fill = effects),
    color = "transparent",
    linewidth = 0.1
  ) +
  scale_fill_stepsn(
    colors = rev(brewer.pal(9, "RdPu")),
    breaks = c(-4000, seq(-500, -200, 100), seq(-100, 0, 10)),
    labels = c("", seq(-500, -200, 100), seq(-100, 0, 10)),
    limits = c(-4000, 0),
    na.value = "white",
    values = scales::rescale(
      c(-4000, seq(-500, -100, 100), seq(-100, 0, 10))
    ),
    name = bquote((kg ~ ha^-1 ~ season^-1))
  ) +
  labs(subtitle = bquote(Yield ~ loss ~ associated ~ with ~ HDW)) +
  facet_grid(Model ~ Type, labeller = HDW_map_facet_labeller) +
  theme_bw(base_family = figure_font_family, base_size = font_strip) +

  # The new province and national boundaries restore the Bohai and eastern
  # coastal outlines while leaving the yield-effect fill untouched.
  geom_sf(
    data = amap_province_boundary_map,
    color = "grey50",
    alpha = 0.9,
    linewidth = 0.10,
    inherit.aes = FALSE,
    show.legend = FALSE
  ) +
  geom_sf(
    data = amap_country_boundary_map,
    color = "grey45",
    alpha = 0.95,
    linewidth = 0.18,
    inherit.aes = FALSE,
    show.legend = FALSE
  ) +

  # One white backing and one outer frame only: there is no nested maritime box.
  geom_sf(
    data = inset_outer_frame,
    fill = "white",
    color = NA,
    inherit.aes = FALSE,
    show.legend = FALSE
  ) +
  geom_sf(
    data = province_south_inset,
    fill = NA,
    color = "grey55",
    linewidth = 0.08,
    inherit.aes = FALSE,
    show.legend = FALSE
  ) +
  geom_sf(
    data = country_south_inset,
    fill = NA,
    color = "grey45",
    linewidth = 0.16,
    inherit.aes = FALSE,
    show.legend = FALSE
  ) +
  geom_sf(
    data = maritime_south_inset,
    color = "grey45",
    linewidth = 0.14,
    inherit.aes = FALSE,
    show.legend = FALSE
  ) +
  geom_sf(
    data = inset_outer_frame,
    fill = NA,
    color = "grey45",
    linewidth = 0.22,
    inherit.aes = FALSE,
    show.legend = FALSE
  ) +
  coord_sf(
    xlim = main_x_limits,
    ylim = main_y_limits,
    expand = FALSE,
    datum = sf::st_crs(4326)
  ) +
  theme(
    plot.subtitle = element_text(
      size = font_subtitle,
      hjust = 0.02,
      vjust = 1.5,
      lineheight = 2
    ),
    strip.text = element_text(size = font_strip),
    legend.key.size = unit(1.7, "cm"),
    axis.ticks = element_blank(),
    axis.text = element_blank(),
    panel.grid.major = element_line(
      colour = "grey90",
      linewidth = 0.35
    ),
    panel.grid.minor = element_blank(),
    legend.position = c(0.68, 1.09),
    legend.direction = "horizontal",
    legend.key.height = unit(0.18, "cm"),
    legend.background = element_blank(),
    legend.text = element_text(size = font_legend),
    legend.title = element_text(size = font_legend),
    strip.background = element_rect(color = "transparent"),
    plot.background = element_rect(
      fill = "transparent",
      colour = NA_character_
    ),
    plot.margin = margin(1.5, 1.5, 0, 1.5, unit = "mm")
  )

# -----------------------------------------------------------------------------
# Save the original effect object and all new basemap objects in one RData file
# -----------------------------------------------------------------------------

skip_figure_export <- identical(Sys.getenv("HDW_SKIP_EXPORT"), "1")

if (!skip_figure_export) {
output_dir <- Sys.getenv(
  "HDW_FIGURE_OUTPUT_DIR",
  unset = "D:/Crop yield loss at DHW/Figures/Figures_prof"
)
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)

source_data_dir <- file.path(output_dir, "Source data")
dir.create(source_data_dir, showWarnings = FALSE, recursive = TRUE)

amap_source_manifest <- data.frame(
  role = c("country_land", "province_land", "maritime_line"),
  path = c(
    amap_country_file,
    paste(amap_province_files, collapse = ";"),
    amap_maritime_file
  ),
  stringsAsFactors = FALSE
)

figure_RV4_source_objects <- c(
  "CMFD_freqs_means_sf_jion",
  "amap_country_wgs84",
  "amap_provinces_wgs84",
  "amap_maritime_wgs84",
  "amap_source_manifest"
)

save(
  list = figure_RV4_source_objects,
  file = file.path(source_data_dir, "Figure_4_source_data.RData"),
  envir = environment(),
  version = 2
)

# -----------------------------------------------------------------------------
# Export every format at the same physical size
# -----------------------------------------------------------------------------

output_prefix <- file.path(output_dir, "Figure_4")
fig_width_cm <- 18
fig_height_cm <- 12.2
fig_width_in <- fig_width_cm / 2.54
fig_height_in <- fig_height_cm / 2.54

svglite::svglite(
  paste0(output_prefix, ".svg"),
  width = fig_width_in,
  height = fig_height_in,
  bg = "transparent"
)
print(HDW_effects_sp_gg)
dev.off()

grDevices::cairo_pdf(
  paste0(output_prefix, ".pdf"),
  width = fig_width_in,
  height = fig_height_in,
  family = figure_font_family,
  bg = "transparent",
  fallback_resolution = 600
)
print(HDW_effects_sp_gg)
dev.off()

ragg::agg_tiff(
  paste0(output_prefix, ".tiff"),
  width = fig_width_cm,
  height = fig_height_cm,
  units = "cm",
  res = 600,
  compression = "lzw",
  background = "white"
)
print(HDW_effects_sp_gg)
dev.off()

word_dpi <- 450
ragg::agg_png(
  paste0(output_prefix, "_word_", word_dpi, "dpi.png"),
  width = fig_width_cm,
  height = fig_height_cm,
  units = "cm",
  res = word_dpi,
  background = "white"
)
print(HDW_effects_sp_gg)
dev.off()

if (requireNamespace("devEMF", quietly = TRUE)) {
  devEMF::emf(
    paste0(output_prefix, ".emf"),
    width = fig_width_in,
    height = fig_height_in,
    family = figure_font_family,
    pointsize = 15,
    coordDPI = 600,
    emfPlus = TRUE
  )
  print(HDW_effects_sp_gg)
  dev.off()
}
}
