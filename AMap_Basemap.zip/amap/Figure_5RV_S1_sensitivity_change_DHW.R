# Figure 5RV_S1: changes in yield sensitivity to DHW

required_packages <- c("ggplot2", "ggdist", "RColorBrewer", "svglite", "ragg")
missing_packages <- required_packages[!vapply(
  required_packages, requireNamespace, logical(1), quietly = TRUE
)]
if (length(missing_packages) > 0) {
  stop(
    "Install the required package(s): ", paste(missing_packages, collapse = ", "),
    "\nRun: install.packages(c(",
    paste(sprintf('"%s"', missing_packages), collapse = ", "), "))",
    call. = FALSE
  )
}

if (!exists("Sens_fit_df_dhw_filtered", inherits = TRUE)) {
  stop("Sens_fit_df_dhw_filtered is missing.", call. = FALSE)
}
required_columns <- c("Breeding", "cols", "value", "fact")
missing_columns <- setdiff(required_columns, names(Sens_fit_df_dhw_filtered))
if (length(missing_columns) > 0) {
  stop(
    "Sens_fit_df_dhw_filtered is missing: ",
    paste(missing_columns, collapse = ", "),
    call. = FALSE
  )
}
if (!is.numeric(Sens_fit_df_dhw_filtered$value)) {
  stop("Sens_fit_df_dhw_filtered$value must be numeric.", call. = FALSE)
}

# Preserve the two filtering rules in the original code.
keep_rows <- with(
  Sens_fit_df_dhw_filtered,
  !is.na(Breeding) & Breeding == "No" &
    !is.na(cols) & !grepl("DTWD", cols, fixed = TRUE)
)
plot_data <- Sens_fit_df_dhw_filtered[keep_rows, , drop = FALSE]
if (nrow(plot_data) == 0) {
  stop("No observations remain after Breeding == 'No' and DTWD exclusion.", call. = FALSE)
}

x_levels <- c(
  "HTLH_Early", "HTLH_Middle", "HTLH_Late",
  "PRGW_Early", "PRGW_Middle", "PRGW_Late"
)
plot_data$cols <- factor(as.character(plot_data$cols), levels = x_levels)
if (!is.factor(plot_data$fact)) {
  plot_data$fact <- factor(plot_data$fact, levels = unique(plot_data$fact))
}

set2 <- RColorBrewer::brewer.pal(8, "Set2")
dhw_colours <- c(
  "HTLH_Early" = set2[1],
  "HTLH_Middle" = set2[1],
  "HTLH_Late" = set2[1],
  "PRGW_Early" = set2[2],
  "PRGW_Middle" = set2[2],
  "PRGW_Late" = set2[2]
)
x_labels <- c(
  "HTLH_Early" = "HTLH-E",
  "HTLH_Middle" = "HTLH-M",
  "HTLH_Late" = "HTLH-L",
  "PRGW_Early" = "PRGW-E",
  "PRGW_Middle" = "PRGW-M",
  "PRGW_Late" = "PRGW-L"
)

# Publication font: Arial, with the device's sans-serif fallback if unavailable.
figure_font <- "Arial"

sens_change_DHW_gg <- ggplot2::ggplot(
  plot_data,
  ggplot2::aes(x = cols, y = value)
) +
  ggdist::stat_halfeye(
    ggplot2::aes(fill = cols),
    adjust = 0.6,
    width = 1,
    .width = 0,
    alpha = 0.6,
    justification = -0.10,
    point_colour = NA
  ) +
  ggdist::stat_pointinterval(
    ggplot2::aes(colour = cols),
    size = 1.25,
    position = ggplot2::position_dodge(width = 0.7, preserve = "single")
  ) +
  ggplot2::geom_hline(
    yintercept = 0,
    linewidth = 0.5,
    linetype = "dashed",
    colour = "black"
  ) +
  ggplot2::stat_summary(
    ggplot2::aes(label = after_stat(round(y, 1)), colour = cols),
    fun = mean,
    geom = "text",
    hjust = -0.12,
    vjust = 1.35,
    size = 3,
    show.legend = FALSE
  ) +
  ggplot2::scale_colour_manual(values = dhw_colours, drop = FALSE) +
  ggplot2::scale_fill_manual(values = dhw_colours, drop = FALSE) +
  ggplot2::scale_x_discrete(
    limits = x_levels,
    labels = x_labels,
    drop = FALSE
  ) +
  ggplot2::facet_wrap(~fact, scales = "free", ncol = 2) +
  ggplot2::labs(
    x = "Types of HDW across three phases in HD-MT",
    y = expression(
      atop(
        "Changes in yield sensitivity to DHW",
        "(" * kg~ha^{-1}~hour^{-1} * ")"
      )
    )
  ) +
  ggplot2::coord_cartesian(clip = "off") +
  ggplot2::theme_bw(base_family = figure_font, base_size = 9) +
  ggplot2::theme(
    strip.text = ggplot2::element_text(size = 9),
    strip.background = ggplot2::element_rect(fill = "grey85", colour = NA),
    axis.text.x = ggplot2::element_text(
      size = 8,
      angle = 45,
      hjust = 1,
      vjust = 1
    ),
    axis.text.y = ggplot2::element_text(size = 8),
    axis.title.x = ggplot2::element_text(size = 9.5, margin = ggplot2::margin(t = 5)),
    axis.title.y = ggplot2::element_text(
      size = 9.5,
      lineheight = 1.05,
      margin = ggplot2::margin(r = 8)
    ),
    legend.position = "none",
    panel.spacing.x = grid::unit(0.55, "cm"),
    panel.spacing.y = grid::unit(0.45, "cm"),
    plot.margin = ggplot2::margin(5, 7, 5, 8, unit = "mm"),
    plot.background = ggplot2::element_rect(fill = "transparent", colour = NA)
  )

# Preserve the original Figure 5RV_S1 dimensions in every output format.
output_dir <- Sys.getenv(
  "HDW_FIGURE_DIR",
  unset = "D:/Crop yield loss at DHW/Figures/Figures_prof"
)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
output_prefix <- file.path(output_dir, "Figure_5RV_S1")
fig_width_cm <- 14.8
fig_height_cm <- 18

filter_manifest <- data.frame(
  input_rows = nrow(Sens_fit_df_dhw_filtered),
  plotted_rows = nrow(plot_data),
  rule = "Breeding == 'No' and cols does not contain 'DTWD'",
  stringsAsFactors = FALSE
)
save(
  Sens_fit_df_dhw_filtered,
  plot_data,
  filter_manifest,
  dhw_colours,
  x_labels,
  file = paste0(output_prefix, "_source_data.RData")
)

if (!identical(Sys.getenv("HDW_SKIP_EXPORT"), "1")) {
  svglite::svglite(
    paste0(output_prefix, ".svg"),
    width = fig_width_cm / 2.54,
    height = fig_height_cm / 2.54,
    bg = "transparent",
    system_fonts = list(Arial = "Arial")
  )
  print(sens_change_DHW_gg)
  grDevices::dev.off()

  grDevices::cairo_pdf(
    paste0(output_prefix, ".pdf"),
    width = fig_width_cm / 2.54,
    height = fig_height_cm / 2.54,
    family = "sans",
    bg = "transparent"
  )
  print(sens_change_DHW_gg)
  grDevices::dev.off()

  ragg::agg_tiff(
    paste0(output_prefix, ".tiff"),
    width = fig_width_cm,
    height = fig_height_cm,
    units = "cm",
    res = 600,
    compression = "lzw",
    background = "white"
  )
  print(sens_change_DHW_gg)
  grDevices::dev.off()

  ragg::agg_png(
    paste0(output_prefix, "_word_450dpi.png"),
    width = fig_width_cm,
    height = fig_height_cm,
    units = "cm",
    res = 450,
    background = "white"
  )
  print(sens_change_DHW_gg)
  grDevices::dev.off()

  if (requireNamespace("devEMF", quietly = TRUE)) {
    devEMF::emf(
      paste0(output_prefix, ".emf"),
      units = "cm",
      width = fig_width_cm,
      height = fig_height_cm,
      pointsize = 11,
      family = figure_font
    )
    print(sens_change_DHW_gg)
    grDevices::dev.off()
  }
}

sens_change_DHW_gg
