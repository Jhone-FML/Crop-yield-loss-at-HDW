library(ggplot2)
library(cowplot)
library(ggtern)
library(dplyr)
library(tidyr)
library(sf)
library(readxl)
library(RColorBrewer)

# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------

EXDat_Mmer_DHW <- EXDat_Mmer_DHW %>%
  mutate(
    Group = if_else(Y_anomly < 0, "Yield loss", "Yield gain"),
    Y_anomly_pc = 100 * Y_anomly / Yield_S.x
  )

sites_all <- bind_rows(
  nexpourn_vars_sites[, c(1, 3, 125)],
  expourn_lossY_sites[, c(1, 4, 129)],
  expourn_gainY_sites[, c(1, 4, 129)]
)

sitstation <- read_excel("F:/Crop yield loss at DHW/sitstation.xls")
names(sitstation)[c(2, 9, 10)] <- c("site", "lat", "lon")

site_xy <- sitstation %>%
  select(site, lon, lat) %>%
  distinct(site, .keep_all = TRUE)

site_prop <- sites_all %>%
  count(site, group, name = "n") %>%
  group_by(site) %>%
  mutate(prop = n / sum(n)) %>%
  ungroup() %>%
  select(site, group, prop) %>%
  pivot_wider(names_from = group, values_from = prop, values_fill = 0) %>%
  left_join(site_xy, by = "site")

site_prop_sf <- st_as_sf(
  site_prop,
  coords = c("lon", "lat"),
  crs = 4326,
  remove = FALSE
)

# ---------------------------------------------------------------------------
# Shared settings
# ---------------------------------------------------------------------------

# Publication font: Arial-compatible Helvetica/sans-serif fallback.
figure_font_family <- "sans"
set2 <- brewer.pal(3, "Set2")
target_crs <- 4547

map_layers <- lapply(
  list(China_line, China_sea, Provience_line, Chian_frame),
  st_transform,
  crs = target_crs
)
site_prop_sf <- st_transform(site_prop_sf, target_crs)

cluster_cols <- setdiff(
  names(site_prop_sf),
  c("site", "lon", "lat", "geometry")
)
if (length(cluster_cols) != 3L) {
  stop("Exactly three cluster-proportion columns are required.", call. = FALSE)
}

mix_colour <- function(data, columns, palette) {
  z <- as.matrix(st_drop_geometry(data)[, columns, drop = FALSE])
  total <- rowSums(z, na.rm = TRUE)
  if (any(!is.finite(total) | total <= 0)) {
    stop("Cluster proportions contain an invalid or zero total.", call. = FALSE)
  }
  z <- z / total
  rgb_matrix <- t(col2rgb(palette)) / 255
  rgb_values <- z %*% rgb_matrix
  rgb(rgb_values[, 1], rgb_values[, 2], rgb_values[, 3])
}
site_prop_sf$point_colour <- mix_colour(site_prop_sf, cluster_cols, set2)

# ---------------------------------------------------------------------------
# Pie charts and boxplot
# ---------------------------------------------------------------------------

pie_theme <- theme_void(base_family = figure_font_family) +
  theme(
    plot.subtitle = element_text(size = 8, hjust = 0.5, lineheight = 1),
    legend.position = "bottom",
    legend.text = element_text(size = 6.5),
    legend.key.height = unit(0.22, "cm"),
    legend.margin = margin(0, 0, 0, 0),
    plot.margin = margin(1, 1, 1, 1, unit = "mm"),
    plot.background = element_rect(fill = "transparent", colour = NA)
  )

make_pie <- function(data, group_name, subtitle) {
  ggplot(
    filter(data, Group == group_name),
    aes(x = "", y = value, fill = Type)
  ) +
    geom_col(width = 1, colour = "white", linewidth = 0.2) +
    geom_text(
      aes(label = sprintf("%.1f", value)),
      position = position_stack(vjust = 0.5),
      size = 2.7
    ) +
    coord_polar(theta = "y") +
    scale_fill_brewer(palette = "Set2", name = NULL) +
    labs(subtitle = subtitle) +
    pie_theme
}

PC_CUL_gg1 <- make_pie(
  PC_CUL,
  "Percentage of varieties under DHW exposure",
  "Percentage of varieties\nunder DHW exposure (%)"
)
PC_CUL_gg2 <- make_pie(
  PC_CUL,
  "Percentage of varieties in yield loss attributed to DHW",
  "Percentage of varieties in\nyield loss attributed to DHW (%)"
)

EX_Y_anomly_gg <- ggplot(
  EXDat_Mmer_DHW,
  aes(x = Group, y = Y_anomly_pc, fill = Group)
) +
  geom_boxplot(
    width = 0.5,
    outlier.shape = NA,
    linewidth = 0.5
  ) +
  geom_hline(
    yintercept = 0,
    linewidth = 0.5,
    linetype = "dashed"
  ) +
  stat_summary(
    aes(label = after_stat(sprintf("%.1f", y))),
    fun = mean,
    geom = "text",
    colour = "red",
    size = 2.7,
    vjust = -1.2
  ) +
  scale_fill_brewer(palette = "Set2") +
  coord_cartesian(ylim = c(-25, 25)) +
  scale_y_continuous(breaks = seq(-25, 25, 5)) +
  labs(
    x = NULL,
    y = "Changes in yield of variety\nclusters with HDW exposure (%)"
  ) +
  theme_minimal(base_family = figure_font_family, base_size = 8) +
  theme(
    axis.text = element_text(size = 7.5, colour = "black"),
    axis.title = element_text(size = 8.5, colour = "black"),
    legend.position = "none",
    panel.grid = element_blank(),
    plot.margin = margin(2, 2, 2, 2, unit = "mm"),
    plot.background = element_rect(fill = "transparent", colour = NA)
  )

# ---------------------------------------------------------------------------
# Map and ternary key
# ---------------------------------------------------------------------------

HDW_map_gg <- ggplot() +
  geom_sf(
    data = site_prop_sf,
    aes(colour = point_colour),
    size = 2
  ) +
  scale_colour_identity() +
  lapply(
    map_layers,
    function(x) geom_sf(data = x, colour = "grey65", linewidth = 0.2)
  ) +
  coord_sf(
    xlim = c(-2900000, 1900000),
    ylim = c(3500000, 5950000),
    expand = FALSE
  ) +
  theme_bw(base_family = figure_font_family) +
  theme(
    axis.text = element_blank(),
    axis.ticks = element_blank(),
    axis.title = element_blank(),
    legend.position = "none",
    plot.margin = margin(0, 0, 0, 0),
    plot.background = element_rect(fill = "transparent", colour = NA)
  )

tern_grid <- expand.grid(
  c1 = seq(0, 1, length.out = 40),
  c2 = seq(0, 1, length.out = 40)
) %>%
  mutate(c3 = 1 - c1 - c2) %>%
  filter(c3 >= 0)

tern_rgb <- as.matrix(tern_grid[, c("c1", "c2", "c3")]) %*%
  (t(col2rgb(set2)) / 255)
tern_grid$colour <- rgb(tern_rgb[, 1], tern_rgb[, 2], tern_rgb[, 3])

ternary_key <- ggtern(
  tern_grid,
  aes(x = c1, y = c2, z = c3, colour = colour)
) +
  geom_point(size = 1.5) +
  scale_colour_identity() +
  labs(L = cluster_cols[1], T = cluster_cols[2], R = cluster_cols[3]) +
  theme_void(base_family = figure_font_family) +
  theme(
    tern.axis.title = element_text(size = 5.5, colour = "black"),
    plot.margin = margin(1, 1, 1, 1, unit = "mm"),
    plot.background = element_rect(fill = "transparent", colour = NA)
  )

# Original layout, expressed once with stable relative coordinates.
Figure_5RV_s1_gg <- ggdraw() +
  draw_plot(HDW_map_gg, x = 0, y = 0, width = 1, height = 1) +
  draw_plot(PC_CUL_gg1, x = 0.06, y = 0.48, width = 0.22, height = 0.50) +
  draw_plot(PC_CUL_gg2, x = 0.06, y = 0.03, width = 0.22, height = 0.50) +
  draw_plot(EX_Y_anomly_gg, x = 0.40, y = 0.44, width = 0.28, height = 0.48) +
  draw_plot(ternary_key, x = 0.86, y = 0.08, width = 0.11, height = 0.18)

# ---------------------------------------------------------------------------
# Source data and same-size exports
# ---------------------------------------------------------------------------

output_dir <- "D:/Crop yield loss at DHW/Figures/Figures_prof"
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(output_dir, "Source data"), showWarnings = FALSE)

save(
  EXDat_Mmer_DHW,
  PC_CUL,
  nexpourn_vars_sites,
  expourn_lossY_sites,
  expourn_gainY_sites,
  sitstation,
  sites_all,
  site_prop,
  site_prop_sf,
  file = file.path(
    output_dir,
    "Source data",
    "Figure 5RV s1_source_data.RData"
  ),
  version = 2
)

output_prefix <- file.path(output_dir, "Figure 5RV s1")
fig_width_cm <- 14.8
fig_height_cm <- 7.6
fig_width_in <- fig_width_cm / 2.54
fig_height_in <- fig_height_cm / 2.54

svglite::svglite(
  paste0(output_prefix, ".svg"),
  width = fig_width_in,
  height = fig_height_in,
  bg = "transparent"
)
print(Figure_5RV_s1_gg)
dev.off()

grDevices::cairo_pdf(
  paste0(output_prefix, ".pdf"),
  width = fig_width_in,
  height = fig_height_in,
  family = figure_font_family,
  bg = "transparent",
  fallback_resolution = 600
)
print(Figure_5RV_s1_gg)
dev.off()

ragg::agg_tiff(
  paste0(output_prefix, ".tiff"),
  width = fig_width_cm,
  height = fig_height_cm,
  units = "cm",
  res = 600,
  compression = "lzw",
  background = "white"
)
print(Figure_5RV_s1_gg)
dev.off()

ragg::agg_png(
  paste0(output_prefix, "_word_450dpi.png"),
  width = fig_width_cm,
  height = fig_height_cm,
  units = "cm",
  res = 450,
  background = "white"
)
print(Figure_5RV_s1_gg)
dev.off()

if (requireNamespace("devEMF", quietly = TRUE)) {
  devEMF::emf(
    paste0(output_prefix, ".emf"),
    width = fig_width_in,
    height = fig_height_in,
    family = figure_font_family,
    pointsize = 11,
    coordDPI = 600,
    emfPlus = TRUE
  )
  print(Figure_5RV_s1_gg)
  dev.off()
}
