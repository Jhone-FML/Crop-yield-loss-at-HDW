library(ggplot2)
library(cowplot)
library(ggtern)
library(dplyr)
library(tidyr)
library(sf)
library(readxl)
library(RColorBrewer)

# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------

EXDat_Mmer_DHW <- EXDat_Mmer_DHW %>%
  mutate(
    Group = if_else(Y_anomly < 0, "Yield loss", "Yield gain"),
    Y_anomly_pc = 100 * Y_anomly / Yield_S.x
  )
boxplot_finite <- !is.na(EXDat_Mmer_DHW$Group) &
  is.finite(EXDat_Mmer_DHW$Y_anomly_pc)
boxplot_in_range <- boxplot_finite &
  EXDat_Mmer_DHW$Y_anomly_pc >= -25 &
  EXDat_Mmer_DHW$Y_anomly_pc <= 25
EXDat_Mmer_DHW_plot <- EXDat_Mmer_DHW[
  boxplot_in_range,
  ,
  drop = FALSE
]
boxplot_filter_manifest <- data.frame(
  input_rows = nrow(EXDat_Mmer_DHW),
  plotted_rows = nrow(EXDat_Mmer_DHW_plot),
  excluded_non_finite_rows = sum(!boxplot_finite),
  excluded_outside_range_rows = sum(boxplot_finite & !boxplot_in_range),
  rule = "Finite Y_anomly_pc within [-25, 25], matching the original figure",
  stringsAsFactors = FALSE
)

sites_all <- bind_rows(
  nexpourn_vars_sites[, c(1, 3, 125)],
  expourn_lossY_sites[, c(1, 4, 129)],
  expourn_gainY_sites[, c(1, 4, 129)]
)

sitstation <- read_excel("F:/Crop yield loss at DHW/sitstation.xls")
names(sitstation)[c(2, 9, 10)] <- c("site", "lat", "lon")

site_xy <- sitstation %>%
  select(site, lon, lat) %>%
  distinct(site, .keep_all = TRUE)

site_prop <- sites_all %>%
  count(site, group, name = "n") %>%
  group_by(site) %>%
  mutate(prop = n / sum(n)) %>%
  ungroup() %>%
  select(site, group, prop) %>%
  pivot_wider(names_from = group, values_from = prop, values_fill = 0) %>%
  left_join(site_xy, by = "site")

site_prop_sf <- st_as_sf(
  site_prop,
  coords = c("lon", "lat"),
  crs = 4326,
  remove = FALSE
)

# ---------------------------------------------------------------------------
# Shared settings
# ---------------------------------------------------------------------------

# Publication font: Arial-compatible Helvetica/sans-serif fallback.
figure_font_family <- "sans"
set2 <- brewer.pal(3, "Set2")
target_crs <- 4547

map_layers <- lapply(
  list(China_line, China_sea, Provience_line, Chian_frame),
  st_transform,
  crs = target_crs
)
site_prop_sf <- st_transform(site_prop_sf, target_crs)

cluster_cols <- setdiff(
  names(site_prop_sf),
  c("site", "lon", "lat", "geometry")
)
if (length(cluster_cols) != 3L) {
  stop("Exactly three cluster-proportion columns are required.", call. = FALSE)
}

mix_colour <- function(data, columns, palette) {
  z <- as.matrix(st_drop_geometry(data)[, columns, drop = FALSE])
  total <- rowSums(z, na.rm = TRUE)
  if (any(!is.finite(total) | total <= 0)) {
    stop("Cluster proportions contain an invalid or zero total.", call. = FALSE)
  }
  z <- z / total
  rgb_matrix <- t(col2rgb(palette)) / 255
  rgb_values <- z %*% rgb_matrix
  rgb(rgb_values[, 1], rgb_values[, 2], rgb_values[, 3])
}
site_prop_sf$point_colour <- mix_colour(site_prop_sf, cluster_cols, set2)

# ---------------------------------------------------------------------------
# Pie charts and boxplot
# ---------------------------------------------------------------------------

pie_theme <- theme_void(base_family = figure_font_family) +
  theme(
    plot.subtitle = element_text(size = 7.5, hjust = 0.5, lineheight = 1),
    legend.position = "bottom",
    legend.direction = "vertical",
    legend.text = element_text(size = 5.8),
    legend.key.width = unit(0.28, "cm"),
    legend.key.height = unit(0.18, "cm"),
    legend.margin = margin(0, 0, 0, 0),
    plot.margin = margin(1, 1, 1, 1, unit = "mm"),
    plot.background = element_rect(fill = "transparent", colour = NA)
  )

make_pie <- function(data, group_name, subtitle) {
  ggplot(
    filter(data, Group == group_name),
    aes(x = "", y = value, fill = Type)
  ) +
    geom_col(width = 1, colour = "white", linewidth = 0.2) +
    geom_text(
      aes(label = sprintf("%.1f", value)),
      position = position_stack(vjust = 0.5),
      size = 2.7
    ) +
    coord_polar(theta = "y") +
    scale_fill_brewer(
      palette = "Set2",
      name = NULL,
      guide = guide_legend(ncol = 1, byrow = TRUE)
    ) +
    labs(subtitle = subtitle) +
    pie_theme
}

PC_CUL_gg1 <- make_pie(
  PC_CUL,
  "Percentage of varieties under DHW exposure",
  "Percentage of varieties\nunder DHW exposure (%)"
)
PC_CUL_gg2 <- make_pie(
  PC_CUL,
  "Percentage of varieties in yield loss attributed to DHW",
  "Percentage of varieties in\nyield loss attributed to DHW (%)"
)

EX_Y_anomly_gg <- ggplot(
  EXDat_Mmer_DHW_plot,
  aes(x = Group, y = Y_anomly_pc, fill = Group)
) +
  geom_boxplot(
    width = 0.5,
    outlier.shape = NA,
    linewidth = 0.5
  ) +
  geom_hline(
    yintercept = 0,
    linewidth = 0.5,
    linetype = "dashed"
  ) +
  stat_summary(
    aes(label = after_stat(sprintf("%.1f", y))),
    fun = mean,
    geom = "text",
    colour = "red",
    size = 2.7,
    vjust = -1.2
  ) +
  scale_fill_brewer(palette = "Set2") +
  scale_x_discrete(expand = expansion(add = 0.45)) +
  scale_y_continuous(
    limits = c(-25, 25),
    breaks = seq(-25, 25, 5)
  ) +
  labs(
    x = NULL,
    y = "Changes in yield of variety\nclusters with HDW exposure (%)"
  ) +
  theme_minimal(base_family = figure_font_family, base_size = 8) +
  theme(
    axis.text = element_text(size = 7.2, colour = "black"),
    axis.text.x = element_text(margin = margin(t = 2)),
    axis.title = element_text(size = 8, colour = "black"),
    axis.title.y = element_text(
      size = 7,
      lineheight = 0.90,
      margin = margin(r = 1)
    ),
    legend.position = "none",
    panel.grid = element_blank(),
    plot.margin = margin(2, 1, 2, 5, unit = "mm"),
    plot.background = element_rect(fill = "transparent", colour = NA)
  )

# ---------------------------------------------------------------------------
# Map and ternary key
# ---------------------------------------------------------------------------

HDW_map_gg <- ggplot() +
  geom_sf(
    data = site_prop_sf,
    aes(colour = point_colour),
    size = 2
  ) +
  scale_colour_identity() +
  lapply(
    map_layers,
    function(x) geom_sf(data = x, colour = "grey65", linewidth = 0.2)
  ) +
  coord_sf(
    xlim = c(-2900000, 1900000),
    ylim = c(3350000, 5950000),
    expand = FALSE
  ) +
  theme_bw(base_family = figure_font_family) +
  theme(
    axis.text = element_blank(),
    axis.ticks = element_blank(),
    axis.title = element_blank(),
    legend.position = "none",
    plot.margin = margin(0, 0, 0, 0),
    plot.background = element_rect(fill = "transparent", colour = NA)
  )

# Reuse the earlier AMap base layers for one combined southern-land and
# maritime inset. All content is placed inside a single frame.
amap_dir <- "D:/Crop yield loss at DHW/amap"
amap_country <- st_read(
  file.path(amap_dir, "land", "100000.geojson"),
  quiet = TRUE
) %>%
  st_transform(target_crs)
amap_province_files <- list.files(
  file.path(amap_dir, "province_land"),
  pattern = "\\.geojson$",
  full.names = TRUE
)
amap_provinces <- do.call(
  rbind,
  lapply(amap_province_files, st_read, quiet = TRUE)
) %>%
  st_transform(target_crs)
amap_maritime <- st_read(
  file.path(amap_dir, "maritime", "100000.geojson"),
  quiet = TRUE
) %>%
  st_transform(target_crs)

crop_south <- function(x, ymax = 3350000) {
  bbox <- st_bbox(x)
  out <- suppressWarnings(st_crop(
    x,
    xmin = unname(bbox[["xmin"]]),
    ymin = unname(bbox[["ymin"]]),
    xmax = unname(bbox[["xmax"]]),
    ymax = ymax
  ))
  out[!st_is_empty(out), , drop = FALSE]
}

country_south <- crop_south(
  st_boundary(st_simplify(amap_country, dTolerance = 5000))
)
province_south <- crop_south(
  st_boundary(st_simplify(amap_provinces, dTolerance = 5000))
)
maritime_south <- crop_south(amap_maritime)
south_layers <- Filter(
  function(x) nrow(x) > 0L,
  list(country_south, province_south, maritime_south)
)
south_bbox_values <- do.call(
  rbind,
  lapply(south_layers, function(x) as.numeric(st_bbox(x)))
)
south_bbox <- c(
  xmin = min(south_bbox_values[, 1]),
  ymin = min(south_bbox_values[, 2]),
  xmax = max(south_bbox_values[, 3]),
  ymax = max(south_bbox_values[, 4])
)

south_inset_gg <- ggplot() +
  geom_sf(
    data = province_south,
    fill = NA,
    colour = "grey60",
    linewidth = 0.12
  ) +
  geom_sf(
    data = country_south,
    fill = NA,
    colour = "grey45",
    linewidth = 0.22
  ) +
  geom_sf(
    data = maritime_south,
    colour = "grey45",
    linewidth = 0.18
  ) +
  coord_sf(
    xlim = south_bbox[c("xmin", "xmax")],
    ylim = south_bbox[c("ymin", "ymax")],
    expand = FALSE,
    datum = NA
  ) +
  theme_void(base_family = figure_font_family) +
  theme(
    panel.border = element_rect(
      fill = NA,
      colour = "grey45",
      linewidth = 0.45
    ),
    plot.margin = margin(0, 0, 0, 0),
    plot.background = element_rect(fill = "white", colour = NA)
  )

tern_grid <- expand.grid(
  c1 = seq(0, 1, length.out = 40),
  c2 = seq(0, 1, length.out = 40)
) %>%
  mutate(c3 = 1 - c1 - c2) %>%
  filter(c3 >= 0)

tern_rgb <- as.matrix(tern_grid[, c("c1", "c2", "c3")]) %*%
  (t(col2rgb(set2)) / 255)
tern_grid$colour <- rgb(tern_rgb[, 1], tern_rgb[, 2], tern_rgb[, 3])
cluster_labels <- c("Cluster 1", "Cluster 2", "Cluster 3")

ternary_key <- ggtern(
  tern_grid,
  aes(x = c1, y = c2, z = c3, colour = colour)
) +
  geom_point(size = 1.5) +
  scale_colour_identity() +
  labs(L = NULL, T = NULL, R = NULL) +
  theme_void(base_family = figure_font_family) +
  ggtern::theme_hidetitles() +
  ggtern::theme_hidelabels() +
  ggtern::theme_hideticks() +
  theme(
    plot.margin = margin(0, 0, 0, 0),
    plot.background = element_rect(fill = "transparent", colour = NA)
  )

# Original layout, expressed once with stable relative coordinates.
Supplementary_Figure_13_gg <- ggdraw() +
  draw_plot(HDW_map_gg, x = 0, y = 0, width = 1, height = 1) +
  draw_plot(PC_CUL_gg1, x = 0.06, y = 0.56, width = 0.22, height = 0.41) +
  draw_plot(PC_CUL_gg2, x = 0.06, y = 0.06, width = 0.22, height = 0.41) +
  draw_plot(EX_Y_anomly_gg, x = 0.42, y = 0.34, width = 0.30, height = 0.58) +
  draw_plot(ternary_key, x = 0.865, y = 0.285, width = 0.105, height = 0.16) +
  draw_label(
    cluster_labels[2],
    x = 0.9175, y = 0.46,
    size = 5.0, fontfamily = figure_font_family
  ) +
  draw_label(
    cluster_labels[1],
    x = 0.845, y = 0.275,
    hjust = 0, size = 5.0, fontfamily = figure_font_family
  ) +
  draw_label(
    cluster_labels[3],
    x = 0.975, y = 0.275,
    hjust = 1, size = 5.0, fontfamily = figure_font_family
  ) +
  draw_plot(
    south_inset_gg,
    x = 0.855, y = 0.035,
    width = 0.13, height = 0.20
  )

# ---------------------------------------------------------------------------
# Source data and same-size exports
# ---------------------------------------------------------------------------

output_dir <- "D:/Crop yield loss at DHW/Figures/Figures_prof"
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(output_dir, "Source data"), showWarnings = FALSE)

save(
  EXDat_Mmer_DHW,
  EXDat_Mmer_DHW_plot,
  boxplot_filter_manifest,
  PC_CUL,
  nexpourn_vars_sites,
  expourn_lossY_sites,
  expourn_gainY_sites,
  sitstation,
  sites_all,
  site_prop,
  site_prop_sf,
  amap_country,
  amap_provinces,
  amap_maritime,
  country_south,
  province_south,
  maritime_south,
  file = file.path(
    output_dir,
    "Source data",
    "Supplementary_Figure_13_source_data.RData"
  ),
  version = 2
)

output_prefix <- file.path(output_dir, "Supplementary_Figure_13")
# Match the projected map aspect ratio to remove lateral canvas padding.
fig_width_cm <- 14.0
fig_height_cm <- 7.6
fig_width_in <- fig_width_cm / 2.54
fig_height_in <- fig_height_cm / 2.54

svglite::svglite(
  paste0(output_prefix, ".svg"),
  width = fig_width_in,
  height = fig_height_in,
  bg = "transparent"
)
print(Supplementary_Figure_13_gg)
dev.off()

grDevices::cairo_pdf(
  paste0(output_prefix, ".pdf"),
  width = fig_width_in,
  height = fig_height_in,
  family = figure_font_family,
  bg = "transparent",
  fallback_resolution = 600
)
print(Supplementary_Figure_13_gg)
dev.off()

ragg::agg_tiff(
  paste0(output_prefix, ".tiff"),
  width = fig_width_cm,
  height = fig_height_cm,
  units = "cm",
  res = 600,
  compression = "lzw",
  background = "white"
)
print(Supplementary_Figure_13_gg)
dev.off()

ragg::agg_png(
  paste0(output_prefix, "_word_450dpi.png"),
  width = fig_width_cm,
  height = fig_height_cm,
  units = "cm",
  res = 450,
  background = "white"
)
print(Supplementary_Figure_13_gg)
dev.off()

if (requireNamespace("devEMF", quietly = TRUE)) {
  devEMF::emf(
    paste0(output_prefix, ".emf"),
    width = fig_width_in,
    height = fig_height_in,
    family = figure_font_family,
    pointsize = 11,
    coordDPI = 600,
    emfPlus = TRUE
  )
  print(Supplementary_Figure_13_gg)
  dev.off()
}
