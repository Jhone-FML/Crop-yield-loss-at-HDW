# Figure 7RV_s2: driver importance and partial-dependence responses

required_packages <- c(
  "ggplot2", "cowplot", "RColorBrewer", "svglite", "ragg"
)
missing_packages <- required_packages[!vapply(
  required_packages,
  requireNamespace,
  logical(1),
  quietly = TRUE
)]

if (length(missing_packages) > 0) {
  stop(
    paste0(
      "Install the required R package(s) first: ",
      paste(missing_packages, collapse = ", "),
      ".\nRun: install.packages(c(",
      paste(sprintf('"%s"', missing_packages), collapse = ", "),
      "))"
    ),
    call. = FALSE
  )
}

suppressPackageStartupMessages({
  library(ggplot2)
  library(cowplot)
})

# -----------------------------------------------------------------------------
# Input checks
# -----------------------------------------------------------------------------

required_objects <- c(
  "Importance2", "Response", "labels_ID", "col", "cols",
  "legend_levels", "legend_labels_char"
)
missing_objects <- required_objects[!vapply(
  required_objects,
  function(x) exists(x, inherits = TRUE),
  logical(1)
)]

if (length(missing_objects) > 0) {
  stop(
    paste(
      "Missing required object(s):",
      paste(missing_objects, collapse = ", ")
    ),
    call. = FALSE
  )
}

if (!is.character(col) || !is.character(cols)) {
  stop("col and cols must be character colour vectors.", call. = FALSE)
}

required_columns <- function(data, columns, object_name) {
  missing_columns <- setdiff(columns, names(data))
  if (length(missing_columns) > 0) {
    stop(
      paste(
        object_name, "is missing:",
        paste(missing_columns, collapse = ", ")
      ),
      call. = FALSE
    )
  }
}

required_columns(
  Importance2,
  c("percentage", "Feature", "ID"),
  "Importance2"
)
required_columns(
  Response,
  c("Variables", "Variables_parsed", "x", "y", "ID"),
  "Response"
)

# Keep the original exclusion rule used for panel (b).
excluded_management_variables <- c(
  "Fertilizer", "Irrigation", "Manure",
  "Mechanization", "Pesticide", "Seed"
)
response_keep <- !is.na(Response$Variables) &
  !Response$Variables %in% excluded_management_variables
Response_plot_data <- Response[response_keep, , drop = FALSE]

if (nrow(Importance2) == 0) {
  stop("Importance2 contains no rows.", call. = FALSE)
}
if (nrow(Response_plot_data) == 0) {
  stop("No rows remain for panel (b).", call. = FALSE)
}

filter_manifest <- data.frame(
  panel = c("a", "b"),
  source_object = c("Importance2", "Response"),
  input_rows = c(nrow(Importance2), nrow(Response)),
  plotted_rows = c(nrow(Importance2), nrow(Response_plot_data)),
  rule = c(
    "All rows",
    paste0(
      "Exclude Variables in: ",
      paste(excluded_management_variables, collapse = ", ")
    )
  ),
  stringsAsFactors = FALSE
)

# -----------------------------------------------------------------------------
# Unified typography at the intended 20 x 12 cm output size
# -----------------------------------------------------------------------------

# Use R's device-independent sans-serif family. On Windows screen/EMF devices
# this resolves to an Arial-compatible system font and remains safe on PDF
# devices that do not have Arial registered in the PostScript font database.
figure_font_family <- "sans"
font_panel_title <- 11
font_strip <- 9
font_axis_text <- 8.5
font_axis_title <- 9.5
font_legend <- 8
font_percentage <- 2.55

# -----------------------------------------------------------------------------
# Panel (a): XGBoost driver importance
# -----------------------------------------------------------------------------

# Use a plotting copy so the original data and its ID field are unchanged.
# The six displayed panels follow the order already present in Importance2.
importance_id_levels <- if (is.factor(Importance2$ID)) {
  levels(droplevels(Importance2$ID))
} else {
  unique(as.character(Importance2$ID))
}
importance_id_levels <- importance_id_levels[
  importance_id_levels %in% as.character(Importance2$ID)
]
importance_display_levels <- c(
  "HTLH-E", "HTLH-M", "HTLH-L",
  "PRGW-E", "PRGW-M", "PRGW-L"
)

if (length(importance_id_levels) != length(importance_display_levels)) {
  stop(
    paste0(
      "Panel (a) requires six ID panels, but Importance2 contains ",
      length(importance_id_levels), "."
    ),
    call. = FALSE
  )
}

importance_id_key <- data.frame(
  ID = importance_id_levels,
  ID_display = importance_display_levels,
  stringsAsFactors = FALSE
)
Importance_plot_data <- Importance2
Importance_plot_data$ID_display <- factor(
  importance_display_levels[
    match(as.character(Importance_plot_data$ID), importance_id_levels)
  ],
  levels = importance_display_levels
)

importance_feature_labels <- c(
  "Trends_HTLH_Early" = "HTLH-E",
  "Trends_HTLH_Middle" = "HTLH-M",
  "Trends_HTLH_Late" = "HTLH-L",
  "Trends_PRGW_Early" = "PRGW-E",
  "Trends_PRGW_Middle" = "PRGW-M",
  "Trends_PRGW_Late" = "PRGW-L"
)
importance_legend_labels <- function(x) {
  out <- as.character(x)
  replace <- out %in% names(importance_feature_labels)
  out[replace] <- unname(importance_feature_labels[out[replace]])
  out
}

Importance_gg <- ggplot(
  Importance_plot_data,
  aes(x = 1, y = percentage, fill = Feature)
) +
  geom_col(colour = "white", linewidth = 0.22, width = 1) +
  geom_text(
    aes(
      label = ifelse(
        percentage >= 1,
        paste0(round(percentage, 1), "%"),
        ""
      )
    ),
    position = position_stack(vjust = 0.5),
    colour = "white",
    size = font_percentage,
    lineheight = 0.95
  ) +
  facet_wrap(
    ~ID_display,
    ncol = 6,
    labeller = label_value,
    drop = FALSE
  ) +
  scale_fill_manual(
    name = NULL,
    values = c(
      col,
      c("gray66", "gray68", "gray70", "gray72", "gray74", "gray76")
    ),
    labels = importance_legend_labels,
    guide = guide_legend(
      ncol = 4,
      nrow = 3,
      byrow = TRUE
    )
  ) +
  labs(
    x = NULL,
    y = NULL,
    subtitle = paste0(
      "(a) Importance of drivers in XGBoost\n",
      "at the county scale"
    )
  ) +
  theme_bw(base_family = figure_font_family, base_size = font_axis_text) +
  theme(
    plot.subtitle = element_text(
      size = font_panel_title,
      lineheight = 0.95,
      margin = margin(b = 3)
    ),
    panel.spacing = grid::unit(0.10, "cm"),
    strip.text = element_text(
      size = 8.5,
      margin = margin(t = 2, b = 2)
    ),
    axis.text = element_blank(),
    axis.ticks = element_blank(),
    axis.title = element_blank(),
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.key.width = grid::unit(0.42, "cm"),
    legend.key.height = grid::unit(0.24, "cm"),
    legend.spacing.x = grid::unit(0.10, "cm"),
    legend.text = element_text(size = font_legend),
    legend.title = element_text(size = font_legend),
    legend.background = element_blank(),
    strip.background = element_rect(colour = "transparent"),
    plot.background = element_rect(fill = "transparent", colour = NA),
    plot.margin = margin(2, 3, 2, 3, unit = "mm")
  )

# -----------------------------------------------------------------------------
# Panel (b): partial-dependence curves
# -----------------------------------------------------------------------------

p_1 <- ggplot(
  Response_plot_data,
  aes(x = x, y = y, colour = ID)
) +
  geom_line(linewidth = 0.65) +
  facet_wrap(
    ~Variables_parsed,
    scales = "free_x",
    labeller = label_parsed,
    ncol = 3
  ) +
  scale_colour_manual(
    name = NULL,
    values = cols,
    breaks = legend_levels,
    labels = parse(text = legend_labels_char)
  ) +
  guides(
    colour = guide_legend(
      ncol = 1,
      byrow = TRUE,
      override.aes = list(linewidth = 0.75)
    )
  ) +
  labs(
    # Plain Unicode text is more reliable than plotmath after SVG is imported
    # into Word. The non-breaking space keeps HDW and the unit separated.
    x = "Trend of HDW\u00A0(hour year\u207B\u00B9)",
    y = expression(
      italic(beta)[HDW %*% year]~(kg~ha^-1~hour^-1~year^-1)
    ),
    subtitle = paste0(
      "(b) Partial dependence of the drivers\n",
      "at the county scale"
    )
  ) +
  theme_bw(base_family = figure_font_family, base_size = font_axis_text) +
  theme(
    plot.subtitle = element_text(
      size = font_panel_title,
      lineheight = 0.95,
      margin = margin(b = 3)
    ),
    strip.text = element_text(size = font_strip),
    axis.text.x = element_text(
      size = font_axis_text,
      angle = 45,
      vjust = 1,
      hjust = 1
    ),
    axis.text.y = element_text(size = font_axis_text),
    axis.title = element_text(size = font_axis_title),
    legend.position = "inside",
    legend.position.inside = c(0.025, 0.975),
    legend.justification = c(0, 1),
    legend.direction = "vertical",
    legend.key.width = grid::unit(0.38, "cm"),
    legend.key.height = grid::unit(0.20, "cm"),
    legend.spacing.y = grid::unit(0.01, "cm"),
    legend.text = element_text(size = font_legend),
    legend.title = element_text(size = font_legend),
    legend.background = element_blank(),
    strip.background = element_rect(colour = "transparent"),
    plot.background = element_rect(fill = "transparent", colour = NA),
    plot.margin = margin(2, 2, 2, 2, unit = "mm")
  )

# Give panel (a) enough horizontal room for six complete facet strips, its
# three-row legend, and its two-line title. Both panels retain equal height.
Figure_7RV_s2_gg <- cowplot::ggdraw() +
  cowplot::draw_plot(
    Importance_gg,
    x = 0,
    y = 0,
    width = 0.55,
    height = 1
  ) +
  cowplot::draw_plot(
    p_1,
    x = 0.55,
    y = 0,
    width = 0.45,
    height = 1
  )

# -----------------------------------------------------------------------------
# Source Data and consistent exports
# -----------------------------------------------------------------------------

skip_figure_export <- identical(Sys.getenv("HDW_SKIP_EXPORT"), "1")

if (!skip_figure_export) {
  output_dir <- Sys.getenv(
    "HDW_FIGURE_OUTPUT_DIR",
    unset = "D:/Crop yield loss at DHW/Figures/Figures_prof"
  )
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

  source_data_dir <- file.path(output_dir, "Source data")
  dir.create(source_data_dir, recursive = TRUE, showWarnings = FALSE)

  plot_configuration <- list(
    labels_ID = labels_ID,
    col = col,
    cols = cols,
    legend_levels = legend_levels,
    legend_labels_char = legend_labels_char
  )
  save(
    Importance2,
    Importance_plot_data,
    importance_id_key,
    Response,
    Response_plot_data,
    filter_manifest,
    plot_configuration,
    file = file.path(
      source_data_dir,
      "Figure_7RV_s2_source_data.RData"
    ),
    version = 2
  )

  output_prefix <- file.path(output_dir, "Figure_7RV_s2")
  fig_width_cm <- 20
  fig_height_cm <- 12
  fig_width_in <- fig_width_cm / 2.54
  fig_height_in <- fig_height_cm / 2.54

  svglite::svglite(
    paste0(output_prefix, ".svg"),
    width = fig_width_in,
    height = fig_height_in,
    bg = "transparent"
  )
  print(Figure_7RV_s2_gg)
  dev.off()

  grDevices::cairo_pdf(
    paste0(output_prefix, ".pdf"),
    width = fig_width_in,
    height = fig_height_in,
    family = figure_font_family,
    bg = "transparent",
    fallback_resolution = 600
  )
  print(Figure_7RV_s2_gg)
  dev.off()

  ragg::agg_tiff(
    paste0(output_prefix, ".tiff"),
    width = fig_width_cm,
    height = fig_height_cm,
    units = "cm",
    res = 600,
    compression = "lzw",
    background = "white"
  )
  print(Figure_7RV_s2_gg)
  dev.off()

  word_dpi <- 450
  ragg::agg_png(
    paste0(output_prefix, "_word_", word_dpi, "dpi.png"),
    width = fig_width_cm,
    height = fig_height_cm,
    units = "cm",
    res = word_dpi,
    background = "white"
  )
  print(Figure_7RV_s2_gg)
  dev.off()

  if (requireNamespace("devEMF", quietly = TRUE)) {
    devEMF::emf(
      paste0(output_prefix, ".emf"),
      width = fig_width_in,
      height = fig_height_in,
      family = figure_font_family,
      pointsize = 15,
      coordDPI = 600,
      emfPlus = TRUE
    )
    print(Figure_7RV_s2_gg)
    dev.off()
  }
}
