# Supplementary Figure 10: field-level sensitivity changes and variety trends

required_packages <- c(
  "ggplot2", "ggdist", "cowplot", "RColorBrewer",
  "svglite", "ragg"
)
missing_packages <- required_packages[!vapply(
  required_packages,
  requireNamespace,
  logical(1),
  quietly = TRUE
)]

if (length(missing_packages) > 0) {
  stop(
    paste0(
      "Install the required R package(s) first: ",
      paste(missing_packages, collapse = ", "),
      ".\nRun: install.packages(c(",
      paste(sprintf('"%s"', missing_packages), collapse = ", "),
      "))"
    ),
    call. = FALSE
  )
}

suppressPackageStartupMessages({
  library(ggplot2)
  library(cowplot)
})

# -----------------------------------------------------------------------------
# Input checks and the original filtering rules
# -----------------------------------------------------------------------------

required_objects <- c(
  "summarized_df_filtered",
  "FHW_ychange_gg_df"
)
missing_objects <- required_objects[!vapply(
  required_objects,
  function(x) exists(x, inherits = TRUE),
  logical(1)
)]

if (length(missing_objects) > 0) {
  stop(
    paste(
      "Missing required object(s):",
      paste(missing_objects, collapse = ", ")
    ),
    call. = FALSE
  )
}

required_columns <- function(data, columns, object_name) {
  missing_columns <- setdiff(columns, names(data))
  if (length(missing_columns) > 0) {
    stop(
      paste(
        object_name, "is missing:",
        paste(missing_columns, collapse = ", ")
      ),
      call. = FALSE
    )
  }
}

required_columns(
  summarized_df_filtered,
  c("varbs", "Y_levle", "value", "Model"),
  "summarized_df_filtered"
)
required_columns(
  FHW_ychange_gg_df,
  c("Type", "model", "year", "Estimate", "Std..Error"),
  "FHW_ychange_gg_df"
)

# Panel (a): retain non-DTWD observations outside the County level.
field_keep <- with(
  summarized_df_filtered,
  !is.na(varbs) & varbs != "DTWD" &
    !is.na(Y_levle) & Y_levle != "County"
)
field_sensitivity_data <- summarized_df_filtered[
  field_keep,
  ,
  drop = FALSE
]

# Panel (b): retain non-DryWind observations for TSCD exactly as supplied.
trend_keep <- with(
  FHW_ychange_gg_df,
  !is.na(Type) & Type != "DryWind" &
    !is.na(model) & model == "TSCD"
)
field_ychange_data <- FHW_ychange_gg_df[
  trend_keep,
  ,
  drop = FALSE
]

if (nrow(field_sensitivity_data) == 0) {
  stop("No field-level non-DTWD observations remain.", call. = FALSE)
}
if (nrow(field_ychange_data) == 0) {
  stop("No non-DryWind TSCD observations remain.", call. = FALSE)
}

filter_manifest <- data.frame(
  panel = c("a", "b"),
  source_object = c("summarized_df_filtered", "FHW_ychange_gg_df"),
  input_rows = c(nrow(summarized_df_filtered), nrow(FHW_ychange_gg_df)),
  plotted_rows = c(nrow(field_sensitivity_data), nrow(field_ychange_data)),
  rule = c(
    "varbs != DTWD and Y_levle != County; missing classification excluded",
    "Type != DryWind and model == TSCD; missing classification excluded"
  ),
  stringsAsFactors = FALSE
)

# -----------------------------------------------------------------------------
# Shared typography and display labels
# -----------------------------------------------------------------------------

figure_font_family <- "Arial"
font_panel_label <- 9
font_strip <- 7.5
font_axis_text <- 7
font_axis_title <- 8
font_legend <- 7

display_prgw <- function(x) {
  gsub("PRWD", "PRGW", as.character(x), fixed = TRUE)
}

# -----------------------------------------------------------------------------
# Panel (a): distributions of field-level sensitivity changes
# -----------------------------------------------------------------------------

field_sens_change_sum_gg <- ggplot(
  field_sensitivity_data,
  aes(x = varbs, y = value)
) +
  ggdist::stat_halfeye(
    aes(fill = varbs),
    adjust = 0.6,
    width = 0.8,
    .width = 0,
    alpha = 0.6,
    position = position_dodge(width = 1),
    justification = -0.2,
    point_colour = NA
  ) +
  ggdist::stat_pointinterval(
    aes(colour = varbs),
    justification = 0.2,
    size = 0.6,
    position = position_dodge(width = 1),
    alpha = 0.6
  ) +
  stat_summary(
    aes(
      label = after_stat(round(y, 1)),
      colour = varbs
    ),
    fun = median,
    geom = "label",
    size = 2.25,
    position = position_dodge(width = 0.8),
    hjust = 0.5,
    vjust = -3,
    linewidth = 0.15,
    fill = "white",
    label.r = grid::unit(0.15, "lines")
  ) +
  geom_hline(
    yintercept = 0,
    linewidth = 0.5,
    linetype = "dashed",
    colour = "black"
  ) +
  scale_colour_manual(
    name = NULL,
    values = RColorBrewer::brewer.pal(8, "Set2")
  ) +
  scale_fill_manual(
    name = NULL,
    values = RColorBrewer::brewer.pal(8, "Set2")
  ) +
  scale_x_discrete(labels = display_prgw) +
  facet_wrap(~Model, ncol = 2) +
  labs(
    x = "Types of HDW",
    y = expression(
      "Changes in yield sensitivity to HDW"~(kg~ha^-1~hour^-1)
    ),
    subtitle = "(a)"
  ) +
  theme_bw(base_family = figure_font_family, base_size = font_axis_text) +
  theme(
    plot.subtitle = element_text(
      size = font_panel_label,
      face = "bold",
      hjust = 0.02,
      vjust = 1.2,
      margin = margin(b = 1)
    ),
    strip.text = element_text(size = font_strip),
    axis.text.x = element_text(
      size = font_axis_text,
      angle = 0,
      vjust = 1,
      hjust = 0.5
    ),
    axis.text.y = element_text(size = font_axis_text),
    axis.title = element_text(size = font_axis_title),
    legend.position = "none",
    panel.spacing = grid::unit(0.5, "lines"),
    strip.background = element_rect(colour = "transparent"),
    plot.background = element_rect(fill = "transparent", colour = NA),
    plot.margin = margin(1.5, 1.5, 1.5, 1.5, unit = "mm")
  )

# -----------------------------------------------------------------------------
# Panel (b): time series of variety-level HDW sensitivity
# -----------------------------------------------------------------------------

FHW_ychange_gg <- ggplot(
  field_ychange_data,
  aes(x = year, y = Estimate, colour = Type)
) +
  # Preserve the supplied interval: Estimate plus or minus one standard error.
  geom_errorbar(
    aes(
      ymin = Estimate - Std..Error,
      ymax = Estimate + Std..Error
    ),
    width = 0.3,
    alpha = 0.7,
    linewidth = 0.5
  ) +
  geom_line(linewidth = 0.5, alpha = 0.6) +
  geom_point(size = 1.5) +
  geom_hline(
    yintercept = 0,
    linetype = "dashed",
    colour = "gray40",
    linewidth = 0.4
  ) +
  scale_colour_manual(
    name = NULL,
    values = RColorBrewer::brewer.pal(8, "Dark2")[c(2, 1)],
    labels = display_prgw
  ) +
  guides(
    colour = guide_legend(
      ncol = 1,
      byrow = TRUE,
      override.aes = list(linewidth = 0.6, size = 1.6)
    )
  ) +
  labs(
    x = "Release year of variety",
    y = expression(beta[HDW]~"("*kg~ha^-1~hour^-1*")"),
    subtitle = "(b)"
  ) +
  theme_bw(base_family = figure_font_family, base_size = font_axis_text) +
  theme(
    plot.subtitle = element_text(
      size = font_panel_label,
      face = "bold",
      hjust = 0.02,
      vjust = 1.2,
      margin = margin(b = 1)
    ),
    strip.text = element_text(size = font_strip),
    axis.text.x = element_text(
      size = font_axis_text,
      angle = 0,
      vjust = 0.5
    ),
    axis.text.y = element_text(size = font_axis_text),
    axis.title = element_text(size = font_axis_title),
    legend.position = "inside",
    legend.position.inside = c(0.035, 0.975),
    legend.justification = c(0, 1),
    legend.direction = "vertical",
    legend.key.width = grid::unit(0.42, "cm"),
    legend.key.height = grid::unit(0.18, "cm"),
    legend.spacing.y = grid::unit(0.01, "cm"),
    legend.text = element_text(size = font_legend),
    legend.background = element_blank(),
    strip.background = element_rect(colour = "transparent"),
    plot.background = element_rect(fill = "transparent", colour = NA),
    plot.margin = margin(1.5, 1.5, 1.5, 1.5, unit = "mm")
  )

# Use two identical drawing viewports. Unlike plot_grid alignment, this does
# not vertically re-centre the structurally different faceted and single plots.
# The panel labels, top edges, x axes and bottom titles therefore remain level.
Supplementary_Figure_10_gg <- cowplot::ggdraw() +
  cowplot::draw_plot(
    field_sens_change_sum_gg,
    x = 0,
    y = 0,
    width = 0.5,
    height = 1
  ) +
  cowplot::draw_plot(
    FHW_ychange_gg,
    x = 0.5,
    y = 0,
    width = 0.5,
    height = 1
  )

# -----------------------------------------------------------------------------
# Source Data and consistent exports
# -----------------------------------------------------------------------------

skip_figure_export <- identical(Sys.getenv("HDW_SKIP_EXPORT"), "1")

if (!skip_figure_export) {
  output_dir <- Sys.getenv(
    "HDW_FIGURE_OUTPUT_DIR",
    unset = "D:/Crop yield loss at DHW/Figures/Figures_prof"
  )
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

  source_data_dir <- file.path(output_dir, "Source data")
  dir.create(source_data_dir, recursive = TRUE, showWarnings = FALSE)

  source_objects <- c(
    "summarized_df_filtered",
    "FHW_ychange_gg_df",
    "field_sensitivity_data",
    "field_ychange_data",
    "filter_manifest"
  )
  save(
    list = source_objects,
    file = file.path(
      source_data_dir,
      "Supplementary_Figure_10_source_data.RData"
    ),
    envir = environment(),
    version = 2
  )

  output_prefix <- file.path(output_dir, "Supplementary_Figure_10")
  fig_width_cm <- 14.6
  fig_height_cm <- 8
  fig_width_in <- fig_width_cm / 2.54
  fig_height_in <- fig_height_cm / 2.54

  svglite::svglite(
    paste0(output_prefix, ".svg"),
    width = fig_width_in,
    height = fig_height_in,
    bg = "transparent"
  )
  print(Supplementary_Figure_10_gg)
  dev.off()

  grDevices::cairo_pdf(
    paste0(output_prefix, ".pdf"),
    width = fig_width_in,
    height = fig_height_in,
    family = figure_font_family,
    bg = "transparent",
    fallback_resolution = 600
  )
  print(Supplementary_Figure_10_gg)
  dev.off()

  ragg::agg_tiff(
    paste0(output_prefix, ".tiff"),
    width = fig_width_cm,
    height = fig_height_cm,
    units = "cm",
    res = 600,
    compression = "lzw",
    background = "white"
  )
  print(Supplementary_Figure_10_gg)
  dev.off()

  word_dpi <- 450
  ragg::agg_png(
    paste0(output_prefix, "_word_", word_dpi, "dpi.png"),
    width = fig_width_cm,
    height = fig_height_cm,
    units = "cm",
    res = word_dpi,
    background = "white"
  )
  print(Supplementary_Figure_10_gg)
  dev.off()

  if (requireNamespace("devEMF", quietly = TRUE)) {
    devEMF::emf(
      paste0(output_prefix, ".emf"),
      width = fig_width_in,
      height = fig_height_in,
      family = figure_font_family,
      pointsize = 11,
      coordDPI = 600,
      emfPlus = TRUE
    )
    print(Supplementary_Figure_10_gg)
    dev.off()
  }
}
