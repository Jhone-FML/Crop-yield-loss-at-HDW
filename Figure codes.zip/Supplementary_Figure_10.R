# Supplementary Figure 10 -------------------------------------------------------------
# Direct Excel-based reproduction. This file does not source any other R script.
library(readxl)
ROOT = "F:/Post PHD documents/Crop yield loss at DHW/Submission/NF_proof_2026_09_01/Upload_Ready"
FIGURE_OUTPUT_DIR = file.path(ROOT,"Figures")
AMAP_DIR = "D:/Crop yield loss at DHW/amap"
FIGURE_FONT = "sans"
NF_LEGEND_TEXT_PT = 6.6; NF_LEGEND_TITLE_PT = 7.8
TIFF_DPI=600; PNG_DPI=450
MAP_YLIM=c(3200000,6024402)
INSET_LEFT=.170; INSET_RIGHT=.006; INSET_BOTTOM=.018
BASEMAP_TOLERANCE_M=10000
dir.create(FIGURE_OUTPUT_DIR,recursive=TRUE,showWarnings=FALSE)
check_packages=function(x){m=x[!vapply(x,requireNamespace,logical(1),quietly=TRUE)];if(length(m))stop("Install required package(s): ",paste(m,collapse=", "))}
check_packages(c("svglite","ragg","devEMF"))
if(requireNamespace("cowplot",quietly=TRUE)) cowplot::set_null_device("agg")
save_device=function(plot,device,file,...){device(file,...);id=dev.cur();on.exit(if(id %in% dev.list())dev.off(id),add=TRUE);print(plot);invisible(file)}
export_six=function(plot,name,width_cm,height_cm){prefix=file.path(FIGURE_OUTPUT_DIR,name);w=width_cm/2.54;h=height_cm/2.54;
 save_device(plot,function(file,...)cairo_pdf(filename=file,...),paste0(prefix,".pdf"),width=w,height=h,family=FIGURE_FONT,bg="transparent");
 save_device(plot,svglite::svglite,paste0(prefix,".svg"),width=w,height=h,bg="transparent");
 save_device(plot,svg,paste0(prefix,"_word_compatible.svg"),width=w,height=h,family="sans",pointsize=11,bg="transparent",onefile=TRUE);
 save_device(plot,devEMF::emf,paste0(prefix,".emf"),width=w,height=h,family="sans",pointsize=11,coordDPI=600,emfPlus=TRUE);
 save_device(plot,ragg::agg_tiff,paste0(prefix,".tiff"),width=width_cm,height=height_cm,units="cm",res=TIFF_DPI,compression="lzw",background="white");
 save_device(plot,ragg::agg_png,paste0(prefix,".png"),width=width_cm,height=height_cm,units="cm",res=PNG_DPI,background="white")}
export_bundle=function(plot,data,name,width_cm,height_cm)export_six(plot,name,width_cm,height_cm)
join_excel=function(geometry,values,keys,columns){for(k in keys){geometry[[k]]=as.character(geometry[[k]]);values[[k]]=as.character(values[[k]])};gk=do.call(paste,c(sf::st_drop_geometry(geometry)[keys],sep=""));vk=do.call(paste,c(values[keys],sep=""));i=match(gk,vk);if(anyNA(i))stop("Geometry cannot be matched to Excel: ",paste(keys,collapse=", "));for(to in names(columns))geometry[[to]]=values[[columns[[to]]]][i];geometry}

library(ggplot2)
x=as.data.frame(read_excel(file.path(ROOT,"Supplementary_Figure_10_source_data.xlsx"),sheet="Supplementary Figure 10"))
x$fact=factor(x$fact,levels=unique(x$fact));x$cols=factor(x$cols,levels=c("EDD_HD-MT","EDD_JT-HD","FDD_PT-JT"))

colours=c("EDD_HD-MT"="orangered3","EDD_JT-HD"="orangered","FDD_PT-JT"=RColorBrewer::brewer.pal(11,"PRGn")[2])
Supplementary_Figure_10=ggplot(x,aes(cols,colour=cols))+geom_linerange(aes(ymin=lo95,ymax=hi95),linewidth=.48)+geom_linerange(aes(ymin=lo66,ymax=hi66),linewidth=1.45)+geom_point(aes(y=median),size=2.1)+geom_text(aes(y=mean,label=mean_label),hjust=0,vjust=1.4,position=position_nudge(x=.10),size=3,show.legend=FALSE)+geom_hline(yintercept=0,linewidth=.48,linetype="dashed",colour="black")+scale_colour_manual(values=colours,guide="none")+scale_x_discrete(name=NULL,drop=FALSE,labels=c("EDD_HD-MT"=expression(EDD[HD-MT]),"EDD_JT-HD"=expression(EDD[JT-HD]),"FDD_PT-JT"=expression(FDD[PT-JT])))+scale_y_continuous(expand=expansion(mult=c(.08,.11)))+facet_wrap(~fact,scales="free",ncol=2)+labs(y=expression("Changes in yield sensitivity to weather"~(kg~ha^{-1}~day~degree*C)))+theme_bw(base_family=FIGURE_FONT,base_size=8)+theme(strip.text=element_text(size=8),axis.text.x=element_text(size=7,angle=45,hjust=1,vjust=1),axis.text.y=element_text(size=7),axis.title.y=element_text(size=8),panel.spacing=grid::unit(3.2,"mm"),strip.background=element_rect(colour="transparent"),plot.background=element_rect(fill="transparent",colour=NA),plot.margin=margin(2,2,2,2,unit="mm"))
export_six(Supplementary_Figure_10,"Supplementary_Figure_10",16,16)
