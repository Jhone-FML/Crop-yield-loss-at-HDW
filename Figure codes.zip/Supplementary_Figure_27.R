# Supplementary Figure 27 -------------------------------------------------------------
# Direct Excel-based reproduction. This file does not source any other R script.
library(readxl)
ROOT = "F:/Post PHD documents/Crop yield loss at DHW/Submission/NF_proof_2026_09_01/Upload_Ready"
FIGURE_OUTPUT_DIR = file.path(ROOT,"Figures")
AMAP_DIR = "D:/Crop yield loss at DHW/amap"
FIGURE_FONT = "sans"
NF_LEGEND_TEXT_PT = 6.6; NF_LEGEND_TITLE_PT = 7.8
TIFF_DPI=600; PNG_DPI=450
MAP_YLIM=c(3200000,6024402)
INSET_LEFT=.170; INSET_RIGHT=.006; INSET_BOTTOM=.018
BASEMAP_TOLERANCE_M=10000
dir.create(FIGURE_OUTPUT_DIR,recursive=TRUE,showWarnings=FALSE)
check_packages=function(x){m=x[!vapply(x,requireNamespace,logical(1),quietly=TRUE)];if(length(m))stop("Install required package(s): ",paste(m,collapse=", "))}
check_packages(c("svglite","ragg","devEMF"))
if(requireNamespace("cowplot",quietly=TRUE)) cowplot::set_null_device("agg")
save_device=function(plot,device,file,...){device(file,...);id=dev.cur();on.exit(if(id %in% dev.list())dev.off(id),add=TRUE);print(plot);invisible(file)}
export_six=function(plot,name,width_cm,height_cm){prefix=file.path(FIGURE_OUTPUT_DIR,name);w=width_cm/2.54;h=height_cm/2.54;
 save_device(plot,function(file,...)cairo_pdf(filename=file,...),paste0(prefix,".pdf"),width=w,height=h,family=FIGURE_FONT,bg="transparent");
 save_device(plot,svglite::svglite,paste0(prefix,".svg"),width=w,height=h,bg="transparent");
 save_device(plot,svg,paste0(prefix,"_word_compatible.svg"),width=w,height=h,family="sans",pointsize=11,bg="transparent",onefile=TRUE);
 save_device(plot,devEMF::emf,paste0(prefix,".emf"),width=w,height=h,family="sans",pointsize=11,coordDPI=600,emfPlus=TRUE);
 save_device(plot,ragg::agg_tiff,paste0(prefix,".tiff"),width=width_cm,height=height_cm,units="cm",res=TIFF_DPI,compression="lzw",background="white");
 save_device(plot,ragg::agg_png,paste0(prefix,".png"),width=width_cm,height=height_cm,units="cm",res=PNG_DPI,background="white")}
export_bundle=function(plot,data,name,width_cm,height_cm)export_six(plot,name,width_cm,height_cm)
join_excel=function(geometry,values,keys,columns){for(k in keys){geometry[[k]]=as.character(geometry[[k]]);values[[k]]=as.character(values[[k]])};gk=do.call(paste,c(sf::st_drop_geometry(geometry)[keys],sep="
"));vk=do.call(paste,c(values[keys],sep="
"));i=match(gk,vk);if(anyNA(i))stop("Geometry cannot be matched to Excel: ",paste(keys,collapse=", "));for(to in names(columns))geometry[[to]]=values[[columns[[to]]]][i];geometry}

prepare_latest_amap=local({cache=NULL;function(amap_dir=AMAP_DIR){if(!is.null(cache)&&identical(cache$amap_dir,amap_dir))return(cache);crs=sf::st_crs(paste("+proj=aea +lat_1=25 +lat_2=47 +lat_0=0 +lon_0=105","+datum=WGS84 +units=m +no_defs"));files=c(country=file.path(amap_dir,"land","100000.geojson"),maritime=file.path(amap_dir,"maritime","100000.geojson"),anhui=file.path(amap_dir,"province_land","340000.geojson"));pf=sort(list.files(file.path(amap_dir,"province_land"),"[.]geojson$",full.names=TRUE));readg=function(p)sf::st_sf(geometry=sf::st_geometry(sf::st_transform(sf::st_read(p,quiet=TRUE),4326)));country=readg(files["country"]);maritime=readg(files["maritime"]);anhui=readg(files["anhui"]);province=do.call(rbind,lapply(pf,readg));cut=unname(sf::st_bbox(anhui)["ymin"]);asline=function(x){if(any(grepl("POLYGON",as.character(sf::st_geometry_type(x)))))sf::st_geometry(x)=sf::st_boundary(sf::st_geometry(x));x};project=function(x){x=sf::st_transform(x,crs);x=suppressWarnings(sf::st_simplify(x,BASEMAP_TOLERANCE_M,preserveTopology=TRUE));x[!sf::st_is_empty(x),]};lines=lapply(list(country,province,maritime),asline);north=lapply(lines,project);main=sf::st_bbox(sf::st_transform(sf::st_as_sfc(sf::st_bbox(c(xmin=75.5,ymin=29,xmax=133.5,ymax=52.8),crs=sf::st_crs(4326))),crs));xlim=unname(main[c("xmin","xmax")]);ylim=MAP_YLIM;ylim[1]=min(ylim[1],unname(sf::st_bbox(sf::st_transform(anhui,crs))["ymin"])-30000);box=sf::st_bbox(c(xmin=73,ymin=3,xmax=135,ymax=cut),crs=sf::st_crs(4326));crop=function(x){g=sf::st_geometry(x);sf::st_crs(g)=NA;g=suppressWarnings(sf::st_crop(g,unclass(box)));g=suppressWarnings(sf::st_collection_extract(g,"LINESTRING"));sf::st_crs(g)=4326;project(sf::st_sf(geometry=g))};south=lapply(lines,crop);src=sf::st_bbox(do.call(rbind,south));pw=diff(xlim);ph=diff(ylim);xmin=xlim[2]-INSET_LEFT*pw;xmax=xlim[2]-INSET_RIGHT*pw;ymin=ylim[1]+INSET_BOTTOM*ph;sc=(xmax-xmin)/unname(src["xmax"]-src["xmin"]);ymax=ymin+sc*unname(src["ymax"]-src["ymin"]);inset=lapply(south,function(x){g=(sf::st_geometry(x)-unname(src[c("xmin","ymin")]))*sc+c(xmin,ymin);sf::st_sf(geometry=sf::st_set_crs(g,crs))});frame=sf::st_as_sf(sf::st_as_sfc(sf::st_bbox(c(xmin=xmin,ymin=ymin,xmax=xmax,ymax=ymax),crs=crs)));cache<<-list(amap_dir=amap_dir,crs=crs,xlim=xlim,ylim=ylim,north=north,inset=inset,frame=frame,south_cut_lat=cut,province_files=pf,country_file=files["country"],maritime_file=files["maritime"]);cache}})
latest_amap_layers=function(b){line=function(x,col,w)ggplot2::geom_sf(data=x,fill=NA,colour=col,linewidth=w,inherit.aes=FALSE,show.legend=FALSE);list(line(b$north[[2]],"grey55",.10),line(b$north[[1]],"grey45",.18),line(b$inset[[2]],"grey55",.08),line(b$inset[[1]],"grey45",.16),line(b$inset[[3]],"grey45",.14),line(b$frame,"grey45",.20))}
latest_amap_manifest=function(b)data.frame()

library(ggplot2)
library(sf)
library(cowplot)
book=file.path(ROOT,"Supplementary_Figure_27_source_data.xlsx");gpkg=file.path(ROOT,"Supplementary_Figure_27_geometry.gpkg")
value_names=c("PTDoy","JTDoy","HDDoy","MTDoy");source_names=c("Planting (DOY)","Jointing (DOY)","Heading (DOY)","Maturity (DOY)");panel_names=c("PT","JT","HD","MT")
maps=Map(function(layer,sheet,to,from){g=st_read(gpkg,layer=layer,quiet=TRUE);x=as.data.frame(read_excel(book,sheet=sheet));x[[from]]=suppressWarnings(as.numeric(x[[from]]));join_excel(g,x,"site",setNames(from,to))},panel_names,1:4,value_names,source_names)

specs=list(PT=list(value="PTDoy",title="(a) Planting",breaks=seq(259,315,5),limits=c(259,315)),JT=list(value="JTDoy",title="(b) Jointing",breaks=seq(50,132,5),limits=c(50,132)),HD=list(value="HDDoy",title="(c) Heading",breaks=seq(90,160,5),limits=c(90,160)),MT=list(value="MTDoy",title="(d) Maturity",breaks=seq(130,205,5),limits=c(130,205)))
b=prepare_latest_amap();maps=Map(function(z,s)suppressWarnings(st_simplify(st_transform(z,b$crs),2500,preserveTopology=TRUE)),maps,specs)
coord=coord_sf(crs=b$crs,xlim=b$xlim,ylim=b$ylim,expand=FALSE,clip="on",datum=st_crs(4326))
th=theme_bw(base_family=FIGURE_FONT,base_size=8)+theme(plot.title=element_text(size=9,hjust=.01),axis.title=element_blank(),axis.ticks=element_blank(),axis.text=element_blank(),panel.grid.major=element_line(colour="grey90",linewidth=.28),panel.grid.minor=element_blank(),legend.position="top",legend.justification="right",legend.direction="horizontal",legend.background=element_rect(fill="transparent",colour=NA),legend.key=element_rect(fill="transparent",colour=NA),legend.box.background=element_rect(fill="transparent",colour=NA),legend.title=element_text(size=NF_LEGEND_TITLE_PT,margin=margin(r=7)),legend.text=element_text(size=NF_LEGEND_TEXT_PT,angle=38,hjust=1,vjust=1,margin=margin(t=3.4)),legend.margin=margin(0,0,2,0),legend.box.spacing=unit(2.6,"mm"),plot.background=element_rect(fill="transparent",colour=NA),plot.margin=margin(.4,.5,.4,.5,unit="mm"))
panels=Map(function(z,s)ggplot()+geom_sf(data=z,aes(fill=.data[[s$value]]),colour="grey85",linewidth=.035)+latest_amap_layers(b)+scale_fill_stepsn(colours=RColorBrewer::brewer.pal(9,"Blues"),breaks=s$breaks,labels=as.character(s$breaks),limits=s$limits,oob=scales::squish,na.value="white",name="(doy)",guide=guide_colorsteps(direction="horizontal",title.position="left",label.position="bottom",barwidth=unit(6.8,"cm"),barheight=unit(.22,"cm"),ticks=FALSE))+labs(title=s$title)+coord+th,maps,specs)
Supplementary_Figure_27=ggdraw()+draw_plot(panels[[1]],.01,.48,.48,.52)+draw_plot(panels[[2]],.51,.48,.48,.52)+draw_plot(panels[[3]],.01,0,.48,.52)+draw_plot(panels[[4]],.51,0,.48,.52)
export_six(Supplementary_Figure_27,"Supplementary_Figure_27",16,11.35)
