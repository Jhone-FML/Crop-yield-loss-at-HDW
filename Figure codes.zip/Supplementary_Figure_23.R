# Supplementary Figure 23 -------------------------------------------------------------
# Direct Excel-based reproduction. This file does not source any other R script.
library(readxl)
ROOT = "F:/Post PHD documents/Crop yield loss at DHW/Submission/NF_proof_2026_09_01/Upload_Ready"
FIGURE_OUTPUT_DIR = file.path(ROOT,"Figures")
AMAP_DIR = "D:/Crop yield loss at DHW/amap"
FIGURE_FONT = "sans"
NF_LEGEND_TEXT_PT = 6.6; NF_LEGEND_TITLE_PT = 7.8
TIFF_DPI=600; PNG_DPI=450
MAP_YLIM=c(3200000,6024402)
INSET_LEFT=.170; INSET_RIGHT=.006; INSET_BOTTOM=.018
BASEMAP_TOLERANCE_M=10000
dir.create(FIGURE_OUTPUT_DIR,recursive=TRUE,showWarnings=FALSE)
check_packages=function(x){m=x[!vapply(x,requireNamespace,logical(1),quietly=TRUE)];if(length(m))stop("Install required package(s): ",paste(m,collapse=", "))}
check_packages(c("svglite","ragg","devEMF"))
if(requireNamespace("cowplot",quietly=TRUE)) cowplot::set_null_device("agg")
save_device=function(plot,device,file,...){device(file,...);id=dev.cur();on.exit(if(id %in% dev.list())dev.off(id),add=TRUE);print(plot);invisible(file)}
export_six=function(plot,name,width_cm,height_cm){prefix=file.path(FIGURE_OUTPUT_DIR,name);w=width_cm/2.54;h=height_cm/2.54;
 save_device(plot,function(file,...)cairo_pdf(filename=file,...),paste0(prefix,".pdf"),width=w,height=h,family=FIGURE_FONT,bg="transparent");
 save_device(plot,svglite::svglite,paste0(prefix,".svg"),width=w,height=h,bg="transparent");
 save_device(plot,svg,paste0(prefix,"_word_compatible.svg"),width=w,height=h,family="sans",pointsize=11,bg="transparent",onefile=TRUE);
 save_device(plot,devEMF::emf,paste0(prefix,".emf"),width=w,height=h,family="sans",pointsize=11,coordDPI=600,emfPlus=TRUE);
 save_device(plot,ragg::agg_tiff,paste0(prefix,".tiff"),width=width_cm,height=height_cm,units="cm",res=TIFF_DPI,compression="lzw",background="white");
 save_device(plot,ragg::agg_png,paste0(prefix,".png"),width=width_cm,height=height_cm,units="cm",res=PNG_DPI,background="white")}
export_bundle=function(plot,data,name,width_cm,height_cm)export_six(plot,name,width_cm,height_cm)
join_excel=function(geometry,values,keys,columns){for(k in keys){geometry[[k]]=as.character(geometry[[k]]);values[[k]]=as.character(values[[k]])};gk=do.call(paste,c(sf::st_drop_geometry(geometry)[keys],sep="
"));vk=do.call(paste,c(values[keys],sep="
"));i=match(gk,vk);if(anyNA(i))stop("Geometry cannot be matched to Excel: ",paste(keys,collapse=", "));for(to in names(columns))geometry[[to]]=values[[columns[[to]]]][i];geometry}

library(ggplot2)
wheat_cost_long=as.data.frame(read_excel(file.path(ROOT,"Supplementary_Figure_23_source_data.xlsx"),sheet="Supplementary Figure 23"))
names(wheat_cost_long)[names(wheat_cost_long)=="Cost (CNY ha-1)"]="Cost"

# Supplementary Figure 23: provincial wheat-production costs ----------------

pkgs <- c("ggplot2", "RColorBrewer", "scales", "svglite", "ragg")
miss <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
if (length(miss)) stop("Install: ", paste(miss, collapse = ", "), call. = FALSE)
library(ggplot2)

if (!exists("wheat_cost_long", inherits = TRUE) || !is.data.frame(wheat_cost_long))
  stop("wheat_cost_long is missing or is not a data frame.", call. = FALSE)
need <- c("year", "Cost", "Cost_Type", "Provience")
miss <- setdiff(need, names(wheat_cost_long))
if (length(miss)) stop("wheat_cost_long is missing: ", paste(miss, collapse = ", "),
                       call. = FALSE)
if (!is.numeric(wheat_cost_long$year) || !is.numeric(wheat_cost_long$Cost))
  stop("wheat_cost_long$year and $Cost must be numeric.", call. = FALSE)

# Retain the original four cost types and Cost x 15 conversion.
cost_types <- c("Seed", "Fertilizer", "Mechanization", "Irrigation")
province_levels <- if (is.factor(wheat_cost_long$Provience)) {
  levels(wheat_cost_long$Provience)
} else {
  unique(as.character(wheat_cost_long$Provience))
}
plot_data <- wheat_cost_long[wheat_cost_long$Cost_Type %in% cost_types, ]
if (!nrow(plot_data)) stop("No requested cost types were found.", call. = FALSE)
plot_data$Cost_Type <- factor(as.character(plot_data$Cost_Type), levels = cost_types)
plot_data$Provience <- factor(as.character(plot_data$Provience), levels = province_levels)
plot_data$Cost_ha <- plot_data$Cost
plot_data <- plot_data[order(plot_data$Provience, plot_data$Cost_Type,
                             plot_data$year), ]

cost_colours <- setNames(RColorBrewer::brewer.pal(8, "Set2")[1:4], cost_types)

AgpC_gg <- ggplot(
  plot_data,
  aes(x = year, y = Cost_ha, colour = Cost_Type, group = Cost_Type)
) +
  geom_line(linewidth = 0.58, alpha = 0.95, na.rm = FALSE) +
  facet_wrap(~Provience, scales = "free_y", ncol = 3) +
  scale_colour_manual(
    values = cost_colours, limits = cost_types, drop = FALSE,
    name = "Cost type",
    guide = guide_legend(nrow = 1, byrow = TRUE, title.position = "left")
  ) +
  scale_x_continuous(
    breaks = scales::breaks_pretty(n = 5),
    expand = expansion(mult = c(0.02, 0.02))
  ) +
  scale_y_continuous(
    breaks = scales::breaks_pretty(n = 4),
    labels = scales::label_number(big.mark = ",", accuracy = 1),
    expand = expansion(mult = c(0.04, 0.08))
  ) +
  labs(x = "Year", y = "Wheat production cost (CNY ha\u207B\u00B9)") +
  theme_bw(base_family = "sans", base_size = 8) +
  theme(
    strip.text = element_text(size = 8),
    strip.background = element_rect(fill = "grey90", colour = NA),
    axis.title = element_text(size = 9),
    axis.title.x = element_text(margin = margin(t = 4)),
    axis.title.y = element_text(margin = margin(r = 4)),
    axis.text.x = element_text(size = 7, angle = 45, hjust = 1, vjust = 1),
    axis.text.y = element_text(size = 7),
    panel.grid.major = element_line(colour = "grey90", linewidth = 0.25),
    panel.grid.minor = element_blank(),
    panel.spacing = grid::unit(1.5, "mm"),
    legend.position = "top", legend.justification = "center",
    legend.direction = "horizontal",
    legend.key.width = grid::unit(6, "mm"),
    legend.key.height = grid::unit(3, "mm"),
    legend.title = element_text(size = 8, margin = margin(r = 4)),
    legend.text = element_text(size = 8),
    legend.background = element_rect(fill = "transparent", colour = NA),
    legend.key = element_rect(fill = "transparent", colour = NA),
    legend.box.background = element_rect(fill = "transparent", colour = NA),
    legend.margin = margin(0, 0, 1, 0, unit = "mm"),
    plot.background = element_rect(fill = "transparent", colour = NA),
    plot.margin = margin(1, 1, 1, 1, unit = "mm")
  )

Supplementary_Figure_23 <- AgpC_gg


if (!identical(Sys.getenv("HDW_SKIP_EXPORT"), "1")) export_bundle(
  Supplementary_Figure_23, list(plot_data = plot_data),
  "Supplementary_Figure_23", 18, 16
)
export_six(Supplementary_Figure_23,"Supplementary_Figure_23", 18, 16)
