# Supplementary Figure 30 -------------------------------------------------------------
# Direct Excel-based reproduction. This file does not source any other R script.
library(readxl)
ROOT = "F:/Post PHD documents/Crop yield loss at DHW/Submission/NF_proof_2026_09_01/Upload_Ready"
FIGURE_OUTPUT_DIR = file.path(ROOT,"Figures")
AMAP_DIR = "D:/Crop yield loss at DHW/amap"
FIGURE_FONT = "sans"
NF_LEGEND_TEXT_PT = 6.6; NF_LEGEND_TITLE_PT = 7.8
TIFF_DPI=600; PNG_DPI=450
MAP_YLIM=c(3200000,6024402)
INSET_LEFT=.170; INSET_RIGHT=.006; INSET_BOTTOM=.018
BASEMAP_TOLERANCE_M=10000
dir.create(FIGURE_OUTPUT_DIR,recursive=TRUE,showWarnings=FALSE)
check_packages=function(x){m=x[!vapply(x,requireNamespace,logical(1),quietly=TRUE)];if(length(m))stop("Install required package(s): ",paste(m,collapse=", "))}
check_packages(c("svglite","ragg","devEMF"))
if(requireNamespace("cowplot",quietly=TRUE)) cowplot::set_null_device("agg")
save_device=function(plot,device,file,...){device(file,...);id=dev.cur();on.exit(if(id %in% dev.list())dev.off(id),add=TRUE);print(plot);invisible(file)}
export_six=function(plot,name,width_cm,height_cm){prefix=file.path(FIGURE_OUTPUT_DIR,name);w=width_cm/2.54;h=height_cm/2.54;
 save_device(plot,function(file,...)cairo_pdf(filename=file,...),paste0(prefix,".pdf"),width=w,height=h,family=FIGURE_FONT,bg="transparent");
 save_device(plot,svglite::svglite,paste0(prefix,".svg"),width=w,height=h,bg="transparent");
 save_device(plot,svg,paste0(prefix,"_word_compatible.svg"),width=w,height=h,family="sans",pointsize=11,bg="transparent",onefile=TRUE);
 save_device(plot,devEMF::emf,paste0(prefix,".emf"),width=w,height=h,family="sans",pointsize=11,coordDPI=600,emfPlus=TRUE);
 save_device(plot,ragg::agg_tiff,paste0(prefix,".tiff"),width=width_cm,height=height_cm,units="cm",res=TIFF_DPI,compression="lzw",background="white");
 save_device(plot,ragg::agg_png,paste0(prefix,".png"),width=width_cm,height=height_cm,units="cm",res=PNG_DPI,background="white")}
export_bundle=function(plot,data,name,width_cm,height_cm)export_six(plot,name,width_cm,height_cm)
join_excel=function(geometry,values,keys,columns){for(k in keys){geometry[[k]]=as.character(geometry[[k]]);values[[k]]=as.character(values[[k]])};gk=do.call(paste,c(sf::st_drop_geometry(geometry)[keys],sep="
"));vk=do.call(paste,c(values[keys],sep="
"));i=match(gk,vk);if(anyNA(i))stop("Geometry cannot be matched to Excel: ",paste(keys,collapse=", "));for(to in names(columns))geometry[[to]]=values[[columns[[to]]]][i];geometry}

library(ggplot2)
library(sf)
library(cowplot)
a=as.data.frame(read_excel(file.path(ROOT,"Supplementary_Figure_30_source_data.xlsx"),sheet="Supplementary Figure 30 a"))
p=as.data.frame(read_excel(file.path(ROOT,"Supplementary_Figure_30_source_data.xlsx"),sheet="Supplementary Figure 30 b"))
sig_summary=as.data.frame(read_excel(file.path(ROOT,"Supplementary_Figure_30_source_data.xlsx"),sheet="Supplementary Figure 30 c"))
a$correlation=suppressWarnings(as.numeric(a$correlation))
p$p_value=suppressWarnings(as.numeric(p$p_value))
g=st_read(file.path(ROOT,"Supplementary_Figure_30_geometry.gpkg"),layer="correlation_map",quiet=TRUE)
site_corr_long_sf=join_excel(g,a,c("site","ENAME","group"),c(correlation="correlation"));site_corr_long_sf=join_excel(site_corr_long_sf,p,c("site","ENAME","group"),c(p_value="p_value"))
map_source_manifest=function(...)data.frame()

# Supplementary Figure 30: partial correlations and significance ------------

pkgs <- c("ggplot2", "sf", "cowplot", "RColorBrewer", "scales", "svglite", "ragg")
miss <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
if (length(miss)) stop("Install: ", paste(miss, collapse = ", "), call. = FALSE)
library(ggplot2); library(sf); library(grid)

if (!exists("site_corr_long_sf", inherits = TRUE))
  stop("site_corr_long_sf is missing.", call. = FALSE)
if (!exists("sig_summary", inherits = TRUE))
  stop("sig_summary is missing.", call. = FALSE)
need_map <- c("correlation", "p_value", "group")
need_bar <- c("sig_label", "n", "group")
miss_map <- setdiff(need_map, names(site_corr_long_sf))
miss_bar <- setdiff(need_bar, names(sig_summary))
if (length(miss_map)) stop("Map data missing: ", paste(miss_map, collapse = ", "), call. = FALSE)
if (length(miss_bar)) stop("Bar data missing: ", paste(miss_bar, collapse = ", "), call. = FALSE)

# Data and Figure 3 map range ------------------------------------------------------------
d <- site_corr_long_sf
source_crs <- st_crs(d)
if (!inherits(d, "sf") || is.na(source_crs))
  stop("site_corr_long_sf must use a valid CRS.", call. = FALSE)
map_crs <- st_crs(paste(
  "+proj=aea +lat_1=25 +lat_2=47 +lat_0=0 +lon_0=105",
  "+datum=WGS84 +units=m +no_defs"
))
effects <- st_transform(d, map_crs)

amap <- AMAP_DIR
country_file <- file.path(amap, "land", "100000.geojson")
maritime_file <- file.path(amap, "maritime", "100000.geojson")
province_dir <- file.path(amap, "province_land")
province_files <- sort(list.files(province_dir, pattern = "[.]geojson$", full.names = TRUE))
if (!file.exists(country_file) || !file.exists(maritime_file) || !length(province_files))
  stop("The AMap basemap files are incomplete.", call. = FALSE)

read_geom <- function(f) {
  x <- st_transform(st_read(f, quiet = TRUE), 4326)
  st_sf(geometry = st_geometry(x))
}
map_line <- function(x) {
  if (any(grepl("POLYGON", as.character(st_geometry_type(x)))))
    st_geometry(x) <- st_boundary(st_geometry(x))
  x
}
project_map <- function(x) {
  x <- st_transform(x, map_crs)
  x <- suppressWarnings(st_simplify(x, 10000, preserveTopology = TRUE))
  x[!st_is_empty(x), , drop = FALSE]
}

country_wgs84 <- read_geom(country_file)
province_wgs84 <- do.call(rbind, lapply(province_files, read_geom))
maritime_wgs84 <- read_geom(maritime_file)
anhui_wgs84 <- read_geom(file.path(province_dir, "340000.geojson"))
country_line <- project_map(map_line(country_wgs84))
province_line <- project_map(map_line(province_wgs84))
maritime <- project_map(map_line(maritime_wgs84))

main_box_ll <- st_bbox(c(xmin = 75.5, ymin = 29, xmax = 133.5, ymax = 52.8),
                       crs = st_crs(4326))
main_box <- st_bbox(st_transform(st_as_sfc(main_box_ll), map_crs))
main_xlim <- unname(main_box[c("xmin", "xmax")])
main_ylim <- MAP_YLIM
main_ylim[1] <- min(main_ylim[1],
  unname(st_bbox(st_transform(anhui_wgs84, map_crs))["ymin"]) - 30000)

south_cut <- unname(st_bbox(anhui_wgs84)["ymin"])
south_box <- st_bbox(c(xmin = 73, ymin = 3, xmax = 135, ymax = south_cut),
                      crs = st_crs(4326))
crop_south <- function(x) {
  g <- st_geometry(map_line(x)); st_crs(g) <- NA
  g <- suppressWarnings(st_crop(g, unclass(south_box)))
  g <- suppressWarnings(st_collection_extract(g, "LINESTRING")); st_crs(g) <- 4326
  project_map(st_sf(geometry = g))
}
country_south <- crop_south(country_wgs84)
province_south <- crop_south(province_wgs84)
maritime_south <- crop_south(maritime_wgs84)
south <- list(country_south, province_south, maritime_south)
if (any(vapply(south, nrow, integer(1)) == 0L))
  stop("A southern inset layer is empty.", call. = FALSE)

source_bbox <- st_bbox(do.call(rbind, south))
pw <- diff(main_xlim); ph <- diff(main_ylim)
inset_xmin <- main_xlim[2] - INSET_LEFT * pw
inset_xmax <- main_xlim[2] - INSET_RIGHT * pw
inset_ymin <- main_ylim[1] + INSET_BOTTOM * ph
inset_scale <- (inset_xmax - inset_xmin) /
  unname(source_bbox["xmax"] - source_bbox["xmin"])
inset_ymax <- inset_ymin + inset_scale *
  unname(source_bbox["ymax"] - source_bbox["ymin"])
target_bbox <- c(xmin = inset_xmin, ymin = inset_ymin,
                  xmax = inset_xmax, ymax = inset_ymax)

move_bbox <- function(x, from, to) {
  old_mid <- c(mean(from[c("xmin", "xmax")]), mean(from[c("ymin", "ymax")]))
  new_mid <- c(mean(to[c("xmin", "xmax")]), mean(to[c("ymin", "ymax")]))
  k <- (to["xmax"] - to["xmin"]) / (from["xmax"] - from["xmin"])
  g <- (st_geometry(x) - old_mid) * k + new_mid
  st_geometry(x) <- st_set_crs(g, map_crs)
  x
}
inset <- lapply(south, move_bbox, from = source_bbox, to = target_bbox)
inset_frame <- st_as_sf(st_as_sfc(st_bbox(target_bbox, crs = map_crs)))

# Shared map components ---------------------------------------------------------------
line_layer <- function(x, colour, width) geom_sf(
  data = x, fill = NA, colour = colour, linewidth = width,
  inherit.aes = FALSE, show.legend = FALSE
)
base_layers <- list(
  line_layer(province_line, "grey55", 0.10),
  line_layer(country_line, "grey45", 0.18),
  line_layer(inset[[2]], "grey55", 0.08),
  line_layer(inset[[1]], "grey45", 0.16),
  line_layer(inset[[3]], "grey45", 0.14),
  line_layer(inset_frame, "grey45", 0.20)
)
map_coord <- coord_sf(crs = map_crs, xlim = main_xlim, ylim = main_ylim, expand = FALSE,
                      clip = "on", datum = st_crs(4326))
map_theme <- theme_bw(base_family = "sans", base_size = 8) + theme(
  plot.subtitle = element_text(size = 9, hjust = 0.01, margin = margin(b = 2)),
  strip.text = element_text(size = 7.5),
  strip.background = element_rect(fill = "grey85", colour = NA),
  axis.title = element_blank(), axis.ticks = element_blank(), axis.text = element_blank(),
  panel.grid.major = element_line(colour = "grey90", linewidth = 0.28),
  panel.grid.minor = element_blank(), panel.spacing.x = unit(1.5, "mm"),
  legend.position = "top", legend.justification = "right",
  legend.box.just = "right", legend.direction = "horizontal",
  legend.background = element_blank(), legend.text = element_text(size = 6.2),
  legend.title = element_text(size = 6.5, margin = margin(r = 3)),
  legend.margin = margin(0, 0, 1, 0, unit = "mm"),
  legend.box.spacing = unit(1.2, "mm"),
  plot.background = element_rect(fill = "transparent", colour = NA),
  plot.margin = margin(0.5, 0.2, 0.5, 0.2, unit = "mm")
)

# (a) Partial-correlation coefficients ---------------------------------------
r_breaks <- seq(-1, 1, 0.2)
HDW_site_corr_long_r_gg <- ggplot() +
  geom_sf(data = effects, aes(fill = correlation), colour = "grey85", linewidth = 0.03) +
  base_layers +
  scale_fill_stepsn(
    colours = RColorBrewer::brewer.pal(11, "BrBG"), breaks = r_breaks,
    limits = c(-1, 1), values = scales::rescale(r_breaks), na.value = "grey75",
    name = expression(italic(r)), guide = guide_colorsteps(
      direction = "horizontal", title.position = "left", label.position = "bottom",
      barwidth = unit(6.5, "cm"), barheight = unit(0.22, "cm"), ticks = TRUE
    )
  ) +
  labs(subtitle = "(a) R value of partial correlation analysis") +
  facet_grid(~group) + map_coord + map_theme

# (b) P values; non-significant counties remain grey -------------------------
p_breaks <- c(0, 0.001, 0.005, 0.01, 0.05)
p_sig <- effects[is.finite(effects$p_value) & effects$p_value <= 0.05, ]
p_nonsig <- effects[is.finite(effects$p_value) & effects$p_value > 0.05, ]
HDW_site_corr_long_p_gg <- ggplot() +
  geom_sf(data = p_nonsig, fill = "grey75", colour = "grey85", linewidth = 0.03) +
  geom_sf(data = p_sig, aes(fill = p_value), colour = "grey85", linewidth = 0.03) +
  base_layers +
  scale_fill_stepsn(
    colours = rev(RColorBrewer::brewer.pal(11, "BrBG")[7:11]),
    breaks = p_breaks, limits = c(0, 0.05), values = scales::rescale(p_breaks),
    na.value = "grey75", name = expression(italic(p)), guide = guide_colorsteps(
      direction = "horizontal", title.position = "left", label.position = "bottom",
      barwidth = unit(6.5, "cm"), barheight = unit(0.22, "cm"), ticks = TRUE
    )
  ) +
  labs(subtitle = "(b) P value of partial correlation analysis") +
  facet_grid(~group) + map_coord + map_theme

# (c) County counts -----------------------------------------------------------
HDW_year_sig_gg <- ggplot(sig_summary, aes(sig_label, n, fill = sig_label)) +
  geom_col(width = 0.62, colour = "black", linewidth = 0.25) +
  scale_fill_manual(values = c("grey85", "cyan4", "orange3")) +
  scale_x_discrete(labels = function(x) sub("\\s*\\(", "\n(", x)) +
  scale_y_continuous(breaks = scales::breaks_pretty(n = 4),
                     expand = expansion(mult = c(0, 0.08))) +
  facet_grid(~group) +
  labs(x = NULL, y = "Number of counties",
       subtitle = "(c) Significant and non-significant counties across HDW types") +
  theme_bw(base_family = "sans", base_size = 8) + theme(
    plot.subtitle = element_text(size = 9, hjust = 0.01, margin = margin(b = 2)),
    strip.text = element_text(size = 7.5),
    strip.background = element_rect(fill = "grey85", colour = NA),
    axis.title = element_text(size = 8),
    axis.title.y = element_text(margin = margin(r = 3)),
    axis.text.y = element_text(size = 6.5),
    axis.text.x = element_text(size = 6.8, angle = 0, hjust = 0.5,
                               lineheight = 0.9, margin = margin(t = 2)),
    legend.position = "none", panel.spacing.x = unit(1.5, "mm"),
    plot.background = element_rect(fill = "transparent", colour = NA),
    plot.margin = margin(0.5, 0.2, 1.2, 0.2, unit = "mm")
  )

figure_stack <- cowplot::plot_grid(
  HDW_site_corr_long_r_gg, HDW_site_corr_long_p_gg, HDW_year_sig_gg,
  ncol = 1, align = "v", axis = "lr", greedy = FALSE,
  rel_heights = c(1, 1, 0.95)
)
Supplementary_Figure_30 <- cowplot::ggdraw() +
  draw_plot(HDW_site_corr_long_r_gg, x = 0, y = 0.66,  width =1, height = 0.33) +
  draw_plot(HDW_site_corr_long_p_gg, x = 0, y = 0.31,  width =1, height = 0.33)+
  draw_plot(HDW_year_sig_gg , x = 0.01, y = -0.01, width =0.98, height = 0.29)
# Supplementary_Figure_30


map_manifest <- map_source_manifest(
  country_file, province_files, maritime_file, main_xlim, main_ylim, target_bbox
)
filter_manifest <- data.frame(
  dataset = c("correlation", "p_significant", "p_nonsignificant", "county_counts"),
  rows = c(nrow(effects), nrow(p_sig), nrow(p_nonsig), nrow(sig_summary)),
  rule = c("all mapped correlations", "is.finite(p_value) & p_value <= 0.05",
           "is.finite(p_value) & p_value > 0.05", "aggregated county counts"),
  stringsAsFactors = FALSE
)
if (!identical(Sys.getenv("HDW_SKIP_EXPORT"), "1")) export_bundle(
  Supplementary_Figure_30,
  list(correlation_map = effects, p_significant = p_sig,
       p_nonsignificant = p_nonsig, county_counts = sig_summary,
       filter_manifest = filter_manifest, map_manifest = map_manifest),
  "Supplementary_Figure_30", 15, 12.5
)
export_six(Supplementary_Figure_30, "Supplementary_Figure_30", 15, 12.5)