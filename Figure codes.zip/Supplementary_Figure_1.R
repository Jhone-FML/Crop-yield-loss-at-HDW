# Supplementary Figure 1 -------------------------------------------------------------
# Direct Excel-based reproduction. This file does not source any other R script.
library(readxl)
ROOT = "F:/Post PHD documents/Crop yield loss at DHW/Submission/NF_proof_2026_09_01/Upload_Ready"
FIGURE_OUTPUT_DIR = file.path(ROOT, "Figures")
AMAP_DIR = "D:/Crop yield loss at DHW/amap"
FIGURE_FONT = "sans"
NF_LEGEND_TEXT_PT = 6.6; NF_LEGEND_TITLE_PT = 7.8
TIFF_DPI = 600; PNG_DPI = 450
MAP_YLIM = c(3200000, 6024402)
INSET_LEFT = 0.170; INSET_RIGHT = 0.006; INSET_BOTTOM = 0.018
BASEMAP_TOLERANCE_M = 10000
dir.create(FIGURE_OUTPUT_DIR, recursive = TRUE, showWarnings = FALSE)
check_packages = function(x) {
  miss = x[!vapply(x, requireNamespace, logical(1), quietly = TRUE)]
  if (length(miss)) stop("Install required package(s): ", paste(miss, collapse = ", "))
}
check_packages(c("svglite", "ragg", "devEMF"))
if (requireNamespace("cowplot", quietly = TRUE)) cowplot::set_null_device("agg")
save_device = function(plot, device, file, ...) {
  device(file, ...); id = dev.cur(); on.exit(if (id %in% dev.list()) dev.off(id), add = TRUE)
  print(plot); invisible(file)
}
export_six = function(plot, name, width_cm, height_cm) {
  prefix = file.path(FIGURE_OUTPUT_DIR, name); w = width_cm / 2.54; h = height_cm / 2.54
  save_device(plot, function(file, ...) cairo_pdf(filename = file, ...), paste0(prefix, ".pdf"),
    width = w, height = h, family = FIGURE_FONT, bg = "transparent")
  save_device(plot, svglite::svglite, paste0(prefix, ".svg"), width = w, height = h, bg = "transparent")
  save_device(plot, svg, paste0(prefix, "_word_compatible.svg"), width = w, height = h,
    family = "sans", pointsize = 11, bg = "transparent", onefile = TRUE)
  save_device(plot, devEMF::emf, paste0(prefix, ".emf"), width = w, height = h,
    family = "sans", pointsize = 11, coordDPI = 600, emfPlus = TRUE)
  save_device(plot, ragg::agg_tiff, paste0(prefix, ".tiff"), width = width_cm, height = height_cm,
    units = "cm", res = TIFF_DPI, compression = "lzw", background = "white")
  save_device(plot, ragg::agg_png, paste0(prefix, ".png"), width = width_cm, height = height_cm,
    units = "cm", res = PNG_DPI, background = "white")
}
export_bundle = function(plot, data, name, width_cm, height_cm) export_six(plot, name, width_cm, height_cm)
map_source_manifest = function(...) data.frame()
join_excel = function(geometry, values, keys, columns) {
  for (k in keys) { geometry[[k]] = as.character(geometry[[k]]); values[[k]] = as.character(values[[k]]) }
  gkey = do.call(paste, c(sf::st_drop_geometry(geometry)[keys], sep = "
"))
  vkey = do.call(paste, c(values[keys], sep = "
")); idx = match(gkey, vkey)
  if (anyNA(idx)) stop("Geometry cannot be matched to Excel for key: ", paste(keys, collapse = ", "))
  for (to in names(columns)) geometry[[to]] = values[[columns[[to]]]][idx]
  geometry
}

library(sf)
x = as.data.frame(read_excel(file.path(ROOT,"Supplementary_Figure_1_source_data.xlsx"),sheet="Supplementary Figure 1"))
x[["Mean (hours)"]] = suppressWarnings(as.numeric(x[["Mean (hours)"]]))
g = st_read(file.path(ROOT,"Supplementary_Figure_1_geometry.gpkg"),layer="CMFD_freqs_means_period_sf",quiet=TRUE)
CMFD_freqs_means_period_sf = join_excel(g,x,c("site","Type","Period"),c(mean_hours="Mean (hours)"))

# Supplementary Figure 1 ------------------------------------------------------

required_packages <- c(
  "ggplot2", "sf", "RColorBrewer", "scales", "svglite", "ragg"
)

missing_packages <- required_packages[!vapply(
  required_packages,
  requireNamespace,
  logical(1),
  quietly = TRUE
)]

if (length(missing_packages)) {
  stop(
    "Install the required package(s): ",
    paste(missing_packages, collapse = ", "),
    call. = FALSE
  )
}

library(ggplot2)
library(sf)
library(grid)

# Data check ------------------------------------------------------------------

if (!exists("CMFD_freqs_means_period_sf", inherits = TRUE)) {
  stop("CMFD_freqs_means_period_sf is missing.", call. = FALSE)
}

if (!inherits(CMFD_freqs_means_period_sf, "sf")) {
  stop("CMFD_freqs_means_period_sf must be an sf object.", call. = FALSE)
}

required_columns <- c("mean_hours", "Period", "Type")
missing_columns <- setdiff(
  required_columns,
  names(CMFD_freqs_means_period_sf)
)

if (length(missing_columns)) {
  stop(
    "CMFD_freqs_means_period_sf is missing: ",
    paste(missing_columns, collapse = ", "),
    call. = FALSE
  )
}

# Basemap ---------------------------------------------------------------------

amap_dir <- AMAP_DIR

country_file <- file.path(
  amap_dir,
  "land",
  "100000.geojson"
)

province_dir <- file.path(
  amap_dir,
  "province_land"
)

maritime_file <- file.path(
  amap_dir,
  "maritime",
  "100000.geojson"
)

province_files <- sort(list.files(
  province_dir,
  pattern = "[.]geojson$",
  full.names = TRUE
))

if (
  !file.exists(country_file) ||
  !file.exists(maritime_file) ||
  !length(province_files)
) {
  stop(
    "The basemap files are incomplete under amap_dir.",
    call. = FALSE
  )
}

read_geometry <- function(path) {
  x <- sf::st_transform(sf::st_read(path, quiet = TRUE), 4326)
  sf::st_sf(geometry = sf::st_geometry(x))
}

source_crs <- sf::st_crs(CMFD_freqs_means_period_sf)
if (is.na(source_crs)) stop("CMFD_freqs_means_period_sf has no CRS.", call. = FALSE)
map_crs <- sf::st_crs(paste(
  "+proj=aea +lat_1=25 +lat_2=47 +lat_0=0 +lon_0=105",
  "+datum=WGS84 +units=m +no_defs"
))

country_wgs84 <- read_geometry(country_file)
province_wgs84 <- do.call(rbind, lapply(province_files, read_geometry))
maritime_wgs84 <- read_geometry(maritime_file)
anhui_wgs84 <- read_geometry(file.path(province_dir, "340000.geojson"))

map_line <- function(x) {
  if (any(grepl("POLYGON", as.character(sf::st_geometry_type(x))))) {
    sf::st_geometry(x) <- sf::st_boundary(sf::st_geometry(x))
  }
  x
}
project_map <- function(x) {
  x <- sf::st_transform(x, map_crs)
  x <- suppressWarnings(sf::st_simplify(x, dTolerance = 10000, preserveTopology = TRUE))
  x[!sf::st_is_empty(x), , drop = FALSE]
}

effects_plot <- sf::st_transform(CMFD_freqs_means_period_sf, map_crs)
country_line <- project_map(map_line(country_wgs84))
province_line <- project_map(map_line(province_wgs84))
maritime_plot <- project_map(map_line(maritime_wgs84))

main_box_ll <- sf::st_bbox(
  c(xmin = 75.5, ymin = 29, xmax = 133.5, ymax = 52.8),
  crs = sf::st_crs(4326)
)
main_box <- sf::st_bbox(sf::st_transform(sf::st_as_sfc(main_box_ll), map_crs))
main_xlim <- unname(main_box[c("xmin", "xmax")])
main_ylim <- MAP_YLIM
main_ylim[1] <- min(
  main_ylim[1],
  unname(sf::st_bbox(sf::st_transform(anhui_wgs84, map_crs))["ymin"]) - 30000
)

south_cut <- unname(sf::st_bbox(anhui_wgs84)["ymin"])
south_box <- sf::st_bbox(
  c(xmin = 73, ymin = 3, xmax = 135, ymax = south_cut),
  crs = sf::st_crs(4326)
)
crop_south <- function(x) {
  geometry <- sf::st_geometry(map_line(x))
  sf::st_crs(geometry) <- NA
  geometry <- suppressWarnings(sf::st_crop(geometry, unclass(south_box)))
  geometry <- suppressWarnings(sf::st_collection_extract(geometry, "LINESTRING"))
  sf::st_crs(geometry) <- 4326
  project_map(sf::st_sf(geometry = geometry))
}

country_south <- crop_south(country_wgs84)
province_south <- crop_south(province_wgs84)
maritime_south <- crop_south(maritime_wgs84)
south_layers <- Filter(
  function(x) nrow(x) > 0 && !all(sf::st_is_empty(x)),
  list(country_south, province_south, maritime_south)
)
if (length(south_layers) != 3L) stop("A southern inset layer is empty.", call. = FALSE)

source_bbox <- sf::st_bbox(do.call(rbind, south_layers))
panel_width <- diff(main_xlim)
panel_height <- diff(main_ylim)
inset_xmin <- main_xlim[2] - INSET_LEFT * panel_width
inset_xmax <- main_xlim[2] - INSET_RIGHT * panel_width
inset_ymin <- main_ylim[1] + INSET_BOTTOM * panel_height
inset_scale <- (inset_xmax - inset_xmin) /
  unname(source_bbox["xmax"] - source_bbox["xmin"])
inset_ymax <- inset_ymin + inset_scale *
  unname(source_bbox["ymax"] - source_bbox["ymin"])
target_bbox <- c(
  xmin = inset_xmin, ymin = inset_ymin,
  xmax = inset_xmax, ymax = inset_ymax
)

move_to_bbox <- function(x, from, to) {
  if (!nrow(x)) {
    return(x)
  }
  
  from_size <- c(
    unname(from["xmax"] - from["xmin"]),
    unname(from["ymax"] - from["ymin"])
  )
  
  to_size <- c(
    unname(to["xmax"] - to["xmin"]),
    unname(to["ymax"] - to["ymin"])
  )
  
  scale_factor <- min(
    to_size / from_size
  )
  
  from_center <- c(
    mean(from[c("xmin", "xmax")]),
    mean(from[c("ymin", "ymax")])
  )
  
  to_center <- c(
    mean(to[c("xmin", "xmax")]),
    mean(to[c("ymin", "ymax")])
  )
  
  geometry <- (
    sf::st_geometry(x) - from_center
  ) * scale_factor + to_center
  
  sf::st_geometry(x) <- sf::st_set_crs(
    geometry,
    map_crs
  )
  
  x
}

country_inset <- move_to_bbox(
  country_south,
  source_bbox,
  target_bbox
)

province_inset <- move_to_bbox(
  province_south,
  source_bbox,
  target_bbox
)

maritime_inset <- move_to_bbox(
  maritime_south,
  source_bbox,
  target_bbox
)

inset_frame <- sf::st_as_sf(
  sf::st_as_sfc(
    sf::st_bbox(
      target_bbox,
      crs = map_crs
    )
  )
)

# Legend ----------------------------------------------------------------------

legend_breaks <- c(
  seq(0, 5, 0.5),
  seq(10, 40, 5),
  60
)

legend_labels <- c(
  as.character(
    legend_breaks[-length(legend_breaks)]
  ),
  ">40"
)

legend_colours <- grDevices::colorRampPalette(
  RColorBrewer::brewer.pal(9, "BuPu")
)(
  length(legend_breaks)
)

# Plot ------------------------------------------------------------------------

Supplementary_Figure_1 <- ggplot() +
  
  geom_sf(
    data = effects_plot,
    aes(fill = mean_hours),
    colour = NA,
    linewidth = 0
  ) +
  
  geom_sf(
    data = province_line,
    fill = NA,
    colour = "grey55",
    linewidth = 0.10,
    inherit.aes = FALSE
  ) +
  
  geom_sf(
    data = country_line,
    fill = NA,
    colour = "grey45",
    linewidth = 0.18,
    inherit.aes = FALSE
  ) +
  
  geom_sf(
    data = province_inset,
    fill = NA,
    colour = "grey55",
    linewidth = 0.08,
    inherit.aes = FALSE
  ) +
  
  geom_sf(
    data = country_inset,
    fill = NA,
    colour = "grey45",
    linewidth = 0.16,
    inherit.aes = FALSE
  ) +
  
  geom_sf(
    data = maritime_inset,
    colour = "grey45",
    linewidth = 0.14,
    inherit.aes = FALSE
  ) +
  
  geom_sf(
    data = inset_frame,
    fill = NA,
    colour = "grey45",
    linewidth = 0.20,
    inherit.aes = FALSE
  ) +
  
  scale_fill_stepsn(
    colours = legend_colours,
    breaks = legend_breaks,
    labels = legend_labels,
    limits = c(0, 60),
    values = scales::rescale(legend_breaks),
    na.value = "white",
    name = "Hours (season\u207B\u00B9)",
    guide = guide_colorsteps(
      direction = "horizontal",
      title.position = "left",
      title.hjust = 1,
      label.position = "bottom",
      barwidth = unit(8.0, "cm"),
      barheight = unit(0.24, "cm"),
      ticks = TRUE,
      even.steps = TRUE
    )
  ) +
  
  labs(
    subtitle = bquote(
      Averaged~HDW[HD-MT]
    )
  ) +
  
  facet_grid(
    Period ~ Type,
    labeller = labeller(
      Type = function(x) {
        gsub(
          "PRWD",
          "PRGW",
          x,
          fixed = TRUE
        )
      }
    )
  ) +
  
  coord_sf(
    crs = map_crs,
    xlim = main_xlim,
    ylim = main_ylim,
    expand = FALSE,
    clip = "on",
    datum = sf::st_crs(4326)
  ) +
  
  theme_bw(
    base_family = "sans",
    base_size = 8
  ) +
  
  theme(
    plot.subtitle = element_text(
      size = 9,
      hjust = 0.015,
      vjust = 1.3
    ),
    
    strip.text = element_text(
      size = 8
    ),
    
    strip.background = element_rect(
      fill = "grey85",
      colour = NA
    ),
    
    axis.title = element_blank(),
    axis.ticks = element_blank(),
    axis.text = element_blank(),
    
    panel.grid.major = element_line(
      colour = "grey90",
      linewidth = 0.30
    ),
    
    panel.grid.minor = element_blank(),
    
    panel.spacing.x = unit(
      1.4,
      "mm"
    ),
    
    panel.spacing.y = unit(
      2.8,
      "mm"
    ),
    
    legend.position = "inside",
    
    legend.position.inside = c(
      0.68,
      1.115
    ),
    
    legend.justification = c(
      0.5,
      0.5
    ),
    
    legend.direction = "horizontal",
    
    legend.background = element_blank(),
    
    legend.text = element_text(
      size = 6.2
    ),
    
    legend.title = element_text(
      size = 6.5,
      margin = margin(r = 3)
    ),
    
    legend.margin = margin(
      0,
      0,
      0,
      0
    ),
    
    legend.box.spacing = unit(
      0,
      "mm"
    ),
    
    plot.background = element_rect(
      fill = "transparent",
      colour = NA
    ),
    
    plot.margin = margin(
      0.8,
      0.5,
      0.5,
      0.5,
      unit = "mm"
    )
  )

Supplementary_Figure_1


map_manifest <- map_source_manifest(
  country_file, province_files, maritime_file, main_xlim, main_ylim, target_bbox
)
geometry_manifest <- data.frame(
  dataset = "mean_by_period", input_rows = nrow(CMFD_freqs_means_period_sf),
  plotted_rows = nrow(effects_plot), plotting_simplification_m = 6000,
  values_or_rows_filtered = FALSE
)
if (!identical(Sys.getenv("HDW_SKIP_EXPORT"), "1")) export_bundle(
  Supplementary_Figure_1,
  list(mean_map = effects_plot, geometry_manifest = geometry_manifest,
       map_manifest = map_manifest),
  "Supplementary_Figure_1", 15, 9.2
)
export_six(Supplementary_Figure_1, "Supplementary_Figure_1", 15, 9.2)