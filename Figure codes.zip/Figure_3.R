# Figure 3 --------------------------------------------------------------------
library(ggplot2)
library(sf)
library(cowplot)
library(grid)
library(RColorBrewer)
library(scales)
library(readxl)

need = c("svglite", "ragg", "devEMF")
miss = need[!vapply(need, requireNamespace, logical(1), quietly = TRUE)]
if (length(miss)) stop("Please install: ", paste(miss, collapse = ", "))

root = "F:/Post PHD documents/Crop yield loss at DHW/Submission/NF_proof_2026_09_01/Upload_Ready"
out_dir = file.path(root, "Figures")
amap_dir = "D:/Crop yield loss at DHW/amap"
dir.create(out_dir, showWarnings = FALSE)

# Excel supplies all plotted values; the GeoPackage supplies geometry and join keys only.
effects_data = as.data.frame(read_excel(file.path(root, "Figure_3_source_data.xlsx"),
  sheet = "Figure 3"))
effects_geometry = st_read(file.path(root, "Figure_3_geometry.gpkg"), quiet = TRUE)
effects_data$site = as.character(effects_data$site)
effects_geometry$site = as.character(effects_geometry$site)
key_cols = c("site", "Type", "ENAME", "Model", "Y_levle")
value_key = do.call(paste, c(effects_data[key_cols], sep = "\r"))
geometry_key = do.call(paste, c(st_drop_geometry(effects_geometry)[key_cols], sep = "\r"))
row_id = match(geometry_key, value_key)
if (anyNA(row_id)) stop("Some Figure 3 geometries cannot be matched to the Excel table.")
effects_geometry$effects = as.numeric(effects_data[["effects (kg ha-1 season-1)"]][row_id])
effects_geometry$Model = factor(effects_geometry$Model,
  levels = c("TPCD", "TPDM", "TSCD", "TSDM"))
effects_geometry$Type = factor(effects_geometry$Type,
  levels = c("DTWD", "HTLH", "PRGW"))

# Latest AMap boundaries and the approved north/south map ratio.
map_crs = st_crs(paste("+proj=aea +lat_1=25 +lat_2=47 +lat_0=0 +lon_0=105",
  "+datum=WGS84 +units=m +no_defs"))
country_file = file.path(amap_dir, "land", "100000.geojson")
maritime_file = file.path(amap_dir, "maritime", "100000.geojson")
province_files = sort(list.files(file.path(amap_dir, "province_land"),
  pattern = "[.]geojson$", full.names = TRUE))
read_map = function(x) st_sf(geometry = st_geometry(st_transform(st_read(x, quiet = TRUE), 4326)))
country = read_map(country_file)
maritime = read_map(maritime_file)
province = do.call(rbind, lapply(province_files, read_map))
anhui = read_map(file.path(amap_dir, "province_land", "340000.geojson"))
map_line = function(x) {
  if (any(grepl("POLYGON", as.character(st_geometry_type(x))))) st_geometry(x) = st_boundary(st_geometry(x))
  x
}
project_map = function(x) {
  x = st_transform(x, map_crs)
  x = suppressWarnings(st_simplify(x, dTolerance = 10000, preserveTopology = TRUE))
  x[!st_is_empty(x), ]
}
north_country = project_map(map_line(country))
north_province = project_map(map_line(province))
north_maritime = project_map(map_line(maritime))
main_box_ll = st_bbox(c(xmin = 75.5, ymin = 29, xmax = 133.5, ymax = 52.8), crs = st_crs(4326))
main_box = st_bbox(st_transform(st_as_sfc(main_box_ll), map_crs))
map_xlim = unname(main_box[c("xmin", "xmax")])
map_ylim = c(3200000, 6024402)
map_ylim[1] = min(map_ylim[1], unname(st_bbox(st_transform(anhui, map_crs))["ymin"]) - 30000)

south_cut = unname(st_bbox(anhui)["ymin"])
south_box = st_bbox(c(xmin = 73, ymin = 3, xmax = 135, ymax = south_cut), crs = st_crs(4326))
crop_south = function(x) {
  g = st_geometry(map_line(x)); st_crs(g) = NA
  g = suppressWarnings(st_crop(g, unclass(south_box)))
  g = suppressWarnings(st_collection_extract(g, "LINESTRING")); st_crs(g) = 4326
  project_map(st_sf(geometry = g))
}
south_country = crop_south(country)
south_province = crop_south(province)
south_maritime = crop_south(maritime)
south_all = rbind(south_country, south_province, south_maritime)
south_source = st_bbox(south_all)
panel_width = diff(map_xlim); panel_height = diff(map_ylim)
inset_xmin = map_xlim[2] - 0.170 * panel_width
inset_xmax = map_xlim[2] - 0.006 * panel_width
inset_ymin = map_ylim[1] + 0.018 * panel_height
inset_scale = (inset_xmax - inset_xmin) / unname(south_source["xmax"] - south_source["xmin"])
inset_ymax = inset_ymin + inset_scale * unname(south_source["ymax"] - south_source["ymin"])
move_inset = function(x) {
  g = (st_geometry(x) - unname(south_source[c("xmin", "ymin")])) * inset_scale + c(inset_xmin, inset_ymin)
  st_sf(geometry = st_set_crs(g, map_crs))
}
inset_country = move_inset(south_country)
inset_province = move_inset(south_province)
inset_maritime = move_inset(south_maritime)
inset_frame = st_as_sf(st_as_sfc(st_bbox(c(xmin = inset_xmin, ymin = inset_ymin,
  xmax = inset_xmax, ymax = inset_ymax), crs = map_crs)))

effects_plot = st_transform(effects_geometry, map_crs)
figure_font_family = "sans"
font_subtitle = 10
font_strip = 8
font_legend_text = 6.6
font_legend_title = 7.8

# get_legend() measures text on the current graphics device. Using a temporary
# ragg device avoids the PDF CID-font error that can occur in RStudio/Windows.
get_legend_safe = function(p) {
  tmp = tempfile(fileext = ".png")
  ragg::agg_png(tmp, width = 2400, height = 700, units = "px", res = 300)
  on.exit({dev.off(); unlink(tmp)}, add = TRUE)
  cowplot::get_legend(p)
}

Figure_3_map = ggplot() +
  geom_sf(data = effects_plot, aes(fill = effects), colour = "transparent", linewidth = 0.1) +
  scale_fill_stepsn(colors = rev(brewer.pal(9, "RdPu")),
    breaks = c(-4000, seq(-500, -200, 100), seq(-100, 0, 10)),
    labels = c("", seq(-500, -200, 100), seq(-100, 0, 10)),
    limits = c(-4000, 0), na.value = "white",
    values = rescale(c(-4000, seq(-500, -100, 100), seq(-100, 0, 10))),
    name = bquote((kg~ha^-1~season^-1)),
    guide = guide_colorsteps(direction = "horizontal", title.position = "left",
      label.position = "bottom", barwidth = unit(9, "cm"),
      barheight = unit(0.18, "cm"), ticks = FALSE)) +
  geom_sf(data = north_province, fill = NA, colour = "grey55", linewidth = 0.10) +
  geom_sf(data = north_country, fill = NA, colour = "grey45", linewidth = 0.18) +
  geom_sf(data = inset_province, fill = NA, colour = "grey55", linewidth = 0.08) +
  geom_sf(data = inset_country, fill = NA, colour = "grey45", linewidth = 0.16) +
  geom_sf(data = inset_maritime, fill = NA, colour = "grey45", linewidth = 0.14) +
  geom_sf(data = inset_frame, fill = NA, colour = "grey45", linewidth = 0.20) +
  facet_grid(Model ~ Type, labeller = labeller(Type = c(PRGW = "PRGW"))) +
  coord_sf(crs = map_crs, xlim = map_xlim, ylim = map_ylim,
    expand = FALSE, clip = "on", datum = st_crs(4326)) +
  theme_bw(base_family = figure_font_family, base_size = font_strip) +
  theme(strip.text = element_text(size = font_strip), axis.ticks = element_blank(),
    axis.text = element_blank(), panel.grid.major = element_line(colour = "grey90", linewidth = 0.35),
    panel.grid.minor = element_blank(), legend.position = "top", legend.direction = "horizontal",
    legend.justification = "center", legend.key.height = unit(0.9, "cm"),
    legend.background = element_blank(), legend.text = element_text(size = font_legend_text, angle = 0),
    legend.title = element_text(size = font_legend_title), strip.background = element_rect(colour = "transparent"),
    plot.background = element_rect(fill = "transparent", colour = NA),
    plot.margin = margin(0.5, 0.5, 0.5, 0.5, unit = "mm"))

Figure_3_legend = get_legend_safe(Figure_3_map +
  theme(legend.position = "top", legend.justification = "center",
    legend.box.margin = margin(0, 0, 0, 0), plot.margin = margin(0, 0, 0, 0)))
Figure_3_title = cowplot::ggdraw() + cowplot::draw_label("Yield loss associated with HDW",
  x = 0, y = 0.5, hjust = 0, vjust = 0.5, size = font_subtitle)
Figure_3_top = cowplot::plot_grid(Figure_3_title, Figure_3_legend, nrow = 1,
  rel_widths = c(0.4, 0.96), align = "h")
Figure_3_body = Figure_3_map + theme(legend.position = "none")
Figure_3 = cowplot::plot_grid(Figure_3_top, Figure_3_body, ncol = 1,
  rel_heights = c(0.075, 0.925), align = "v", axis = "lr")

# Six output formats.
w = 17.6 / 2.54; h = 13.4 / 2.54
ggsave(file.path(out_dir, "Figure_3.pdf"), Figure_3, width = w, height = h, device = cairo_pdf, bg = "transparent")
ggsave(file.path(out_dir, "Figure_3.svg"), Figure_3, width = w, height = h, device = svglite::svglite, bg = "transparent")
svg(file.path(out_dir, "Figure_3_word_compatible.svg"), width = w, height = h,
  family = "sans", pointsize = 11, bg = "transparent", onefile = TRUE)
print(Figure_3); dev.off()
devEMF::emf(file.path(out_dir, "Figure_3.emf"), width = w, height = h,
  family = figure_font_family, pointsize = 11, coordDPI = 600, emfPlus = TRUE)
print(Figure_3); dev.off()
ggsave(file.path(out_dir, "Figure_3.tiff"), Figure_3, width = 17.6, height = 13.4,
  units = "cm", dpi = 600, device = ragg::agg_tiff, compression = "lzw", bg = "white")
ggsave(file.path(out_dir, "Figure_3.png"), Figure_3, width = 17.6, height = 13.4,
  units = "cm", dpi = 450, device = ragg::agg_png, bg = "white")
