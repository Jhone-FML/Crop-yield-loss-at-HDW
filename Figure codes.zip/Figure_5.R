# Figure 5 -------------------------------------------------------------
# Direct Excel-based reproduction. This file does not source any other R script.
library(readxl)
ROOT = "F:/Post PHD documents/Crop yield loss at DHW/Submission/NF_proof_2026_09_01/Upload_Ready"
FIGURE_OUTPUT_DIR = file.path(ROOT, "Figures")
AMAP_DIR = "D:/Crop yield loss at DHW/amap"
FIGURE_FONT = "sans"
NF_LEGEND_TEXT_PT = 6.6; NF_LEGEND_TITLE_PT = 7.8
TIFF_DPI = 600; PNG_DPI = 450
MAP_YLIM = c(3200000, 6024402)
INSET_LEFT = 0.170; INSET_RIGHT = 0.006; INSET_BOTTOM = 0.018
BASEMAP_TOLERANCE_M = 10000
dir.create(FIGURE_OUTPUT_DIR, recursive = TRUE, showWarnings = FALSE)
check_packages = function(x) {
  miss = x[!vapply(x, requireNamespace, logical(1), quietly = TRUE)]
  if (length(miss)) stop("Install required package(s): ", paste(miss, collapse = ", "))
}
check_packages(c("svglite", "ragg", "devEMF"))
if (requireNamespace("cowplot", quietly = TRUE)) cowplot::set_null_device("agg")
save_device = function(plot, device, file, ...) {
  device(file, ...); id = dev.cur(); on.exit(if (id %in% dev.list()) dev.off(id), add = TRUE)
  print(plot); invisible(file)
}
export_six = function(plot, name, width_cm, height_cm) {
  prefix = file.path(FIGURE_OUTPUT_DIR, name); w = width_cm / 2.54; h = height_cm / 2.54
  save_device(plot, function(file, ...) cairo_pdf(filename = file, ...), paste0(prefix, ".pdf"),
    width = w, height = h, family = FIGURE_FONT, bg = "transparent")
  save_device(plot, svglite::svglite, paste0(prefix, ".svg"), width = w, height = h, bg = "transparent")
  save_device(plot, svg, paste0(prefix, "_word_compatible.svg"), width = w, height = h,
    family = "sans", pointsize = 11, bg = "transparent", onefile = TRUE)
  save_device(plot, devEMF::emf, paste0(prefix, ".emf"), width = w, height = h,
    family = "sans", pointsize = 11, coordDPI = 600, emfPlus = TRUE)
  save_device(plot, ragg::agg_tiff, paste0(prefix, ".tiff"), width = width_cm, height = height_cm,
    units = "cm", res = TIFF_DPI, compression = "lzw", background = "white")
  save_device(plot, ragg::agg_png, paste0(prefix, ".png"), width = width_cm, height = height_cm,
    units = "cm", res = PNG_DPI, background = "white")
}
export_bundle = function(plot, data, name, width_cm, height_cm) export_six(plot, name, width_cm, height_cm)
map_source_manifest = function(...) data.frame()
join_excel = function(geometry, values, keys, columns) {
  for (k in keys) { geometry[[k]] = as.character(geometry[[k]]); values[[k]] = as.character(values[[k]]) }
  gkey = do.call(paste, c(sf::st_drop_geometry(geometry)[keys], sep = "
"))
  vkey = do.call(paste, c(values[keys], sep = "
")); idx = match(gkey, vkey)
  if (anyNA(idx)) stop("Geometry cannot be matched to Excel for key: ", paste(keys, collapse = ", "))
  for (to in names(columns)) geometry[[to]] = values[[columns[[to]]]][idx]
  geometry
}

library(ggplot2)
library(cowplot)
Importance2 = as.data.frame(read_excel(file.path(ROOT,"Figure_5_source_data.xlsx"),sheet="Figure 5 a"))
names(Importance2)[names(Importance2)=="Percentage (%)"] = "percentage"
Response = as.data.frame(read_excel(file.path(ROOT,"Figure_5_source_data.xlsx"),sheet="Figure 5 b"))
labels_ID = character()
col = c("#8E2043","#BC7A8F","#E0607E","#ECA0B2")
cols = c(HTLH_Early_change="#66C2A5",HTLH_Middle_change="#FC8D62",HTLH_Late_change="#8DA0CB",PRGW_Early_change="#E78AC3",PRGW_Middle_change="#A6D854",PRGW_Late_change="#FFD92F")
legend_levels = names(cols); legend_labels_char = c("HTLH-E","HTLH-M","HTLH-L","PRGW-E","PRGW-M","PRGW-L")

# Figure 5
required_packages <- c(
  "ggplot2", "cowplot", "RColorBrewer", "svglite", "ragg"
)
missing_packages <- required_packages[!vapply(
  required_packages,
  requireNamespace,
  logical(1),
  quietly = TRUE
)]

if (length(missing_packages) > 0) {
  stop(
    paste0(
      "Install the required R package(s) first: ",
      paste(missing_packages, collapse = ", "),
      ".\nRun: install.packages(c(",
      paste(sprintf('"%s"', missing_packages), collapse = ", "),
      "))"
    ),
    call. = FALSE
  )
}

suppressPackageStartupMessages({
  library(ggplot2)
  library(cowplot)
})


required_objects <- c(
  "Importance2", "Response", "labels_ID", "col", "cols",
  "legend_levels", "legend_labels_char"
)
missing_objects <- required_objects[!vapply(
  required_objects,
  function(x) exists(x, inherits = TRUE),
  logical(1)
)]

if (length(missing_objects) > 0) {
  stop(
    paste(
      "Missing required object(s):",
      paste(missing_objects, collapse = ", ")
    ),
    call. = FALSE
  )
}

if (!is.character(col) || !is.character(cols)) {
  stop("col and cols must be character colour vectors.", call. = FALSE)
}

required_columns <- function(data, columns, object_name) {
  missing_columns <- setdiff(columns, names(data))
  if (length(missing_columns) > 0) {
    stop(
      paste(
        object_name, "is missing:",
        paste(missing_columns, collapse = ", ")
      ),
      call. = FALSE
    )
  }
}

required_columns(
  Importance2,
  c("percentage", "Feature", "ID"),
  "Importance2"
)
required_columns(
  Response,
  c("Variables", "Variables_parsed", "x", "y", "ID"),
  "Response"
)

excluded_management_variables <- c(
  "Fertilizer", "Irrigation", "Manure",
  "Mechanization", "Pesticide", "Seed"
)
response_keep <- !is.na(Response$Variables) &
  !Response$Variables %in% excluded_management_variables
Response_plot_data <- Response[response_keep, , drop = FALSE]

if (nrow(Importance2) == 0) {
  stop("Importance2 contains no rows.", call. = FALSE)
}
if (nrow(Response_plot_data) == 0) {
  stop("No rows remain for panel (b).", call. = FALSE)
}

filter_manifest <- data.frame(
  panel = c("a", "b"),
  source_object = c("Importance2", "Response"),
  input_rows = c(nrow(Importance2), nrow(Response)),
  plotted_rows = c(nrow(Importance2), nrow(Response_plot_data)),
  rule = c(
    "All rows",
    paste0(
      "Exclude Variables in: ",
      paste(excluded_management_variables, collapse = ", ")
    )
  ),
  stringsAsFactors = FALSE
)


figure_font_family <- "sans"
font_panel_title <- 11
font_strip <- 9
font_axis_text <- 8.5
font_axis_title <- 9.5
font_legend <- 8
font_percentage <- 2.55


importance_id_levels <- if (is.factor(Importance2$ID)) {
  levels(droplevels(Importance2$ID))
} else {
  unique(as.character(Importance2$ID))
}
importance_id_levels <- importance_id_levels[
  importance_id_levels %in% as.character(Importance2$ID)
]
importance_display_levels <- c(
  "HTLH-E", "HTLH-M", "HTLH-L",
  "PRGW-E", "PRGW-M", "PRGW-L"
)

if (length(importance_id_levels) != length(importance_display_levels)) {
  stop(
    paste0(
      "Panel (a) requires six ID panels, but Importance2 contains ",
      length(importance_id_levels), "."
    ),
    call. = FALSE
  )
}

importance_id_key <- data.frame(
  ID = importance_id_levels,
  ID_display = importance_display_levels,
  stringsAsFactors = FALSE
)
Importance_plot_data <- Importance2
Importance_plot_data$ID_display <- factor(
  importance_display_levels[
    match(as.character(Importance_plot_data$ID), importance_id_levels)
  ],
  levels = importance_display_levels
)

importance_feature_labels <- c(
  "Trends_HTLH_Early" = "HTLH-E",
  "Trends_HTLH_Middle" = "HTLH-M",
  "Trends_HTLH_Late" = "HTLH-L",
  "Trends_PRGW_Early" = "PRGW-E",
  "Trends_PRGW_Middle" = "PRGW-M",
  "Trends_PRGW_Late" = "PRGW-L"
)
importance_legend_labels <- function(x) {
  out <- as.character(x)
  replace <- out %in% names(importance_feature_labels)
  out[replace] <- unname(importance_feature_labels[out[replace]])
  out
}

Importance_gg <- ggplot(
  Importance_plot_data,
  aes(x = 1, y = percentage, fill = Feature)
) +
  geom_col(colour = "white", linewidth = 0.22, width = 1) +
  geom_text(
    aes(
      label = ifelse(
        percentage >= 1,
        paste0(round(percentage, 1), "%"),
        ""
      )
    ),
    position = position_stack(vjust = 0.5),
    colour = "white",
    size = font_percentage,
    lineheight = 0.95
  ) +
  facet_wrap(
    ~ID_display,
    ncol = 6,
    labeller = label_value,
    drop = FALSE
  ) +
  scale_fill_manual(
    name = NULL,
    values = c(
      col,
      c("gray66", "gray68", "gray70", "gray72", "gray74", "gray76")
    ),
    labels = importance_legend_labels,
    guide = guide_legend(
      ncol = 4,
      nrow = 3,
      byrow = TRUE
    )
  ) +
  labs(
    x = NULL,
    y = NULL,
    subtitle = paste0(
      "(a) Importance of drivers in XGBoost\n",
      "at the county scale"
    )
  ) +
  theme_bw(base_family = figure_font_family, base_size = font_axis_text) +
  theme(
    plot.subtitle = element_text(
      size = font_panel_title,
      lineheight = 0.95,
      margin = margin(b = 3)
    ),
    panel.spacing = grid::unit(0.10, "cm"),
    strip.text = element_text(
      size = 8.5,
      margin = margin(t = 2, b = 2)
    ),
    axis.text = element_blank(),
    axis.ticks = element_blank(),
    axis.title = element_blank(),
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.key.width = grid::unit(0.42, "cm"),
    legend.key.height = grid::unit(0.24, "cm"),
    legend.spacing.x = grid::unit(0.10, "cm"),
    legend.text = element_text(size = font_legend),
    legend.title = element_text(size = font_legend),
    legend.background = element_blank(),
    strip.background = element_rect(colour = "transparent"),
    plot.background = element_rect(fill = "transparent", colour = NA),
    plot.margin = margin(2, 3, 2, 3, unit = "mm")
  )


p_1 <- ggplot(
  Response_plot_data,
  aes(x = x, y = y, colour = ID)
) +
  geom_line(linewidth = 0.65) +
  facet_wrap(
    ~Variables_parsed,
    scales = "free_x",
    labeller = label_parsed,
    ncol = 3
  ) +
  scale_colour_manual(
    name = NULL,
    values = cols,
    breaks = legend_levels,
    labels = parse(text = legend_labels_char)
  ) +
  guides(
    colour = guide_legend(
      ncol = 1,
      byrow = TRUE,
      override.aes = list(linewidth = 0.75)
    )
  ) +
  labs(
    x = "Trend of HDW\u00A0(hour year\u207B\u00B9)",
    y = expression(
      italic(beta)[HDW %*% year]~(kg~ha^-1~hour^-1~year^-1)
    ),
    subtitle = paste0(
      "(b) Partial dependence of the drivers\n",
      "at the county scale"
    )
  ) +
  theme_bw(base_family = figure_font_family, base_size = font_axis_text) +
  theme(
    plot.subtitle = element_text(
      size = font_panel_title,
      lineheight = 0.95,
      margin = margin(b = 3)
    ),
    strip.text = element_text(size = font_strip),
    axis.text.x = element_text(
      size = font_axis_text,
      angle = 45,
      vjust = 1,
      hjust = 1
    ),
    axis.text.y = element_text(size = font_axis_text),
    axis.title = element_text(size = font_axis_title),
    legend.position = "inside",
    legend.position.inside = c(0.025, 0.975),
    legend.justification = c(0, 1),
    legend.direction = "vertical",
    legend.key.width = grid::unit(0.38, "cm"),
    legend.key.height = grid::unit(0.20, "cm"),
    legend.spacing.y = grid::unit(0.01, "cm"),
    legend.text = element_text(size = font_legend),
    legend.title = element_text(size = font_legend),
    legend.background = element_blank(),
    strip.background = element_rect(colour = "transparent"),
    plot.background = element_rect(fill = "transparent", colour = NA),
    plot.margin = margin(2, 2, 2, 2, unit = "mm")
  )


Figure_5_gg <- cowplot::ggdraw() +
  cowplot::draw_plot(
    Importance_gg,
    x = 0,
    y = 0,
    width = 0.55,
    height = 1
  ) +
  cowplot::draw_plot(
    p_1,
    x = 0.55,
    y = 0,
    width = 0.45,
    height = 1
  )



if (!identical(Sys.getenv("HDW_SKIP_EXPORT"), "1")) export_bundle(
  Figure_5_gg,
  list(driver_importance = Importance_plot_data, partial_dependence = Response_plot_data,
       filter_manifest = filter_manifest, importance_id_key = importance_id_key),
  "Figure_5", 20, 12
)
export_six(Figure_5_gg, "Figure_5", 20, 12)

