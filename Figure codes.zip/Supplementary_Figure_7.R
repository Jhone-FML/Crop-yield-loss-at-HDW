# Supplementary Figure 7 -------------------------------------------------------------
# Direct Excel-based reproduction. This file does not source any other R script.
library(readxl)
ROOT = "F:/Post PHD documents/Crop yield loss at DHW/Submission/NF_proof_2026_09_01/Upload_Ready"
FIGURE_OUTPUT_DIR = file.path(ROOT, "Figures")
AMAP_DIR = "D:/Crop yield loss at DHW/amap"
FIGURE_FONT = "sans"
NF_LEGEND_TEXT_PT = 6.6; NF_LEGEND_TITLE_PT = 7.8
TIFF_DPI = 600; PNG_DPI = 450
MAP_YLIM = c(3200000, 6024402)
INSET_LEFT = 0.170; INSET_RIGHT = 0.006; INSET_BOTTOM = 0.018
BASEMAP_TOLERANCE_M = 10000
dir.create(FIGURE_OUTPUT_DIR, recursive = TRUE, showWarnings = FALSE)
check_packages = function(x) {
  miss = x[!vapply(x, requireNamespace, logical(1), quietly = TRUE)]
  if (length(miss)) stop("Install required package(s): ", paste(miss, collapse = ", "))
}
check_packages(c("svglite", "ragg", "devEMF"))
if (requireNamespace("cowplot", quietly = TRUE)) cowplot::set_null_device("agg")
save_device = function(plot, device, file, ...) {
  device(file, ...); id = dev.cur(); on.exit(if (id %in% dev.list()) dev.off(id), add = TRUE)
  print(plot); invisible(file)
}
export_six = function(plot, name, width_cm, height_cm) {
  prefix = file.path(FIGURE_OUTPUT_DIR, name); w = width_cm / 2.54; h = height_cm / 2.54
  save_device(plot, function(file, ...) cairo_pdf(filename = file, ...), paste0(prefix, ".pdf"),
    width = w, height = h, family = FIGURE_FONT, bg = "transparent")
  save_device(plot, svglite::svglite, paste0(prefix, ".svg"), width = w, height = h, bg = "transparent")
  save_device(plot, svg, paste0(prefix, "_word_compatible.svg"), width = w, height = h,
    family = "sans", pointsize = 11, bg = "transparent", onefile = TRUE)
  save_device(plot, devEMF::emf, paste0(prefix, ".emf"), width = w, height = h,
    family = "sans", pointsize = 11, coordDPI = 600, emfPlus = TRUE)
  save_device(plot, ragg::agg_tiff, paste0(prefix, ".tiff"), width = width_cm, height = height_cm,
    units = "cm", res = TIFF_DPI, compression = "lzw", background = "white")
  save_device(plot, ragg::agg_png, paste0(prefix, ".png"), width = width_cm, height = height_cm,
    units = "cm", res = PNG_DPI, background = "white")
}
export_bundle = function(plot, data, name, width_cm, height_cm) export_six(plot, name, width_cm, height_cm)
map_source_manifest = function(...) data.frame()
join_excel = function(geometry, values, keys, columns) {
  for (k in keys) { geometry[[k]] = as.character(geometry[[k]]); values[[k]] = as.character(values[[k]]) }
  gkey = do.call(paste, c(sf::st_drop_geometry(geometry)[keys], sep = "
"))
  vkey = do.call(paste, c(values[keys], sep = "
")); idx = match(gkey, vkey)
  if (anyNA(idx)) stop("Geometry cannot be matched to Excel for key: ", paste(keys, collapse = ", "))
  for (to in names(columns)) geometry[[to]] = values[[columns[[to]]]][idx]
  geometry
}

library(ggplot2)
library(ggpattern)
EX_df_mean = as.data.frame(read_excel(file.path(ROOT,"Supplementary_Figure_7_source_data.xlsx"),sheet="Supplementary Figure 7"))
EX_df_mean$col=paste(EX_df_mean$Var,EX_df_mean$Y_levle,sep="_")

# Supplementary Figure 7: climate-variable effects
library(ggplot2)
library(ggpattern)
library(grid)
library(RColorBrewer)

CLEX_df_means_gg = ggplot( EX_df_mean, aes(x = Var, y = Estimate,
                                           color = col,fill = col))+
  geom_bar_pattern(stat = "identity",alpha = 0.7, lwd= 0.05,aes(pattern = col),
                   position = position_dodge(.9),
                   color = "black", 
                   pattern_fill = "black",
                   pattern_angle = 45,
                   pattern_density = 0.000001,
                   pattern_size = .05,
                   pattern_spacing = 0.1,
                   pattern_key_scale_factor = 0.1) +
  geom_errorbar(aes(ymin=Estimate-sd, ymax=Estimate+sd), width=.2,
                linewidth = 0.5, position=position_dodge(.9))+
  scale_pattern_manual(values = c("none", "stripe","none", "stripe","none", "stripe",
                                  "none", "stripe","none", "stripe","none", "stripe",
                                  "none", "stripe"),name = '') +
  scale_fill_manual(values = c(brewer.pal(11, "PRGn")[2],brewer.pal(11, "PRGn")[2],
                               brewer.pal(11, "PRGn")[3],brewer.pal(11, "PRGn")[3],
                               brewer.pal(11, "PRGn")[9],brewer.pal(11, "PRGn")[9],
                               brewer.pal(11, "PRGn")[10],
                               brewer.pal(11, "PRGn")[10]))+
  scale_color_manual(values = c(brewer.pal(11, "PRGn")[2],brewer.pal(11, "PRGn")[2],
                                brewer.pal(11, "PRGn")[3],brewer.pal(11, "PRGn")[3],
                                brewer.pal(11, "PRGn")[9],brewer.pal(11, "PRGn")[9],
                                brewer.pal(11, "PRGn")[10],
                                brewer.pal(11, "PRGn")[10]))+
  facet_grid(DHW_sou~Model)+
  scale_x_discrete('Standardize climate indices',labels = c(
    "PJFDD" = bquote(FDD[pT-JT]),
    "JHFDD" = bquote(FDD[JT-HD]),
    "JHEDD" = bquote(EDD[JT-HD]),
    "HMEDD" = bquote(EDD[HD-MT]),
    "hdw_hour1" = bquote(DHW[HTLH]),
    'hdw_hour2' = bquote(DHW[PRGW]),
    "hdw_hour3" = bquote(DHW[DTWD])
  ))+ylab("Yield effects by per standard unit (%)")+theme_bw()+
  theme(
    strip.text = element_text(size = 9),
    axis.text.x = element_text(size = 9, angle = 45, vjust = 0.5),
    axis.text.y = element_text(size = 9, angle = 0, vjust = 0.5),
    axis.title = element_text(size = 10),
    legend.position = c(10.3, 0.95),
    # legend.direction = "horizontal",
    legend.key.height = unit(0.12, "cm"),
    legend.background = element_blank(),
    legend.text = element_text(size = 6),
    legend.title = element_text(size = 6),
    strip.background = element_rect(color = "transparent"),
    plot.background = element_rect(
      fill = "transparent",
      colour = NA_character_
    )
  )



if (!identical(Sys.getenv("HDW_SKIP_EXPORT"), "1")) export_bundle(
  CLEX_df_means_gg, list(plot_data = EX_df_mean),
  "Supplementary_Figure_7", 14.8, 7.8
)

export_six(CLEX_df_means_gg,   "Supplementary_Figure_7", 14.8, 7.8)


