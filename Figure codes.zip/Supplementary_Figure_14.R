# Supplementary Figure 14 -------------------------------------------------------------
# Direct Excel-based reproduction. This file does not source any other R script.
library(readxl)
ROOT = "F:/Post PHD documents/Crop yield loss at DHW/Submission/NF_proof_2026_09_01/Upload_Ready"
FIGURE_OUTPUT_DIR = file.path(ROOT,"Figures")
AMAP_DIR = "D:/Crop yield loss at DHW/amap"
FIGURE_FONT = "sans"
NF_LEGEND_TEXT_PT = 6.6; NF_LEGEND_TITLE_PT = 7.8
TIFF_DPI=600; PNG_DPI=450
MAP_YLIM=c(3200000,6024402)
INSET_LEFT=.170; INSET_RIGHT=.006; INSET_BOTTOM=.018
BASEMAP_TOLERANCE_M=10000
dir.create(FIGURE_OUTPUT_DIR,recursive=TRUE,showWarnings=FALSE)
check_packages=function(x){m=x[!vapply(x,requireNamespace,logical(1),quietly=TRUE)];if(length(m))stop("Install required package(s): ",paste(m,collapse=", "))}
check_packages(c("svglite","ragg","devEMF"))
if(requireNamespace("cowplot",quietly=TRUE)) cowplot::set_null_device("agg")
save_device=function(plot,device,file,...){device(file,...);id=dev.cur();on.exit(if(id %in% dev.list())dev.off(id),add=TRUE);print(plot);invisible(file)}
export_six=function(plot,name,width_cm,height_cm){prefix=file.path(FIGURE_OUTPUT_DIR,name);w=width_cm/2.54;h=height_cm/2.54;
 save_device(plot,function(file,...)cairo_pdf(filename=file,...),paste0(prefix,".pdf"),width=w,height=h,family=FIGURE_FONT,bg="transparent");
 save_device(plot,svglite::svglite,paste0(prefix,".svg"),width=w,height=h,bg="transparent");
 save_device(plot,svg,paste0(prefix,"_word_compatible.svg"),width=w,height=h,family="sans",pointsize=11,bg="transparent",onefile=TRUE);
 save_device(plot,devEMF::emf,paste0(prefix,".emf"),width=w,height=h,family="sans",pointsize=11,coordDPI=600,emfPlus=TRUE);
 save_device(plot,ragg::agg_tiff,paste0(prefix,".tiff"),width=width_cm,height=height_cm,units="cm",res=TIFF_DPI,compression="lzw",background="white");
 save_device(plot,ragg::agg_png,paste0(prefix,".png"),width=width_cm,height=height_cm,units="cm",res=PNG_DPI,background="white")}
export_bundle=function(plot,data,name,width_cm,height_cm)export_six(plot,name,width_cm,height_cm)
join_excel=function(geometry,values,keys,columns){for(k in keys){geometry[[k]]=as.character(geometry[[k]]);values[[k]]=as.character(values[[k]])};gk=do.call(paste,c(sf::st_drop_geometry(geometry)[keys],sep="
"));vk=do.call(paste,c(values[keys],sep="
"));i=match(gk,vk);if(anyNA(i))stop("Geometry cannot be matched to Excel: ",paste(keys,collapse=", "));for(to in names(columns))geometry[[to]]=values[[columns[[to]]]][i];geometry}

prepare_latest_amap=local({cache=NULL;function(amap_dir=AMAP_DIR){if(!is.null(cache)&&identical(cache$amap_dir,amap_dir))return(cache);crs=sf::st_crs(paste("+proj=aea +lat_1=25 +lat_2=47 +lat_0=0 +lon_0=105","+datum=WGS84 +units=m +no_defs"));files=c(country=file.path(amap_dir,"land","100000.geojson"),maritime=file.path(amap_dir,"maritime","100000.geojson"),anhui=file.path(amap_dir,"province_land","340000.geojson"));pf=sort(list.files(file.path(amap_dir,"province_land"),"[.]geojson$",full.names=TRUE));readg=function(p)sf::st_sf(geometry=sf::st_geometry(sf::st_transform(sf::st_read(p,quiet=TRUE),4326)));country=readg(files["country"]);maritime=readg(files["maritime"]);anhui=readg(files["anhui"]);province=do.call(rbind,lapply(pf,readg));cut=unname(sf::st_bbox(anhui)["ymin"]);asline=function(x){if(any(grepl("POLYGON",as.character(sf::st_geometry_type(x)))))sf::st_geometry(x)=sf::st_boundary(sf::st_geometry(x));x};project=function(x){x=sf::st_transform(x,crs);x=suppressWarnings(sf::st_simplify(x,BASEMAP_TOLERANCE_M,preserveTopology=TRUE));x[!sf::st_is_empty(x),]};lines=lapply(list(country,province,maritime),asline);north=lapply(lines,project);main=sf::st_bbox(sf::st_transform(sf::st_as_sfc(sf::st_bbox(c(xmin=75.5,ymin=29,xmax=133.5,ymax=52.8),crs=sf::st_crs(4326))),crs));xlim=unname(main[c("xmin","xmax")]);ylim=MAP_YLIM;ylim[1]=min(ylim[1],unname(sf::st_bbox(sf::st_transform(anhui,crs))["ymin"])-30000);box=sf::st_bbox(c(xmin=73,ymin=3,xmax=135,ymax=cut),crs=sf::st_crs(4326));crop=function(x){g=sf::st_geometry(x);sf::st_crs(g)=NA;g=suppressWarnings(sf::st_crop(g,unclass(box)));g=suppressWarnings(sf::st_collection_extract(g,"LINESTRING"));sf::st_crs(g)=4326;project(sf::st_sf(geometry=g))};south=lapply(lines,crop);src=sf::st_bbox(do.call(rbind,south));pw=diff(xlim);ph=diff(ylim);xmin=xlim[2]-INSET_LEFT*pw;xmax=xlim[2]-INSET_RIGHT*pw;ymin=ylim[1]+INSET_BOTTOM*ph;sc=(xmax-xmin)/unname(src["xmax"]-src["xmin"]);ymax=ymin+sc*unname(src["ymax"]-src["ymin"]);inset=lapply(south,function(x){g=(sf::st_geometry(x)-unname(src[c("xmin","ymin")]))*sc+c(xmin,ymin);sf::st_sf(geometry=sf::st_set_crs(g,crs))});frame=sf::st_as_sf(sf::st_as_sfc(sf::st_bbox(c(xmin=xmin,ymin=ymin,xmax=xmax,ymax=ymax),crs=crs)));cache<<-list(amap_dir=amap_dir,crs=crs,xlim=xlim,ylim=ylim,north=north,inset=inset,frame=frame,south_cut_lat=cut,province_files=pf,country_file=files["country"],maritime_file=files["maritime"]);cache}})
latest_amap_layers=function(b){line=function(x,col,w)ggplot2::geom_sf(data=x,fill=NA,colour=col,linewidth=w,inherit.aes=FALSE,show.legend=FALSE);list(line(b$north[[2]],"grey55",.10),line(b$north[[1]],"grey45",.18),line(b$inset[[2]],"grey55",.08),line(b$inset[[1]],"grey45",.16),line(b$inset[[3]],"grey45",.14),line(b$frame,"grey45",.20))}
latest_amap_manifest=function(b)data.frame()

library(ggplot2)
library(cowplot)
library(ggtern)
library(sf)
box=as.data.frame(read_excel(file.path(ROOT,"Supplementary_Figure_14_source_data.xlsx"),sheet="Supplementary Figure 14 boxplot"))
names(box)[names(box)=="Yield anomaly (%)"]="Y_anomly_pc"
pie=as.data.frame(read_excel(file.path(ROOT,"Supplementary_Figure_14_source_data.xlsx"),sheet="Supplementary Figure 14 pie"))
tern=as.data.frame(read_excel(file.path(ROOT,"Supplementary_Figure_14_source_data.xlsx"),sheet="Supplementary Figure 14 key"))
m=as.data.frame(read_excel(file.path(ROOT,"Supplementary_Figure_14_source_data.xlsx"),sheet="Supplementary Figure 14 map"))
sites=st_read(file.path(ROOT,"Supplementary_Figure_14_geometry.gpkg"),layer="sites",quiet=TRUE)
sites=join_excel(sites,m,"site",c(point_colour="point_colour"));b=prepare_latest_amap();sites=st_transform(sites,b$crs);set2=RColorBrewer::brewer.pal(3,"Set2")

pie_theme=theme_void(base_family=FIGURE_FONT)+theme(plot.subtitle=element_text(size=7.5,hjust=.5,lineheight=1),legend.position="bottom",legend.direction="vertical",legend.text=element_text(size=NF_LEGEND_TEXT_PT),legend.key.width=unit(.28,"cm"),legend.key.height=unit(.18,"cm"),legend.margin=margin(0,0,0,0),plot.margin=margin(1,1,1,1,unit="mm"),plot.background=element_rect(fill="transparent",colour=NA))
make_pie=function(group_name,subtitle)ggplot(pie[pie$Group==group_name,],aes(x="",y=value,fill=Type))+geom_col(width=1,colour="white",linewidth=.2)+geom_text(aes(label=sprintf("%.1f",value)),position=position_stack(vjust=.5),size=2.7)+coord_polar(theta="y")+scale_fill_brewer(palette="Set2",name=NULL,guide=guide_legend(ncol=1,byrow=TRUE))+labs(subtitle=subtitle)+pie_theme
p1=make_pie("Percentage of varieties under DHW exposure","Percentage of varieties
under DHW exposure (%)");p2=make_pie("Percentage of varieties in yield loss attributed to DHW","Percentage of varieties in
yield loss attributed to DHW (%)")
pb=ggplot(box,aes(Group,Y_anomly_pc,fill=Group))+geom_boxplot(width=.5,outlier.shape=NA,linewidth=.5)+geom_hline(yintercept=0,linewidth=.5,linetype="dashed")+stat_summary(aes(label=after_stat(sprintf("%.1f",y))),fun=mean,geom="text",colour="red",size=2.7,vjust=-1.2)+scale_fill_brewer(palette="Set2")+scale_x_discrete(expand=expansion(add=.45))+scale_y_continuous(limits=c(-25,25),breaks=seq(-25,25,5))+labs(x=NULL,y="Changes in yield of variety
clusters with HDW exposure (%)")+theme_minimal(base_family=FIGURE_FONT,base_size=8)+theme(axis.text=element_text(size=7.2,colour="black"),axis.text.x=element_text(margin=margin(t=2)),axis.title=element_text(size=8,colour="black"),axis.title.y=element_text(size=7,lineheight=.90,margin=margin(r=1)),legend.position="none",panel.grid=element_blank(),plot.margin=margin(2,1,2,5,unit="mm"),plot.background=element_rect(fill="transparent",colour=NA))
pm=ggplot()+geom_sf(data=sites,aes(colour=point_colour),size=2)+scale_colour_identity()+latest_amap_layers(b)+coord_sf(crs=b$crs,xlim=b$xlim,ylim=b$ylim,expand=FALSE,clip="on",datum=st_crs(4326))+theme_bw(base_family=FIGURE_FONT)+theme(axis.text=element_blank(),axis.ticks=element_blank(),axis.title=element_blank(),legend.position="none",panel.grid.major=element_line(colour="grey90",linewidth=.28),panel.grid.minor=element_blank(),plot.margin=margin(0,0,0,0),plot.background=element_rect(fill="transparent",colour=NA))
key=ggtern(tern,aes(c1,c2,z=c3,colour=colour))+geom_point(size=1.5)+scale_colour_identity()+labs(L=NULL,T=NULL,R=NULL)+theme_void(base_family=FIGURE_FONT)+ggtern::theme_hidetitles()+ggtern::theme_hidelabels()+ggtern::theme_hideticks()+theme(plot.margin=margin(0,0,0,0),plot.background=element_rect(fill="transparent",colour=NA))

Supplementary_Figure_14= ggdraw()+
  draw_plot(pm,0,0,1,1)+
  draw_plot(p1,.06,.56,.22,.41)+
  draw_plot(p2,.06,.06,.22,.41)+
  draw_plot(pb,.42,.34,.30,.58)+
  draw_plot(key,.865,.285,.105,.16)+
  draw_label("Cluster 2",.9175,.46,size=5,fontfamily=FIGURE_FONT)+
  draw_label("Cluster 1",.845,.275,hjust=0,size=5,fontfamily=FIGURE_FONT)+
  draw_label("Cluster 3",.975,.275,hjust=1,size=5,fontfamily=FIGURE_FONT)
export_six(Supplementary_Figure_14,"Supplementary_Figure_14",14,7.6)
