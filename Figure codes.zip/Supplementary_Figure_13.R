# Supplementary Figure 13 -------------------------------------------------------------
# Direct Excel-based reproduction. This file does not source any other R script.
library(readxl)
ROOT = "F:/Post PHD documents/Crop yield loss at DHW/Submission/NF_proof_2026_09_01/Upload_Ready"
FIGURE_OUTPUT_DIR = file.path(ROOT,"Figures")
AMAP_DIR = "D:/Crop yield loss at DHW/amap"
FIGURE_FONT = "sans"
NF_LEGEND_TEXT_PT = 6.6; NF_LEGEND_TITLE_PT = 7.8
TIFF_DPI=600; PNG_DPI=450
MAP_YLIM=c(3200000,6024402)
INSET_LEFT=.170; INSET_RIGHT=.006; INSET_BOTTOM=.018
BASEMAP_TOLERANCE_M=10000
dir.create(FIGURE_OUTPUT_DIR,recursive=TRUE,showWarnings=FALSE)
check_packages=function(x){m=x[!vapply(x,requireNamespace,logical(1),quietly=TRUE)];if(length(m))stop("Install required package(s): ",paste(m,collapse=", "))}
check_packages(c("svglite","ragg","devEMF"))
if(requireNamespace("cowplot",quietly=TRUE)) cowplot::set_null_device("agg")
save_device=function(plot,device,file,...){device(file,...);id=dev.cur();on.exit(if(id %in% dev.list())dev.off(id),add=TRUE);print(plot);invisible(file)}
export_six=function(plot,name,width_cm,height_cm){prefix=file.path(FIGURE_OUTPUT_DIR,name);w=width_cm/2.54;h=height_cm/2.54;
 save_device(plot,function(file,...)cairo_pdf(filename=file,...),paste0(prefix,".pdf"),width=w,height=h,family=FIGURE_FONT,bg="transparent");
 save_device(plot,svglite::svglite,paste0(prefix,".svg"),width=w,height=h,bg="transparent");
 save_device(plot,svg,paste0(prefix,"_word_compatible.svg"),width=w,height=h,family="sans",pointsize=11,bg="transparent",onefile=TRUE);
 save_device(plot,devEMF::emf,paste0(prefix,".emf"),width=w,height=h,family="sans",pointsize=11,coordDPI=600,emfPlus=TRUE);
 save_device(plot,ragg::agg_tiff,paste0(prefix,".tiff"),width=width_cm,height=height_cm,units="cm",res=TIFF_DPI,compression="lzw",background="white");
 save_device(plot,ragg::agg_png,paste0(prefix,".png"),width=width_cm,height=height_cm,units="cm",res=PNG_DPI,background="white")}
export_bundle=function(plot,data,name,width_cm,height_cm)export_six(plot,name,width_cm,height_cm)
join_excel=function(geometry,values,keys,columns){for(k in keys){geometry[[k]]=as.character(geometry[[k]]);values[[k]]=as.character(values[[k]])};gk=do.call(paste,c(sf::st_drop_geometry(geometry)[keys],sep=""));vk=do.call(paste,c(values[keys],sep=""));i=match(gk,vk);if(anyNA(i))stop("Geometry cannot be matched to Excel: ",paste(keys,collapse=", "));for(to in names(columns))geometry[[to]]=values[[columns[[to]]]][i];geometry}

library(ggplot2)
agreement=as.data.frame(read_excel(file.path(ROOT,"Supplementary_Figure_13_source_data.xlsx"),sheet="Supplementary Figure 13"))

level_values=unique(as.character(agreement$level));colours=setNames(c("#1f77b4","#1a57b0")[seq_along(level_values)],level_values)
groups=split(agreement,interaction(agreement$level,agreement$var_hdw,drop=TRUE))
eq=do.call(rbind,lapply(groups,function(z){fit=lm(xgb_Pre~fxm_est,data=z);b=coef(fit);r2=summary(fit)$r.squared;sign=if(b[2]<0)"~-~" else "~+~";data.frame(level=z$level[1],var_hdw=z$var_hdw[1],label=paste0("atop(italic(y)==",formatC(b[1],format="g",digits=3),sign,formatC(abs(b[2]),format="g",digits=3),"*italic(x),italic(R)^2==",formatC(r2,format="f",digits=2),")"))}))
Supplementary_Figure_13=ggplot(agreement,aes(fxm_est,xgb_Pre,colour=level))+geom_point(alpha=.30,size=.95)+geom_abline(intercept=0,slope=1,colour="black",linetype="dashed",linewidth=.65)+geom_smooth(aes(group=1),method="lm",formula=y~x,se=FALSE,colour="red3",linewidth=.75)+geom_text(data=eq,aes(x=-Inf,y=Inf,label=label),inherit.aes=FALSE,parse=TRUE,hjust=-.05,vjust=1.15,size=3.45,colour="black")+facet_wrap(level~var_hdw,scales="free")+scale_colour_manual(values=colours,name=NULL)+labs(x="FIE estimation (kg ha⁻¹ hour⁻¹)",y="XGB prediction (kg ha⁻¹ hour⁻¹)")+theme_bw(base_family=FIGURE_FONT,base_size=10.5)+theme(strip.text=element_text(size=10.2,colour="black"),text=element_text(size=10.5,colour="black"),axis.text=element_text(size=9.8),axis.title=element_text(size=11.2),legend.position="none",panel.spacing=grid::unit(.18,"cm"),strip.background=element_rect(colour="transparent"),plot.background=element_rect(fill="transparent",colour=NA),plot.margin=margin(3,4,3,3,unit="mm"))
export_six(Supplementary_Figure_13,"Supplementary_Figure_13",24,18)
