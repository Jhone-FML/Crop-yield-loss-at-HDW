# Supplementary Figure 20 -------------------------------------------------------------
ROOT="F:/Post PHD documents/Crop yield loss at DHW/Submission/NF_proof_2026_09_01/Upload_Ready"
load(file.path(ROOT,"Supplementary_Figure_20_source_data.RData"),envir=.GlobalEnv)
# Supplementary Figures 18 -> 19 -> 20 -> 21 -> 22
# Load the original analysis objects, then source this file (UTF-8).
# Six exports per figure: PDF, SVG, Word-compatible vector SVG, EMF, TIFF, PNG.
# Validation panels retain the supplied bins, filters, fits and RMSE definitions.
# Map panels retain all trend observations; only their visible window is cropped.

AMAP_DIR <- "D:/Crop yield loss at DHW/amap"
OUTPUT_DIR <- file.path(ROOT, "Figures")
FIGURES_TO_RUN <- integer(0)
FIGURE_SIZE_CM <- list(`18` = c(14, 11.5), `19` = c(17.2, 8.4),
                      `20` = c(18, 9.5), `21` = c(18.3, 16.6), `22` = c(18.3, 6.8))
FIGURE_FONT <- "sans"
TIFF_DPI <- 600
PNG_DPI <- 450
MAP_YLIM <- c(3200000, 6024402)
INSET_LEFT <- 0.170                       # fraction measured from panel right
INSET_RIGHT <- 0.006
INSET_BOTTOM <- 0.018
BOUNDARY_TOLERANCE_M <- 10000              # inherited basemap simplification only

# 0. Shared validation, export and plotting helpers --------------------------
check_packages <- function(packages) {
  missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing)) stop("Install packages first: install.packages(c(",
    paste(sprintf('"%s"', missing), collapse = ", "), "))", call. = FALSE)
}
get_data <- function(name, columns, numeric_columns = character(), env = parent.frame()) {
  if (!exists(name, envir = env, inherits = TRUE)) stop("Missing object: ", name, call. = FALSE)
  x <- get(name, envir = env, inherits = TRUE)
  missing <- setdiff(columns, names(x))
  if (length(missing)) stop(name, " is missing: ", paste(missing, collapse = ", "), call. = FALSE)
  if (!all(vapply(numeric_columns, function(n) is.numeric(x[[n]]), logical(1))))
    stop(name, ": expected numeric columns: ", paste(numeric_columns, collapse = ", "), call. = FALSE)
  x
}
format_number <- function(x, digits) {
  ifelse(is.finite(x), formatC(x, format = "f", digits = digits), "NA")
}
format_p <- function(p) {
  if (!is.finite(p)) return("P = NA")
  if (p < 2.2e-16) return("P < 2.2e-16")
  paste0("P = ", formatC(p, format = if (p < 0.001) "e" else "f",
                        digits = if (p < 0.001) 2 else 3))
}

export_six <- function(plot, number, out_dir = OUTPUT_DIR,
                       size_cm = FIGURE_SIZE_CM[[as.character(number)]]) {
  check_packages(c("svglite", "ragg", "devEMF"))
  if (!isTRUE(capabilities("cairo"))) stop("R requires Cairo support for PDF and Word SVG.")
  if (length(size_cm) != 2L || any(!is.finite(size_cm) | size_cm <= 0)) stop("Invalid figure size.")
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  prefix <- file.path(out_dir, paste0("Supplementary_Figure_", number))
  w <- size_cm[1] / 2.54; h <- size_cm[2] / 2.54
  save_device <- function(device, path, ...) {
    device(path, ...)
    device_id <- grDevices::dev.cur()
    on.exit(if (device_id %in% grDevices::dev.list()) grDevices::dev.off(device_id), add = TRUE)
    print(plot)
    invisible(path)
  }
  open_pdf <- function(path, ...) grDevices::cairo_pdf(filename = path, ...)
  open_svg <- function(path, ...) svglite::svglite(file = path, ...)
  save_device(open_pdf, paste0(prefix, ".pdf"), width = w, height = h,
              family = FIGURE_FONT, bg = "transparent", fallback_resolution = TIFF_DPI)
  save_device(open_svg, paste0(prefix, ".svg"), width = w, height = h,
              bg = "transparent")
  # Cairo writes glyph outlines as vector paths, including superscript minus.
  # This SVG has vector content; it is not a PNG embedded in an SVG container.
  save_device(grDevices::svg, paste0(prefix, "_word_compatible.svg"), width = w,
              height = h, family = "sans", pointsize = 11, bg = "transparent")
  save_device(devEMF::emf, paste0(prefix, ".emf"), width = w, height = h,
              family = FIGURE_FONT, pointsize = 11, coordDPI = 600, emfPlus = TRUE)
  save_device(ragg::agg_tiff, paste0(prefix, ".tiff"), width = size_cm[1], height = size_cm[2],
              units = "cm", res = TIFF_DPI, compression = "lzw", background = "white")
  save_device(ragg::agg_png, paste0(prefix, ".png"), width = size_cm[1], height = size_cm[2],
              units = "cm", res = PNG_DPI, background = "white")
  paths <- paste0(prefix, c(".pdf", ".svg", "_word_compatible.svg", ".emf", ".tiff", ".png"))
  if (!all(file.exists(paths)) || any(file.info(paths)$size == 0)) stop("An export is missing: ", prefix)
  word_svg <- readLines(paths[3], warn = FALSE)
  if (any(grepl("<image\\b", word_svg))) stop("Unexpected raster content in Word SVG: ", paths[3])
  message("Exported six formats: ", prefix)
  invisible(paths)
}

count_guide <- function() ggplot2::guide_colourbar(
  display = "rectangles", title.position = "top", title.hjust = 0.5,
  barheight = grid::unit(26, "mm"), barwidth = grid::unit(3.2, "mm"),
  ticks.colour = "black", frame.colour = "black"
)
validation_theme <- function(classic = FALSE) {
  base <- if (classic) ggplot2::theme_classic else ggplot2::theme_gray
  base(base_family = FIGURE_FONT, base_size = 9) + ggplot2::theme(
    axis.title = ggplot2::element_text(size = 9, colour = "black"),
    axis.text = ggplot2::element_text(size = 8, colour = "black"),
    strip.text = ggplot2::element_text(size = 9, face = "bold", colour = "black"),
    panel.spacing.x = grid::unit(4, "mm"), legend.position = "right",
    legend.title = ggplot2::element_text(size = 8, lineheight = 0.95),
    legend.text = ggplot2::element_text(size = 7.5),
    legend.background = ggplot2::element_blank(),
    plot.background = ggplot2::element_rect(fill = "transparent", colour = NA),
    plot.margin = ggplot2::margin(2, 2, 2, 2, unit = "mm")
  )
}
paired_data <- function(x, x_col, y_col, group_col = NULL, group_order = NULL, id) {
  group <- if (is.null(group_col)) rep("All", nrow(x)) else as.character(x[[group_col]])
  if (is.null(group_order)) group_order <- if (!is.null(group_col) && is.factor(x[[group_col]]))
    levels(droplevels(x[[group_col]])) else unique(group[!is.na(group)])
  unknown <- setdiff(unique(group[!is.na(group)]), group_order)
  if (length(unknown)) stop(id, ": unrecognised groups: ", paste(unknown, collapse = ", "))
  d <- data.frame(x = x[[x_col]], y = x[[y_col]], Group = factor(group, levels = group_order))
  keep <- is.finite(d$x) & is.finite(d$y) & !is.na(d$Group)
  message(id, ": input ", nrow(d), "; finite paired rows ", sum(keep), "; excluded ", sum(!keep))
  print(table(Group = d$Group, included = keep, useNA = "ifany"))
  d <- d[keep, , drop = FALSE]
  if (!nrow(d) || any(table(d$Group) < 3L)) stop(id, ": each group needs at least three finite pairs.")
  d
}
pair_stats <- function(d, residual_rmse = FALSE, units = "", extra = FALSE) {
  # Same ordinary least-squares fit as lm(y ~ x), using sufficient statistics.
  # SF19 keeps its original regression-residual RMSE; SF18/20 use y-x RMSE.
  out <- lapply(levels(d$Group), function(g) {
    z <- d[d$Group == g, , drop = FALSE]; n <- nrow(z)
    mx <- mean(z$x); my <- mean(z$y)
    sxx <- sum((z$x - mx)^2); syy <- sum((z$y - my)^2)
    sxy <- sum((z$x - mx) * (z$y - my))
    if (sxx <= 0 || syy <= 0) stop("Constant observations in group: ", g)
    b1 <- sxy / sxx; b0 <- my - b1 * mx
    sse <- sum((z$y - (b0 + b1 * z$x))^2)
    se <- sqrt((sse / (n - 2)) / sxx)
    p <- 2 * stats::pt(-abs(b1 / se), df = n - 2)
    adj_r2 <- 1 - (sse / syy) * (n - 1) / (n - 2)
    rmse <- if (residual_rmse) sqrt(sse / n) else sqrt(mean((z$y - z$x)^2))
    equation <- paste0("y = ", format_number(b0, 2), if (b1 < 0) " - " else " + ",
                       format_number(abs(b1), 3), "x")
    label <- paste0(equation, "\nAdjusted R\u00b2 = ", format_number(adj_r2, 3),
      "; ", if (residual_rmse) "Residual RMSE = " else "RMSE = ", format_number(rmse, 2), units,
      if (extra) paste0("\nMAE = ", format_number(mean(abs(z$y - z$x)), 2), units,
                        "; bias = ", format_number(mean(z$y - z$x), 2), units) else "",
      "\n", format_p(p), "; n = ", scales::comma(n),
      if (extra) " paired hours" else "\npaired observations")
    data.frame(Group = g, intercept = b0, slope = b1, label = label, n = n,
               adj_r2 = adj_r2, rmse = rmse, p = p)
  })
  out <- do.call(rbind, out); out$Group <- factor(out$Group, levels = levels(d$Group)); out
}
paired_limits <- function(d, pad) {
  lim <- range(c(d$x, d$y)); span <- diff(lim)
  if (!is.finite(span) || span <= 0) stop("The paired-observation range is invalid.")
  lim + c(-pad, pad) * span
}

# 20. Daily relative-humidity validation -------------------------------------
make_figure_20 <- function(env = parent.frame()) {
  x <- get_data("RH_dialy_mer", c("value.x", "value.y", "group"), c("value.x", "value.y"), env)
  d <- paired_data(x, "value.x", "value.y", "group", c("CMFD", "ERA5L"), "SF20")
  s <- pair_stats(d, units = "%"); lim <- paired_limits(d, 0.02)
  s$x <- lim[1] + 0.035 * diff(lim); s$y <- lim[2] - 0.085 * diff(lim)
  labels <- data.frame(Group = factor(c("CMFD", "ERA5L"), levels = c("CMFD", "ERA5L")),
                       label = c("(a)", "(b)"))
  p <- ggplot2::ggplot(d, ggplot2::aes(x, y)) + ggplot2::geom_hex(bins = 50, alpha = 0.8, colour = NA) +
    ggplot2::geom_abline(intercept = 0, slope = 1, colour = "#4D4D4D", linetype = "22", linewidth = 0.4) +
    ggplot2::geom_abline(data = s, ggplot2::aes(intercept = intercept, slope = slope), colour = "gray65", linewidth = 0.48) +
    ggplot2::geom_text(data = s, ggplot2::aes(x, y, label = label), inherit.aes = FALSE,
      hjust = 0, vjust = 1, size = 8.5 / ggplot2::.pt, lineheight = 1.05, family = FIGURE_FONT) +
    ggplot2::geom_text(data = labels, ggplot2::aes(label = label), x = lim[1] + 0.015 * diff(lim),
      y = lim[2] - 0.015 * diff(lim), inherit.aes = FALSE, hjust = 0, vjust = 1,
      size = 10 / ggplot2::.pt, fontface = "bold", family = FIGURE_FONT) +
    ggplot2::facet_wrap(~Group, nrow = 1, labeller = ggplot2::labeller(Group = c(CMFD = "CMFD", ERA5L = "ERA5-Land"))) +
    ggplot2::scale_fill_gradientn(colours = RColorBrewer::brewer.pal(9, "BuGn"), transform = "log10",
      breaks = scales::breaks_log(5), labels = scales::label_number(big.mark = ",", accuracy = 1),
      name = "Paired observations\nper hexagon", guide = count_guide()) +
    ggplot2::scale_x_continuous(breaks = scales::breaks_pretty(5)) +
    ggplot2::scale_y_continuous(breaks = scales::breaks_pretty(5)) +
    ggplot2::coord_equal(xlim = lim, ylim = lim, expand = FALSE) +
    ggplot2::labs(x = "CMA daily relative humidity (%)", y = "Reanalysis daily relative humidity (%)") + validation_theme()
  p
}

# Shared latest northern map / southern maritime inset for SF21 and SF22 -----
prepare_basemap <- function(amap_dir = AMAP_DIR) {
  crs <- sf::st_crs(paste("+proj=aea +lat_1=25 +lat_2=47 +lat_0=0 +lon_0=105",
                         "+datum=WGS84 +units=m +no_defs"))
  files <- c(country = file.path(amap_dir, "land", "100000.geojson"),
             maritime = file.path(amap_dir, "maritime", "100000.geojson"),
             anhui = file.path(amap_dir, "province_land", "340000.geojson"))
  province_files <- sort(list.files(file.path(amap_dir, "province_land"), "[.]geojson$", full.names = TRUE))
  if (!all(file.exists(files)) || !length(province_files)) stop("Incomplete AMap directory: ", amap_dir)
  read_geom <- function(file) {
    d <- sf::st_read(file, quiet = TRUE)
    if (is.na(sf::st_crs(d))) stop("Basemap CRS is missing: ", basename(file))
    sf::st_sf(geometry = sf::st_geometry(sf::st_transform(d, 4326)))
  }
  country <- read_geom(files["country"]); maritime <- read_geom(files["maritime"])
  anhui <- read_geom(files["anhui"])
  province <- do.call(rbind, lapply(province_files, read_geom))
  south_cut_lat <- unname(sf::st_bbox(anhui)["ymin"])
  as_lines <- function(d) {
    if (any(grepl("POLYGON", as.character(sf::st_geometry_type(d)))))
      sf::st_geometry(d) <- sf::st_boundary(sf::st_geometry(d))
    d
  }
  lines_ll <- lapply(list(country, province, maritime), as_lines)
  project <- function(d) {
    d <- sf::st_transform(d, crs)
    if (BOUNDARY_TOLERANCE_M > 0) d <- sf::st_simplify(d, dTolerance = BOUNDARY_TOLERANCE_M, preserveTopology = TRUE)
    d[!sf::st_is_empty(d), , drop = FALSE]
  }
  north <- lapply(lines_ll, project)
  main_geo <- sf::st_bbox(c(xmin = 75.5, ymin = 29, xmax = 133.5, ymax = 52.8), crs = sf::st_crs(4326))
  box <- sf::st_bbox(sf::st_transform(sf::st_as_sfc(main_geo), crs))
  xlim <- unname(box[c("xmin", "xmax")]); ylim <- MAP_YLIM
  anhui_ymin <- unname(sf::st_bbox(sf::st_transform(anhui, crs))["ymin"])
  ylim[1] <- min(ylim[1], anhui_ymin - 30000)  # guarantee the complete Anhui boundary
  south_geo <- sf::st_bbox(c(xmin = 73, ymin = 3, xmax = 135, ymax = south_cut_lat), crs = sf::st_crs(4326))
  # Crop in lon/lat before projection: the northern limit equals the southernmost latitude of Anhui.
  crop_south <- function(d) {
    g <- sf::st_geometry(d); sf::st_crs(g) <- NA
    g <- suppressWarnings(sf::st_crop(g, unclass(south_geo)))
    g <- suppressWarnings(sf::st_collection_extract(g, "LINESTRING")) # discard isolated crop-contact points
    sf::st_crs(g) <- 4326
    project(sf::st_sf(geometry = g))
  }
  south <- lapply(lines_ll, crop_south)
  if (any(vapply(south, nrow, integer(1)) == 0L)) stop("A southern basemap layer is empty.")
  from <- sf::st_bbox(do.call(rbind, south)); pw <- diff(xlim); ph <- diff(ylim)
  xmin <- xlim[2] - INSET_LEFT * pw; xmax <- xlim[2] - INSET_RIGHT * pw
  ymin <- ylim[1] + INSET_BOTTOM * ph
  k <- (xmax - xmin) / unname(from["xmax"] - from["xmin"])
  ymax <- ymin + k * unname(from["ymax"] - from["ymin"])
  to <- c(xmin = xmin, ymin = ymin, xmax = xmax, ymax = ymax)
  if (ymax >= ylim[2]) stop("Inset exceeds the northern panel; check INSET_LEFT/RIGHT.")
  inset <- lapply(south, function(d) {
    g <- (sf::st_geometry(d) - unname(from[c("xmin", "ymin")])) * k + c(xmin, ymin)
    sf::st_sf(geometry = sf::st_set_crs(g, crs))
  })
  frame <- sf::st_as_sf(sf::st_as_sfc(sf::st_bbox(to, crs = crs)))
  message("Map inset: width ", round(100 * (INSET_LEFT - INSET_RIGHT), 1),
          "%; south cutoff ", round(south_cut_lat, 5), " degrees N; source/target aspect preserved.")
  list(crs = crs, xlim = xlim, ylim = ylim, north = north, inset = inset,
       frame = frame, inset_bbox = to, source_bbox = from, south_cut_lat = south_cut_lat)
}
map_layers <- function(b) {
  line <- function(d, colour, width) ggplot2::geom_sf(data = d, fill = NA, colour = colour,
      linewidth = width, inherit.aes = FALSE, show.legend = FALSE)
  list(line(b$north[[2]], "grey55", 0.10), line(b$north[[1]], "grey45", 0.18),
       line(b$inset[[2]], "grey55", 0.08), line(b$inset[[1]], "grey45", 0.16),
       line(b$inset[[3]], "grey45", 0.14), line(b$frame, "grey45", 0.20))
}
map_theme <- function() ggplot2::theme_bw(base_family = FIGURE_FONT, base_size = 8) + ggplot2::theme(
  axis.title = ggplot2::element_blank(), axis.ticks = ggplot2::element_blank(), axis.text = ggplot2::element_blank(),
  strip.text = ggplot2::element_text(size = 7, colour = "black"),
  strip.background = ggplot2::element_rect(fill = "grey85", colour = NA),
  panel.grid.major = ggplot2::element_line(colour = "grey90", linewidth = 0.28),
  panel.grid.minor = ggplot2::element_blank(),
  panel.spacing.x = grid::unit(1.4, "mm"), panel.spacing.y = grid::unit(2.8, "mm"),
  legend.position = "bottom", legend.direction = "horizontal", legend.justification = "center",
  legend.title = ggplot2::element_text(size = 8, margin = ggplot2::margin(b = 3)),
  legend.text = ggplot2::element_text(size = 7),
  legend.background = ggplot2::element_rect(fill = "transparent", colour = NA),
  legend.key = ggplot2::element_rect(fill = "transparent", colour = NA),
  legend.box.background = ggplot2::element_blank(), legend.box.spacing = grid::unit(2.5, "mm"),
  plot.background = ggplot2::element_rect(fill = "transparent", colour = NA),
  plot.margin = ggplot2::margin(0.5, 0.5, 1.5, 0.5, unit = "mm")
)
trend_scale <- function(limits, breaks) {
  args <- list(colours = rev(RColorBrewer::brewer.pal(11, "BrBG")), limits = limits, breaks = breaks,
    labels = scales::label_number(accuracy = 0.01),
    name = expression("Relative humidity trend"~("%"~year^{-1})),
    guide = ggplot2::guide_colourbar(display = "rectangles", title.position = "top", title.hjust = 0.5,
      barwidth = grid::unit(5.4, "cm"), barheight = grid::unit(0.20, "cm")))
  if (limits[1] < 0 && limits[2] > 0)
    args$values <- scales::rescale(c(limits[1], 0, limits[2]), from = limits)
  do.call(ggplot2::scale_colour_gradientn, args)
}
trend_map <- function(d, b, scale, facets) {
  if (!inherits(d, "sf") || is.na(sf::st_crs(d))) stop("Trend data must be sf with a known CRS.")
  # Observations are never shifted into the southern inset; the inset is basemap only.
  d <- sf::st_transform(d, b$crs)
  ggplot2::ggplot() + ggplot2::geom_sf(data = d, ggplot2::aes(colour = trend_slope),
    size = 0.20, linewidth = 0.30, key_glyph = "rect") + scale + facets + map_layers(b) +
    ggplot2::coord_sf(crs = b$crs, xlim = b$xlim, ylim = b$ylim, expand = FALSE,
                     clip = "on", datum = sf::st_crs(4326)) + map_theme()
}

Supplementary_Figure_20=make_figure_20()
export_six(Supplementary_Figure_20,20)
