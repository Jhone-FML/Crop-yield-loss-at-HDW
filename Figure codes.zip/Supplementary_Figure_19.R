# Supplementary Figure 19 -------------------------------------------------------------
ROOT="F:/Post PHD documents/Crop yield loss at DHW/Submission/NF_proof_2026_09_01/Upload_Ready"
load(file.path(ROOT,"Supplementary_Figure_19_source_data.RData"),envir=.GlobalEnv)
# Supplementary Figures 18 -> 19 -> 20 -> 21 -> 22
# Load the original analysis objects, then source this file (UTF-8).
# Six exports per figure: PDF, SVG, Word-compatible vector SVG, EMF, TIFF, PNG.
# Validation panels retain the supplied bins, filters, fits and RMSE definitions.
# Map panels retain all trend observations; only their visible window is cropped.

AMAP_DIR <- "D:/Crop yield loss at DHW/amap"
OUTPUT_DIR <- file.path(ROOT, "Figures")
FIGURES_TO_RUN <- integer(0)
FIGURE_SIZE_CM <- list(`18` = c(14, 11.5), `19` = c(17.2, 8.4),
                      `20` = c(18, 9.5), `21` = c(18.3, 16.6), `22` = c(18.3, 6.8))
FIGURE_FONT <- "sans"
TIFF_DPI <- 600
PNG_DPI <- 450
MAP_YLIM <- c(3200000, 6024402)
INSET_LEFT <- 0.170                       # fraction measured from panel right
INSET_RIGHT <- 0.006
INSET_BOTTOM <- 0.018
BOUNDARY_TOLERANCE_M <- 10000              # inherited basemap simplification only

# 0. Shared validation, export and plotting helpers --------------------------
check_packages <- function(packages) {
  missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing)) stop("Install packages first: install.packages(c(",
    paste(sprintf('"%s"', missing), collapse = ", "), "))", call. = FALSE)
}
get_data <- function(name, columns, numeric_columns = character(), env = parent.frame()) {
  if (!exists(name, envir = env, inherits = TRUE)) stop("Missing object: ", name, call. = FALSE)
  x <- get(name, envir = env, inherits = TRUE)
  missing <- setdiff(columns, names(x))
  if (length(missing)) stop(name, " is missing: ", paste(missing, collapse = ", "), call. = FALSE)
  if (!all(vapply(numeric_columns, function(n) is.numeric(x[[n]]), logical(1))))
    stop(name, ": expected numeric columns: ", paste(numeric_columns, collapse = ", "), call. = FALSE)
  x
}
format_number <- function(x, digits) {
  ifelse(is.finite(x), formatC(x, format = "f", digits = digits), "NA")
}
format_p <- function(p) {
  if (!is.finite(p)) return("P = NA")
  if (p < 2.2e-16) return("P < 2.2e-16")
  paste0("P = ", formatC(p, format = if (p < 0.001) "e" else "f",
                        digits = if (p < 0.001) 2 else 3))
}

export_six <- function(plot, number, out_dir = OUTPUT_DIR,
                       size_cm = FIGURE_SIZE_CM[[as.character(number)]]) {
  check_packages(c("svglite", "ragg", "devEMF"))
  if (!isTRUE(capabilities("cairo"))) stop("R requires Cairo support for PDF and Word SVG.")
  if (length(size_cm) != 2L || any(!is.finite(size_cm) | size_cm <= 0)) stop("Invalid figure size.")
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  prefix <- file.path(out_dir, paste0("Supplementary_Figure_", number))
  w <- size_cm[1] / 2.54; h <- size_cm[2] / 2.54
  save_device <- function(device, path, ...) {
    device(path, ...)
    device_id <- grDevices::dev.cur()
    on.exit(if (device_id %in% grDevices::dev.list()) grDevices::dev.off(device_id), add = TRUE)
    print(plot)
    invisible(path)
  }
  open_pdf <- function(path, ...) grDevices::cairo_pdf(filename = path, ...)
  open_svg <- function(path, ...) svglite::svglite(file = path, ...)
  save_device(open_pdf, paste0(prefix, ".pdf"), width = w, height = h,
              family = FIGURE_FONT, bg = "transparent", fallback_resolution = TIFF_DPI)
  save_device(open_svg, paste0(prefix, ".svg"), width = w, height = h,
              bg = "transparent")
  # Cairo writes glyph outlines as vector paths, including superscript minus.
  # This SVG has vector content; it is not a PNG embedded in an SVG container.
  save_device(grDevices::svg, paste0(prefix, "_word_compatible.svg"), width = w,
              height = h, family = "sans", pointsize = 11, bg = "transparent")
  save_device(devEMF::emf, paste0(prefix, ".emf"), width = w, height = h,
              family = FIGURE_FONT, pointsize = 11, coordDPI = 600, emfPlus = TRUE)
  save_device(ragg::agg_tiff, paste0(prefix, ".tiff"), width = size_cm[1], height = size_cm[2],
              units = "cm", res = TIFF_DPI, compression = "lzw", background = "white")
  save_device(ragg::agg_png, paste0(prefix, ".png"), width = size_cm[1], height = size_cm[2],
              units = "cm", res = PNG_DPI, background = "white")
  paths <- paste0(prefix, c(".pdf", ".svg", "_word_compatible.svg", ".emf", ".tiff", ".png"))
  if (!all(file.exists(paths)) || any(file.info(paths)$size == 0)) stop("An export is missing: ", prefix)
  word_svg <- readLines(paths[3], warn = FALSE)
  if (any(grepl("<image\\b", word_svg))) stop("Unexpected raster content in Word SVG: ", paths[3])
  message("Exported six formats: ", prefix)
  invisible(paths)
}

count_guide <- function() ggplot2::guide_colourbar(
  display = "rectangles", title.position = "top", title.hjust = 0.5,
  barheight = grid::unit(26, "mm"), barwidth = grid::unit(3.2, "mm"),
  ticks.colour = "black", frame.colour = "black"
)
validation_theme <- function(classic = FALSE) {
  base <- if (classic) ggplot2::theme_classic else ggplot2::theme_gray
  base(base_family = FIGURE_FONT, base_size = 9) + ggplot2::theme(
    axis.title = ggplot2::element_text(size = 9, colour = "black"),
    axis.text = ggplot2::element_text(size = 8, colour = "black"),
    strip.text = ggplot2::element_text(size = 9, face = "bold", colour = "black"),
    panel.spacing.x = grid::unit(4, "mm"), legend.position = "right",
    legend.title = ggplot2::element_text(size = 8, lineheight = 0.95),
    legend.text = ggplot2::element_text(size = 7.5),
    legend.background = ggplot2::element_blank(),
    plot.background = ggplot2::element_rect(fill = "transparent", colour = NA),
    plot.margin = ggplot2::margin(2, 2, 2, 2, unit = "mm")
  )
}
paired_data <- function(x, x_col, y_col, group_col = NULL, group_order = NULL, id) {
  group <- if (is.null(group_col)) rep("All", nrow(x)) else as.character(x[[group_col]])
  if (is.null(group_order)) group_order <- if (!is.null(group_col) && is.factor(x[[group_col]]))
    levels(droplevels(x[[group_col]])) else unique(group[!is.na(group)])
  unknown <- setdiff(unique(group[!is.na(group)]), group_order)
  if (length(unknown)) stop(id, ": unrecognised groups: ", paste(unknown, collapse = ", "))
  d <- data.frame(x = x[[x_col]], y = x[[y_col]], Group = factor(group, levels = group_order))
  keep <- is.finite(d$x) & is.finite(d$y) & !is.na(d$Group)
  message(id, ": input ", nrow(d), "; finite paired rows ", sum(keep), "; excluded ", sum(!keep))
  print(table(Group = d$Group, included = keep, useNA = "ifany"))
  d <- d[keep, , drop = FALSE]
  if (!nrow(d) || any(table(d$Group) < 3L)) stop(id, ": each group needs at least three finite pairs.")
  d
}
pair_stats <- function(d, residual_rmse = FALSE, units = "", extra = FALSE) {
  # Same ordinary least-squares fit as lm(y ~ x), using sufficient statistics.
  # SF19 keeps its original regression-residual RMSE; SF18/20 use y-x RMSE.
  out <- lapply(levels(d$Group), function(g) {
    z <- d[d$Group == g, , drop = FALSE]; n <- nrow(z)
    mx <- mean(z$x); my <- mean(z$y)
    sxx <- sum((z$x - mx)^2); syy <- sum((z$y - my)^2)
    sxy <- sum((z$x - mx) * (z$y - my))
    if (sxx <= 0 || syy <= 0) stop("Constant observations in group: ", g)
    b1 <- sxy / sxx; b0 <- my - b1 * mx
    sse <- sum((z$y - (b0 + b1 * z$x))^2)
    se <- sqrt((sse / (n - 2)) / sxx)
    p <- 2 * stats::pt(-abs(b1 / se), df = n - 2)
    adj_r2 <- 1 - (sse / syy) * (n - 1) / (n - 2)
    rmse <- if (residual_rmse) sqrt(sse / n) else sqrt(mean((z$y - z$x)^2))
    equation <- paste0("y = ", format_number(b0, 2), if (b1 < 0) " - " else " + ",
                       format_number(abs(b1), 3), "x")
    label <- paste0(equation, "\nAdjusted R\u00b2 = ", format_number(adj_r2, 3),
      "; ", if (residual_rmse) "Residual RMSE = " else "RMSE = ", format_number(rmse, 2), units,
      if (extra) paste0("\nMAE = ", format_number(mean(abs(z$y - z$x)), 2), units,
                        "; bias = ", format_number(mean(z$y - z$x), 2), units) else "",
      "\n", format_p(p), "; n = ", scales::comma(n),
      if (extra) " paired hours" else "\npaired observations")
    data.frame(Group = g, intercept = b0, slope = b1, label = label, n = n,
               adj_r2 = adj_r2, rmse = rmse, p = p)
  })
  out <- do.call(rbind, out); out$Group <- factor(out$Group, levels = levels(d$Group)); out
}
paired_limits <- function(d, pad) {
  lim <- range(c(d$x, d$y)); span <- diff(lim)
  if (!is.finite(span) || span <= 0) stop("The paired-observation range is invalid.")
  lim + c(-pad, pad) * span
}

# 19. Hourly wind-speed validation -------------------------------------------
make_figure_19 <- function(env = parent.frame()) {
  x <- get_data("W10_hourly", c("value.x", "value.y", "Group"), c("value.x", "value.y"), env)
  d <- paired_data(x, "value.x", "value.y", "Group", id = "SF19")
  s <- pair_stats(d, residual_rmse = TRUE, units = " m s\u207b\u00b9")
  s$x <- 0.70; s$y <- 13.25
  labels <- data.frame(Group = factor(levels(d$Group), levels = levels(d$Group)),
    label = if (nlevels(d$Group) == 2L) c("(b)", "(a)") else paste0("(", letters[seq_len(nlevels(d$Group))], ")"))
  p <- ggplot2::ggplot(d, ggplot2::aes(x, y)) + ggplot2::geom_hex(bins = 160) +
    ggplot2::scale_fill_gradientn(colours = RColorBrewer::brewer.pal(9, "RdPu"), transform = "log10",
      breaks = c(1, 10, 100, 1000, 10000, 100000), labels = scales::comma,
      name = "Paired observations\nper hexagon", guide = count_guide()) +
    ggplot2::geom_abline(intercept = 0, slope = 1, colour = "red4", linetype = "dashed", linewidth = 0.55) +
    ggplot2::geom_vline(xintercept = c(3, 6), colour = "gray85", linetype = "dashed", linewidth = 0.4) +
    ggplot2::geom_hline(yintercept = c(3, 6), colour = "gray85", linetype = "dashed", linewidth = 0.4) +
    ggplot2::annotate("text", x = 3, y = 3, label = "3 m/s",
      vjust = -1, size = 3, colour = "gray25", family = FIGURE_FONT) +
    ggplot2::annotate("text", x = 6, y = 6, label = "6 m/s",
      vjust = -1, size = 3, colour = "gray25", family = FIGURE_FONT) +
    ggplot2::geom_abline(data = s, ggplot2::aes(intercept = intercept, slope = slope), colour = "gray65", linewidth = 0.7) +
    ggplot2::geom_text(data = s, ggplot2::aes(x, y, label = label), inherit.aes = FALSE,
      hjust = 0, vjust = 1, size = 2.65, lineheight = 0.92, family = FIGURE_FONT) +
    ggplot2::geom_text(data = labels, ggplot2::aes(label = label), x = 0.22, y = 14.75,
      inherit.aes = FALSE, hjust = 0, vjust = 1, size = 3.3, fontface = "bold", family = FIGURE_FONT) +
    ggplot2::facet_wrap(~Group, ncol = 2) +
    ggplot2::scale_x_continuous(breaks = c(0, 5, 10, 15)) +
    ggplot2::scale_y_continuous(breaks = c(0, 5, 10, 15)) +
    ggplot2::coord_cartesian(xlim = c(0, 15), ylim = c(0, 15), expand = FALSE) +
    ggplot2::labs(x = "CMA wind speed (m s\u207b\u00b9)", y = "Reanalysis wind speed (m s\u207b\u00b9)") + validation_theme()
  p
}

Supplementary_Figure_19=make_figure_19()
export_six(Supplementary_Figure_19,19)
