# Figure 2 --------------------------------------------------------------------
library(ggplot2)
library(ggpattern)
library(cowplot)
library(grid)
library(RColorBrewer)
library(readxl)

root = "F:/Post PHD documents/Crop yield loss at DHW/Submission/NF_proof_2026_09_01/Upload_Ready"
out_dir = file.path(root, "Figures")
dir.create(out_dir, showWarnings = FALSE)
file = file.path(root, "Figure_2_source_data.xlsx")

# Read the four panels directly from the four Excel sheets.
dfSM = as.data.frame(read_excel(file, sheet = "Figure 2 a"))
names(dfSM) = c("Estimate", "Std..Error", "Model", "stg", "soil")
dfSM$soil = factor(dfSM$soil, levels = c("SM_0q~10q", "SM_10q~20q", "SM_20q~30q",
  "SM_30q~40q", "SM_40q~50q", "SM_50q~60q", "SM_60q~70q",
  "SM_70q~80q", "SM_80q~90q", "SM_90q~100q"))
dfSM$stg = factor(dfSM$stg, levels = c("HD-MT", "JT-HD", "PT-JT"))
dfSM$Model = factor(dfSM$Model, levels = c("TSMM", "TSDM", "TSCD"))

Per_Fit_long = as.data.frame(read_excel(file, sheet = "Figure 2 b"))
names(Per_Fit_long) = c("Per", "STG", "per_fit", "sd")
Per_Fit_long$STG = factor(Per_Fit_long$STG, levels = c("HM_per", "JH_per", "PJ_per"))

DHW_gg_summary = as.data.frame(read_excel(file, sheet = "Figure 2 c"))
names(DHW_gg_summary) = c("Model", "Y_levle", "DHW_sou", "Type",
  "Estimate", "Std.Error", "Pr.t")
DHW_gg_summary$Type = factor(DHW_gg_summary$Type,
  levels = c("HTLH", "PRWD", "DTWD"))
DHW_gg_summary$col = paste(as.character(DHW_gg_summary$Type),
  DHW_gg_summary$Y_levle, sep = "_")
DHW_gg_summary$Model_formatted = paste0(sub("_.*", "", DHW_gg_summary$Model),
  "[", sub(".*_", "", DHW_gg_summary$Model), "]")
DHW_gg_summary$Model_formatted = factor(DHW_gg_summary$Model_formatted,
  levels = unique(DHW_gg_summary$Model_formatted))
DHW_gg_summary$signif = ifelse(DHW_gg_summary$Pr.t < 0.001, "***",
  ifelse(DHW_gg_summary$Pr.t < 0.01, "**",
  ifelse(DHW_gg_summary$Pr.t < 0.05, "*", "ns")))
DHW_gg_summary$y_position = ifelse(DHW_gg_summary$Estimate < 0,
  (DHW_gg_summary$Estimate - DHW_gg_summary$Std.Error) * 100 - 1,
  (DHW_gg_summary$Estimate + DHW_gg_summary$Std.Error) * 100 + 1)

Prov_DHW_SEN_DF = as.data.frame(read_excel(file, sheet = "Figure 2 d"))
names(Prov_DHW_SEN_DF) = c("Values", "Hs", "Prov", "varbs", "sd")
Prov_DHW_SEN_DF$varbs = factor(Prov_DHW_SEN_DF$varbs,
  levels = c("HTLH", "PRGW"))

figure_font_family = "Arial"
font_panel_label = 10
font_axis_title = 9
font_axis_text = 8
font_strip = 7
font_legend_text = 6.6
font_legend_title = 7.8
font_significance = 8

Soil_point_gg = ggplot(dfSM) +
  geom_hline(yintercept = 0, linewidth = 0.5, linetype = "dashed", color = "gray75") +
  geom_point(aes(x = soil, y = Estimate, shape = Model, color = Model, fill = Model),
    size = 1, position = position_dodge(0.5)) +
  geom_errorbar(aes(x = soil, ymin = Estimate - Std..Error,
    ymax = Estimate + Std..Error, color = Model), linewidth = 0.25,
    width = 0.45, position = position_dodge(0.5)) +
  scale_fill_manual(name = "", values = brewer.pal(8, "Dark2")[1:3]) +
  scale_shape_manual(name = "", values = c(1, 2, 3)) +
  scale_color_manual(name = "", values = brewer.pal(8, "Dark2")[1:3]) +
  facet_grid(stg ~ .) +
  ylab(bquote(Yield~sensitivity~to~soil~moisture~(kg~ha^-1~day^-1))) +
  scale_x_discrete("Soil moisture bins at different quantiles", labels = c(
    "SM_0q~10q" = bquote(SM['10% quantile']), "SM_10q~20q" = bquote(SM['20% quantile']),
    "SM_20q~30q" = bquote(SM['30% quantile']), "SM_30q~40q" = bquote(SM['40% quantile']),
    "SM_40q~50q" = bquote(SM['50% quantile']), "SM_50q~60q" = bquote(SM['60% quantile']),
    "SM_60q~70q" = bquote(SM['70% quantile']), "SM_70q~80q" = bquote(SM['80% quantile']),
    "SM_80q~90q" = bquote(SM['90% quantile']), "SM_90q~100q" = bquote(SM['100% quantile']))) +
  labs(subtitle = "(a)") + theme_bw(base_family = figure_font_family, base_size = font_axis_text) +
  theme(plot.subtitle = element_text(size = font_panel_label, hjust = 0.02, vjust = 2.5),
    strip.text = element_text(size = font_strip), legend.key.size = unit(0.3, "cm"),
    axis.text.x = element_text(size = 8.6, angle = 45, vjust = 0.7, hjust = 0.6),
    axis.text.y = element_text(size = font_axis_text), axis.title = element_text(size = font_axis_title),
    legend.position = c(0.91, 0.27), legend.key.height = unit(0.1, "cm"),
    legend.background = element_blank(), legend.text = element_text(size = font_legend_text),
    legend.title = element_text(size = font_legend_title), strip.background = element_rect(color = "transparent"),
    plot.margin = margin(1, 1, 4, 1, unit = "mm"),
    plot.background = element_rect(fill = "transparent", colour = NA))

Perp_sensity_gg = ggplot(Per_Fit_long) +
  geom_histogram(aes(x = Per, y = after_stat(density), group = STG, fill = STG),
    color = "gray75", alpha = 0.8, linewidth = 0.4) +
  geom_line(aes(x = Per, y = 0.03 + per_fit / 30000, group = STG, color = STG), linewidth = 0.6) +
  geom_ribbon(aes(x = Per, ymin = 0.03 + (per_fit - sd) / 30000,
    ymax = 0.03 + (per_fit + sd) / 30000, fill = STG), alpha = 0.3) +
  scale_fill_manual(values = brewer.pal(11, "PRGn")[9:11], name = "",
    labels = c("HD-MT", "JT-HD", "PT-JT")) +
  scale_color_manual(values = brewer.pal(11, "PRGn")[9:11], name = "",
    labels = c("HD-MT", "JT-HD", "PT-JT")) +
  scale_y_continuous(name = "Density of county-year precipitation",
    sec.axis = sec_axis(~(. * 30000) - 30000 * 0.03,
      name = bquote(Sensitivity~of~yield~to~Prcp~(kg~ha^-1~mm^-1)))) +
  geom_hline(yintercept = 0.03, color = "gray75", linetype = 5, linewidth = 0.4) +
  xlab("Cumulative precipitation (mm)") + labs(subtitle = "(b)") +
  theme_bw(base_family = figure_font_family, base_size = font_axis_text) +
  theme(plot.subtitle = element_text(size = font_panel_label, hjust = 0.02, vjust = 2.5),
    strip.text = element_text(size = font_strip), legend.key.size = unit(0.3, "cm"),
    axis.text = element_text(size = font_axis_text), axis.title = element_text(size = font_axis_title),
    legend.position = c(0.78, 0.22), legend.key.height = unit(0.22, "cm"),
    legend.background = element_blank(), legend.text = element_text(size = font_legend_text),
    legend.title = element_text(size = font_legend_title), plot.margin = margin(1, 2, 3, 2, unit = "mm"),
    plot.background = element_rect(fill = "transparent", colour = NA))

legend_c_breaks = c("HTLH_County", "HTLH_Field", "PRWD_County", "PRWD_Field", "DTWD_County")
legend_c_labels = c("County: HTLH", "Field trial: HTLH", "County: PRGW",
  "Field trial: PRGW", "County: DTWD")
legend_c_colours = c(DTWD_County = "orange3", HTLH_County = "orangered4",
  HTLH_Field = "brown4", PRWD_County = "orangered3", PRWD_Field = "orangered2")
legend_c_patterns = c(DTWD_County = "none", HTLH_County = "none",
  HTLH_Field = "stripe", PRWD_County = "none", PRWD_Field = "stripe")

DHW_SEN_sing_gg = ggplot(DHW_gg_summary,
    aes(x = Type, y = Estimate * 100, color = col, fill = col)) +
  geom_bar_pattern(stat = "identity", alpha = 0.6, linewidth = 0.05,
    aes(pattern = col), position = position_dodge(0.9), color = "black",
    pattern_fill = "black", pattern_angle = 45, pattern_density = 0.000001,
    pattern_size = 0.05, pattern_spacing = 0.1, pattern_key_scale_factor = 0.1) +
  geom_errorbar(aes(ymin = (Estimate - Std.Error) * 100,
    ymax = (Estimate + Std.Error) * 100), width = 0.2,
    position = position_dodge(0.9)) +
  geom_text(aes(y = y_position, label = signif), position = position_dodge(0.9),
    size = font_significance / ggplot2::.pt, vjust = 0.5, color = "black") +
  scale_x_discrete("Yield models", labels = c("HTLH" = "HTLH", "PRWD" = "PRGW", "DTWD" = "DTWD")) +
  ylab("Yield loss per standard unit (%)") +
  scale_pattern_manual(values = legend_c_patterns, breaks = legend_c_breaks,
    labels = legend_c_labels, name = NULL) +
  scale_fill_manual(values = legend_c_colours, breaks = legend_c_breaks,
    labels = legend_c_labels, name = NULL) +
  scale_color_manual(values = legend_c_colours, breaks = legend_c_breaks,
    labels = legend_c_labels, name = NULL, guide = "none") +
  guides(fill = guide_legend(nrow = 2, byrow = TRUE),
    pattern = guide_legend(nrow = 2, byrow = TRUE)) +
  facet_grid(~Model_formatted, switch = "x", scales = "free_x", labeller = label_parsed) +
  labs(subtitle = "(c)") + theme_bw(base_family = figure_font_family, base_size = font_axis_text) +
  theme(plot.subtitle = element_text(size = font_panel_label, hjust = 0.02, vjust = 2.5),
    strip.text = element_text(size = font_strip), panel.spacing = unit(0, "cm"), strip.placement = "outside",
    strip.background = element_rect(fill = "white"), axis.text.x = element_text(size = font_axis_text, angle = 45, vjust = 0.5),
    axis.text.y = element_text(size = font_axis_text), axis.title = element_text(size = font_axis_title),
    legend.position = "top", legend.direction = "horizontal", legend.box = "horizontal",
    legend.justification = "center", legend.key.width = unit(0.40, "cm"), legend.key.height = unit(0.18, "cm"),
    legend.spacing.x = unit(0.03, "cm"), legend.spacing.y = unit(0.02, "cm"),
    legend.margin = margin(0, 0, 1, 0, unit = "mm"), legend.box.spacing = unit(0.10, "cm"),
    legend.background = element_blank(), legend.text = element_text(size = font_legend_text),
    legend.title = element_text(size = font_legend_title), plot.margin = margin(1, 1, 3, 1, unit = "mm"),
    plot.background = element_rect(fill = "transparent", colour = NA))

prov_levels = unique(Prov_DHW_SEN_DF$Prov)
prov_cols = c(All = "#000000", Beijing = "#D73027", Gansu = "#1F78B4",
  Hebei = "#E66101", Heilongjiang = "#4DAF4A", Henan = "#984EA3",
  `Inner Mongolia` = "#8C510A", Jiangsu = "#008EAA", Ningxia = "#006D2C",
  Qinghai = "#542788", Shaanxi = "#A6761D", Shandong = "#4D4D4D",
  Shanxi = "#E6AB02", Tianjing = "#C51B7D", Tianjin = "#C51B7D", Xinjiang = "#A50F15")
prov_linetypes = c(All = "solid", Beijing = "solid", Gansu = "solid", Hebei = "dashed",
  Heilongjiang = "solid", Henan = "dashed", `Inner Mongolia` = "solid", Jiangsu = "dashed",
  Ningxia = "dashed", Qinghai = "solid", Shaanxi = "dashed", Shandong = "dashed",
  Shanxi = "solid", Tianjing = "solid", Tianjin = "solid", Xinjiang = "dashed")
legend_split = ceiling(length(prov_levels) / 2)
make_legend = function(panel, province) data.frame(varbs = panel, Prov = province,
  x0 = 0.12, x1 = 2.0, xtext = 3.00,
  y = -1035 - (seq_along(province) - 1) * 235)
panel_d_legend = rbind(make_legend("HTLH", prov_levels[1:legend_split]),
  make_legend("PRGW", prov_levels[(legend_split + 1):length(prov_levels)]))
panel_d_spacer = data.frame(varbs = c("HTLH", "PRGW"), Hs = 0, Values = -2050)

Prov_DHW_SEN_gg = ggplot(Prov_DHW_SEN_DF) +
  geom_ribbon(aes(x = Hs, ymin = Values - sd, ymax = Values + sd,
    fill = Prov, group = Prov), alpha = 0.1) +
  geom_line(aes(x = Hs, y = Values, color = Prov, linetype = Prov, group = Prov), linewidth = 0.28) +
  geom_blank(data = panel_d_spacer, aes(x = Hs, y = Values), inherit.aes = FALSE) +
  geom_segment(data = panel_d_legend,
    aes(x = x0, xend = x1, y = y, yend = y, colour = Prov, linetype = Prov),
    inherit.aes = FALSE, linewidth = 0.48, lineend = "round") +
  geom_text(data = panel_d_legend,
    aes(x = xtext, y = y, label = Prov, colour = Prov), inherit.aes = FALSE,
    hjust = 0, vjust = 0.5, size = font_legend_text / ggplot2::.pt, show.legend = FALSE) +
  scale_color_manual(values = prov_cols[prov_levels], breaks = prov_levels, guide = "none") +
  scale_fill_manual(values = prov_cols[prov_levels], breaks = prov_levels, guide = "none") +
  scale_linetype_manual(values = prov_linetypes[prov_levels], breaks = prov_levels, guide = "none") +
  facet_grid(. ~ varbs, switch = "x", scales = "free_y") +
  coord_cartesian(xlim = c(0, 10), clip = "on") +
  xlab(expression(Delta~HDW~(hour))) + ylab(expression("Yield response"~(kg~ha^-1))) +
  labs(subtitle = "(d)") + theme_bw(base_family = figure_font_family, base_size = font_axis_text) +
  theme(plot.subtitle = element_text(size = font_panel_label, hjust = 0.02, vjust = 2.5),
    strip.text = element_text(size = font_strip), panel.spacing = unit(0.30, "cm"),
    strip.placement = "outside", strip.background = element_rect(fill = "white"),
    axis.text = element_text(size = font_axis_text), axis.title = element_text(size = font_axis_title),
    legend.position = "none", plot.margin = margin(1.5, 1.5, 2, 1.5, unit = "mm"),
    plot.background = element_rect(fill = "transparent", colour = NA))

Figure_2 = ggdraw() +
  draw_plot(Soil_point_gg, x = 0.00, y = 0.42, width = 0.63, height = 0.55) +
  draw_plot(Perp_sensity_gg, x = 0.63, y = 0.42, width = 0.37, height = 0.55) +
  draw_plot(DHW_SEN_sing_gg, x = 0.00, y = -0.02, width = 0.63, height = 0.44) +
  draw_plot(Prov_DHW_SEN_gg, x = 0.63, y = -0.02, width = 0.37, height = 0.44)

# Six output formats.
w = 18.3 / 2.54; h = 14.2 / 2.54
ggsave(file.path(out_dir, "Figure_2.pdf"), Figure_2, width = w, height = h, device = cairo_pdf, bg = "transparent")
ggsave(file.path(out_dir, "Figure_2.svg"), Figure_2, width = w, height = h, device = svglite::svglite, bg = "transparent")
svg(file.path(out_dir, "Figure_2_word_compatible.svg"), width = w, height = h,
  family = figure_font_family, pointsize = 11, bg = "transparent", onefile = TRUE)
print(Figure_2); dev.off()
devEMF::emf(file.path(out_dir, "Figure_2.emf"), width = w, height = h,
  family = figure_font_family, pointsize = 11, coordDPI = 600, emfPlus = TRUE)
print(Figure_2); dev.off()
ggsave(file.path(out_dir, "Figure_2.tiff"), Figure_2, width = 18.3, height = 14.2,
  units = "cm", dpi = 600, device = ragg::agg_tiff, compression = "lzw", bg = "white")
ggsave(file.path(out_dir, "Figure_2.png"), Figure_2, width = 18.3, height = 14.2,
  units = "cm", dpi = 450, device = ragg::agg_png, bg = "white")
