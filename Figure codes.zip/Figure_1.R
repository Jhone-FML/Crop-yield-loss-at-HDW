# Figure 1 -------------------------------------------------------------
# Direct Excel-based reproduction. This file does not source any other R script.
library(readxl)
ROOT = "F:/Post PHD documents/Crop yield loss at DHW/Submission/NF_proof_2026_09_01/Upload_Ready"
FIGURE_OUTPUT_DIR = file.path(ROOT, "Figures")
AMAP_DIR = "D:/Crop yield loss at DHW/amap"
FIGURE_FONT = "sans"
NF_LEGEND_TEXT_PT = 6.6; NF_LEGEND_TITLE_PT = 7.8
TIFF_DPI = 600; PNG_DPI = 450
MAP_YLIM = c(3200000, 6024402)
INSET_LEFT = 0.170; INSET_RIGHT = 0.006; INSET_BOTTOM = 0.018
BASEMAP_TOLERANCE_M = 10000
dir.create(FIGURE_OUTPUT_DIR, recursive = TRUE, showWarnings = FALSE)
check_packages = function(x) {
  miss = x[!vapply(x, requireNamespace, logical(1), quietly = TRUE)]
  if (length(miss)) stop("Install required package(s): ", paste(miss, collapse = ", "))
}
check_packages(c("svglite", "ragg", "devEMF"))
if (requireNamespace("cowplot", quietly = TRUE)) cowplot::set_null_device("agg")
save_device = function(plot, device, file, ...) {
  device(file, ...); id = dev.cur(); on.exit(if (id %in% dev.list()) dev.off(id), add = TRUE)
  print(plot); invisible(file)
}
export_six = function(plot, name, width_cm, height_cm) {
  prefix = file.path(FIGURE_OUTPUT_DIR, name); w = width_cm / 2.54; h = height_cm / 2.54
  save_device(plot, function(file, ...) cairo_pdf(filename = file, ...), paste0(prefix, ".pdf"),
    width = w, height = h, family = FIGURE_FONT, bg = "transparent")
  save_device(plot, svglite::svglite, paste0(prefix, ".svg"), width = w, height = h, bg = "transparent")
  save_device(plot, svg, paste0(prefix, "_word_compatible.svg"), width = w, height = h,
    family = "sans", pointsize = 11, bg = "transparent", onefile = TRUE)
  save_device(plot, devEMF::emf, paste0(prefix, ".emf"), width = w, height = h,
    family = "sans", pointsize = 11, coordDPI = 600, emfPlus = TRUE)
  save_device(plot, ragg::agg_tiff, paste0(prefix, ".tiff"), width = width_cm, height = height_cm,
    units = "cm", res = TIFF_DPI, compression = "lzw", background = "white")
  save_device(plot, ragg::agg_png, paste0(prefix, ".png"), width = width_cm, height = height_cm,
    units = "cm", res = PNG_DPI, background = "white")
}
export_bundle = function(plot, data, name, width_cm, height_cm) export_six(plot, name, width_cm, height_cm)
map_source_manifest = function(...) data.frame()
join_excel = function(geometry, values, keys, columns) {
  for (k in keys) { geometry[[k]] = as.character(geometry[[k]]); values[[k]] = as.character(values[[k]]) }
  gkey = do.call(paste, c(sf::st_drop_geometry(geometry)[keys], sep = "
"))
  vkey = do.call(paste, c(values[keys], sep = "
")); idx = match(gkey, vkey)
  if (anyNA(idx)) stop("Geometry cannot be matched to Excel for key: ", paste(keys, collapse = ", "))
  for (to in names(columns)) geometry[[to]] = values[[columns[[to]]]][idx]
  geometry
}

library(sf)
a = as.data.frame(read_excel(file.path(ROOT,"Figure_1_source_data.xlsx"),sheet="Figure 1 a"))
b = as.data.frame(read_excel(file.path(ROOT,"Figure_1_source_data.xlsx"),sheet="Figure 1 b"))
c = as.data.frame(read_excel(file.path(ROOT,"Figure_1_source_data.xlsx"),sheet="Figure 1 c"))
a[["Mean (hour)"]] = suppressWarnings(as.numeric(a[["Mean (hour)"]]))
b[["Frequency (%)"]] = suppressWarnings(as.numeric(b[["Frequency (%)"]]))
c[["Trend (hour dec-1)"]] = suppressWarnings(as.numeric(c[["Trend (hour dec-1)"]]))
c[["p value"]] = suppressWarnings(as.numeric(c[["p value"]]))
g = file.path(ROOT,"Figure_1_geometry.gpkg")
CMFD_freqs_means_sf = st_read(g,layer="CMFD_freqs_means_sf",quiet=TRUE)
CMFD_freqs_means_sf = join_excel(CMFD_freqs_means_sf,a,c("site","Type"),c(mean_hours="Mean (hour)"))
CMFD_freqs_means_sf = join_excel(CMFD_freqs_means_sf,b,c("site","Type"),c(freq_years="Frequency (%)"))
CMFD_freqs_means_sf$freq_years = CMFD_freqs_means_sf$freq_years/100
CMFD_all_trends_sf = st_read(g,layer="CMFD_all_trends_sf",quiet=TRUE)
CMFD_all_trends_sf = join_excel(CMFD_all_trends_sf,c,c("site","Type"),c(trend="Trend (hour dec-1)",p_value="p value",sig="sig"))
signif_centroids = st_read(g,layer="signif_centroids",quiet=TRUE)

# Figure 1: mean, frequency and trend of HDW using the supplied AMap basemap

required_packages <- c(
  "ggplot2", "sf", "dplyr", "RColorBrewer", "scales",
  "cowplot", "svglite", "ragg"
)
missing_packages <- required_packages[!vapply(
  required_packages, requireNamespace, logical(1), quietly = TRUE
)]
if (length(missing_packages) > 0) {
  stop(
    "Install the required package(s): ", paste(missing_packages, collapse = ", "),
    "\nRun: install.packages(c(",
    paste(sprintf('"%s"', missing_packages), collapse = ", "), "))",
    call. = FALSE
  )
}

required_objects <- c(
  "CMFD_freqs_means_sf", "CMFD_all_trends_sf", "signif_centroids"
)
missing_objects <- required_objects[!vapply(
  required_objects, exists, logical(1), inherits = TRUE
)]
if (length(missing_objects) > 0) {
  stop("Missing required object(s): ", paste(missing_objects, collapse = ", "), call. = FALSE)
}

required_sf_columns <- function(x, columns, object_name) {
  if (!inherits(x, "sf")) {
    stop(object_name, " must be an sf object.", call. = FALSE)
  }
  missing <- setdiff(columns, names(x))
  if (length(missing) > 0) {
    stop(object_name, " is missing: ", paste(missing, collapse = ", "), call. = FALSE)
  }
  if (is.na(sf::st_crs(x))) {
    stop(object_name, " has no CRS.", call. = FALSE)
  }
}

required_sf_columns(
  CMFD_freqs_means_sf,
  c("mean_hours", "freq_years", "Type"),
  "CMFD_freqs_means_sf"
)
required_sf_columns(
  CMFD_all_trends_sf,
  c("trend", "Type"),
  "CMFD_all_trends_sf"
)
if (!all(c("x", "y", "size_pt") %in% names(signif_centroids))) {
  stop("signif_centroids must contain x, y and size_pt.", call. = FALSE)
}

# -----------------------------------------------------------------------------
# Read the supplied national, provincial and maritime map layers
# -----------------------------------------------------------------------------

amap_dir <- AMAP_DIR
country_file <- file.path(amap_dir, "land", "100000.geojson")
province_dir <- file.path(amap_dir, "province_land")
maritime_file <- file.path(amap_dir, "maritime", "100000.geojson")

required_map_paths <- c(country_file, province_dir, maritime_file)
missing_map_paths <- required_map_paths[!file.exists(required_map_paths)]
if (length(missing_map_paths) > 0) {
  stop("Missing map path(s): ", paste(missing_map_paths, collapse = "; "), call. = FALSE)
}

province_files <- sort(list.files(
  province_dir,
  pattern = "[.]geojson$",
  full.names = TRUE
))
if (length(province_files) == 0) {
  stop("No province GeoJSON files were found in: ", province_dir, call. = FALSE)
}

country_wgs84 <- sf::st_read(country_file, quiet = TRUE)
provinces_wgs84 <- do.call(
  rbind,
  lapply(province_files, function(path) sf::st_read(path, quiet = TRUE))
)
maritime_wgs84 <- sf::st_read(maritime_file, quiet = TRUE)
anhui_wgs84 <- sf::st_read(file.path(province_dir, "340000.geojson"), quiet = TRUE)

source_crs <- sf::st_crs(CMFD_freqs_means_sf)
if (is.na(source_crs)) {
  stop("CMFD_freqs_means_sf has no CRS.", call. = FALSE)
}
map_crs <- sf::st_crs(paste(
  "+proj=aea +lat_1=25 +lat_2=47 +lat_0=0 +lon_0=105",
  "+datum=WGS84 +units=m +no_defs"
))
country_map <- sf::st_transform(country_wgs84, map_crs)
provinces_map <- sf::st_transform(provinces_wgs84, map_crs)
maritime_map <- sf::st_transform(maritime_wgs84, map_crs)

# Simplify only temporary basemap copies. This is the main SVG-size control.
svg_simplify_tolerance_m <- 10000
simplify_for_plot <- function(x, tolerance) {
  out <- suppressWarnings(sf::st_simplify(
    sf::st_make_valid(x),
    dTolerance = tolerance,
    preserveTopology = TRUE
  ))
  out[!sf::st_is_empty(out), , drop = FALSE]
}

# Lightly simplify county polygons for Word-compatible SVG rendering. Attribute
# values and county records are unchanged; only redundant boundary vertices are
# removed from the temporary plotting copies.
county_svg_tolerance_m <- 6000
CMFD_freqs_means_plot <- sf::st_transform(CMFD_freqs_means_sf, map_crs)
CMFD_all_trends_plot <- sf::st_transform(CMFD_all_trends_sf, map_crs)
signif_centroids <- sf::st_transform(signif_centroids, map_crs)
signif_xy <- sf::st_coordinates(signif_centroids)
signif_centroids$x <- signif_xy[, 1]
signif_centroids$y <- signif_xy[, 2]

country_plot <- simplify_for_plot(country_map, svg_simplify_tolerance_m)
provinces_plot <- simplify_for_plot(provinces_map, svg_simplify_tolerance_m)
maritime_plot <- simplify_for_plot(maritime_map, svg_simplify_tolerance_m)

# Convert polygons to boundary lines before cropping, preventing artificial crop edges.
country_boundary <- sf::st_as_sf(sf::st_boundary(sf::st_union(country_plot)))
# Keep boundaries for every province. Unioning first would dissolve the
# internal administrative borders and leave only the national outline.
province_boundary <- sf::st_as_sf(sf::st_boundary(provinces_plot))

# -----------------------------------------------------------------------------
# Main northern map and one combined southern/maritime inset per facet
# -----------------------------------------------------------------------------

# Use exactly the same northern extent, Anhui cutoff and inset ratio as Figure 3.
main_box_ll <- sf::st_bbox(
  c(xmin = 75.5, ymin = 29, xmax = 133.5, ymax = 52.8),
  crs = sf::st_crs(4326)
)
main_box <- sf::st_bbox(sf::st_transform(sf::st_as_sfc(main_box_ll), map_crs))
main_x_limits <- unname(main_box[c("xmin", "xmax")])
main_y_limits <- MAP_YLIM
main_y_limits[1] <- min(
  main_y_limits[1],
  unname(sf::st_bbox(sf::st_transform(anhui_wgs84, map_crs))["ymin"]) - 30000
)

south_cut <- unname(sf::st_bbox(sf::st_transform(anhui_wgs84, 4326))["ymin"])
south_box <- sf::st_bbox(
  c(xmin = 73, ymin = 3, xmax = 135, ymax = south_cut),
  crs = sf::st_crs(4326)
)
map_line_wgs84 <- function(x) {
  x <- sf::st_transform(x, 4326)
  if (any(grepl("POLYGON", as.character(sf::st_geometry_type(x))))) {
    sf::st_geometry(x) <- sf::st_boundary(sf::st_geometry(x))
  }
  x
}
crop_south <- function(x) {
  geometry <- sf::st_geometry(map_line_wgs84(x))
  sf::st_crs(geometry) <- NA
  geometry <- suppressWarnings(sf::st_crop(geometry, unclass(south_box)))
  geometry <- suppressWarnings(sf::st_collection_extract(geometry, "LINESTRING"))
  sf::st_crs(geometry) <- 4326
  simplify_for_plot(sf::st_transform(sf::st_sf(geometry = geometry), map_crs), 10000)
}

country_south <- crop_south(country_wgs84)
province_south <- crop_south(provinces_wgs84)
maritime_south <- crop_south(maritime_wgs84)
south_layers <- Filter(
  function(x) nrow(x) > 0 && !all(sf::st_is_empty(x)),
  list(country_south, province_south, maritime_south)
)
if (length(south_layers) == 0) {
  stop("No southern land or maritime geometry was found for the inset.", call. = FALSE)
}
south_bbox <- sf::st_bbox(do.call(rbind, south_layers))

# Match Figure 3 exactly and preserve the source/target aspect ratio.
panel_width <- diff(main_x_limits)
panel_height <- diff(main_y_limits)
inset_xmin <- main_x_limits[2] - INSET_LEFT * panel_width
inset_xmax <- main_x_limits[2] - INSET_RIGHT * panel_width
inset_ymin <- main_y_limits[1] + INSET_BOTTOM * panel_height
inset_scale <- (inset_xmax - inset_xmin) /
  unname(south_bbox["xmax"] - south_bbox["xmin"])
inset_ymax <- inset_ymin + inset_scale *
  unname(south_bbox["ymax"] - south_bbox["ymin"])
inset_bbox <- c(
  xmin = inset_xmin, ymin = inset_ymin,
  xmax = inset_xmax, ymax = inset_ymax
)

scale_sf_to_bbox <- function(x, source_bbox, target_bbox) {
  if (nrow(x) == 0) return(x)
  source_center <- unname(c(
    mean(source_bbox[c("xmin", "xmax")]),
    mean(source_bbox[c("ymin", "ymax")])
  ))
  target_center <- unname(c(
    mean(target_bbox[c("xmin", "xmax")]),
    mean(target_bbox[c("ymin", "ymax")])
  ))
  scale_factor <- unname(min(
    as.numeric(diff(target_bbox[c("xmin", "xmax")])) /
      as.numeric(diff(source_bbox[c("xmin", "xmax")])),
    as.numeric(diff(target_bbox[c("ymin", "ymax")])) /
      as.numeric(diff(source_bbox[c("ymin", "ymax")]))
  ))
  if (anyNA(c(source_center, target_center, scale_factor)) ||
      !all(is.finite(c(source_center, target_center, scale_factor))) ||
      scale_factor <= 0) {
    stop(
      "Invalid numeric coordinates in southern-inset transformation: ",
      paste(c(source_center, target_center, scale_factor), collapse = ", "),
      call. = FALSE
    )
  }
  geometry <- (sf::st_geometry(x) - source_center) * scale_factor + target_center
  sf::st_geometry(x) <- geometry
  sf::st_crs(x) <- map_crs
  x
}

make_frame <- function(bbox, crs) {
  xy <- matrix(
    c(
      bbox["xmin"], bbox["ymin"], bbox["xmax"], bbox["ymin"],
      bbox["xmax"], bbox["ymax"], bbox["xmin"], bbox["ymax"],
      bbox["xmin"], bbox["ymin"]
    ),
    ncol = 2,
    byrow = TRUE
  )
  sf::st_sf(geometry = sf::st_sfc(sf::st_polygon(list(xy)), crs = crs))
}

country_south_inset <- scale_sf_to_bbox(country_south, south_bbox, inset_bbox)
province_south_inset <- scale_sf_to_bbox(province_south, south_bbox, inset_bbox)
maritime_south_inset <- scale_sf_to_bbox(maritime_south, south_bbox, inset_bbox)
inset_frame <- make_frame(inset_bbox, map_crs)

# -----------------------------------------------------------------------------
# Shared map layers and themes
# -----------------------------------------------------------------------------

figure_font <- "sans"
base_map_layers <- list(
  ggplot2::geom_sf(
    data = province_boundary,
    fill = NA,
    colour = "grey38",
    linewidth = 0.16,
    inherit.aes = FALSE,
    show.legend = FALSE
  ),
  ggplot2::geom_sf(
    data = country_boundary,
    fill = NA,
    colour = "grey45",
    linewidth = 0.16,
    inherit.aes = FALSE,
    show.legend = FALSE
  ),
  ggplot2::geom_sf(
    data = province_south_inset,
    fill = NA,
    colour = "grey38",
    linewidth = 0.12,
    inherit.aes = FALSE,
    show.legend = FALSE
  ),
  ggplot2::geom_sf(
    data = country_south_inset,
    fill = NA,
    colour = "grey45",
    linewidth = 0.14,
    inherit.aes = FALSE,
    show.legend = FALSE
  ),
  ggplot2::geom_sf(
    data = maritime_south_inset,
    colour = "grey45",
    linewidth = 0.12,
    inherit.aes = FALSE,
    show.legend = FALSE
  ),
  ggplot2::geom_sf(
    data = inset_frame,
    fill = NA,
    colour = "grey40",
    linewidth = 0.20,
    inherit.aes = FALSE,
    show.legend = FALSE
  )
)

map_theme <- ggplot2::theme_bw(base_family = figure_font, base_size = 8) +
  ggplot2::theme(
    plot.subtitle = ggplot2::element_text(size = 8.5, hjust = 0.02, margin = ggplot2::margin(b = 2)),
    strip.text = ggplot2::element_text(size = 8),
    strip.background = ggplot2::element_rect(fill = "grey85", colour = NA),
    axis.ticks = ggplot2::element_blank(),
    axis.text = ggplot2::element_blank(),
    axis.title = ggplot2::element_blank(),
    panel.spacing = grid::unit(0.08, "cm"),
    legend.background = ggplot2::element_blank(),
    legend.text = ggplot2::element_text(size = 7.2),
    legend.title = ggplot2::element_text(size = 7.4),
    plot.margin = ggplot2::margin(1, 0, 1, 0, unit = "mm"),
    plot.background = ggplot2::element_rect(fill = "transparent", colour = NA)
  )

map_coord <- ggplot2::coord_sf(
  crs = map_crs,
  xlim = main_x_limits,
  ylim = main_y_limits,
  expand = FALSE,
  clip = "on",
  datum = sf::st_crs(4326)
)

HDW_CMFD_mean_gg <- ggplot2::ggplot() +
  ggplot2::geom_sf(
    data = CMFD_freqs_means_plot,
    ggplot2::aes(fill = mean_hours),
    colour = NA,
    linewidth = 0
  ) +
  base_map_layers +
  ggplot2::scale_fill_stepsn(
    colours = RColorBrewer::brewer.pal(9, "BuPu"),
    na.value = "white",
    breaks = c(0, 1, 2, 3, 4, 5, 10, 20, 40, 140),
    labels = c(0, 1, 2, 3, 4, 5, 10, 20, 40, ">40"),
    values = scales::rescale(c(seq(0, 5, 0.5), seq(10, 40, 5), 140)),
    name = expression(Hours~~(season^{-1})),
    guide = ggplot2::guide_coloursteps(
      title.position = "top",
      title.hjust = 0.5,
      label.position = "bottom",
      barwidth = grid::unit(4.2, "cm"),
      barheight = grid::unit(0.22, "cm")
    )
  ) +
  ggplot2::labs(subtitle = expression("(a) Averaged " * HDW["HD-MT"])) +
  ggplot2::facet_grid(Type ~ .) +
  map_coord +
  map_theme +
  ggplot2::theme(
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.margin = ggplot2::margin(t = 1, unit = "mm")
  )

HDW_CMFD_freq_gg <- ggplot2::ggplot() +
  ggplot2::geom_sf(
    data = CMFD_freqs_means_plot,
    ggplot2::aes(fill = freq_years * 100),
    colour = NA,
    linewidth = 0
  ) +
  base_map_layers +
  ggplot2::scale_fill_stepsn(
    colours = RColorBrewer::brewer.pal(9, "BuPu"),
    breaks = seq(0, 100, 20),
    limits = c(0, 100),
    na.value = "white",
    values = scales::rescale(seq(0, 100, 10)),
    name = "Frequency\u00A0\u00A0(%)",
    guide = ggplot2::guide_coloursteps(
      title.position = "top",
      title.hjust = 0.5,
      label.position = "bottom",
      barwidth = grid::unit(3.45, "cm"),
      barheight = grid::unit(0.22, "cm")
    )
  ) +
  ggplot2::labs(subtitle = expression("(b) " * HDW["HD-MT"] * " frequency")) +
  ggplot2::facet_grid(Type ~ .) +
  map_coord +
  map_theme +
  ggplot2::theme(
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.margin = ggplot2::margin(t = 1, r = 4, b = 0, l = 4, unit = "mm")
  )

HDW_CMFD_trend_gg <- ggplot2::ggplot() +
  ggplot2::geom_sf(
    data = CMFD_all_trends_plot,
    ggplot2::aes(fill = trend * 10),
    colour = "grey95",
    linewidth = 0.05
  ) +
  base_map_layers +
  ggplot2::geom_point(
    data = signif_centroids,
    ggplot2::aes(x = x, y = y, size = size_pt*0.6),
    shape = "+",
    colour = "grey35",
    stroke = 0,
    inherit.aes = FALSE
  ) +
  # Preserve the original county-area scaling: ggplot maps the supplied
  # area-derived size_pt values across the visible point-size range.
  ggplot2::scale_size_continuous(guide = "none") +
  ggplot2::scale_fill_stepsn(
    colours = rev(RColorBrewer::brewer.pal(11, "RdBu")[c(1:5, 8, 9)]),
    breaks = seq(-4, 10, 2),
    limits = c(-4, 10),
    na.value = "white",
    values = scales::rescale(seq(-4, 10, 1)),
    name = expression(Trend~~(hours~decade^{-1})),
    guide = ggplot2::guide_coloursteps(
      title.position = "top",
      title.hjust = 0.5,
      label.position = "bottom",
      barwidth = grid::unit(5.2, "cm"),
      barheight = grid::unit(0.22, "cm")
    )
  ) +
  ggplot2::labs(subtitle = expression("(c) " * HDW["HD-MT"] * " trends")) +
  ggplot2::facet_grid(Type ~ .) +
  map_coord +
  map_theme +
  ggplot2::theme(
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.margin = ggplot2::margin(t = 1, unit = "mm")
  )

# Extract legends before layout so their bar widths cannot resize map panels.
mean_legend <- cowplot::get_legend(
  HDW_CMFD_mean_gg +
    ggplot2::theme(legend.position = "bottom", plot.margin = ggplot2::margin())
)
freq_legend <- cowplot::get_legend(
  HDW_CMFD_freq_gg +
    ggplot2::theme(legend.position = "bottom", plot.margin = ggplot2::margin())
)
trend_legend <- cowplot::get_legend(
  HDW_CMFD_trend_gg +
    ggplot2::theme(legend.position = "bottom", plot.margin = ggplot2::margin())
)

mean_map <- HDW_CMFD_mean_gg + ggplot2::theme(legend.position = "none")
freq_map <- HDW_CMFD_freq_gg + ggplot2::theme(legend.position = "none")
trend_map <- HDW_CMFD_trend_gg + ggplot2::theme(legend.position = "none")

left_column <- cowplot::plot_grid(
  mean_map,
  mean_legend,
  NULL,
  freq_map,
  freq_legend,
  NULL,
  ncol = 1,
  align = "v",
  axis = "lr",
  greedy = TRUE,
  rel_heights = c(1, 0.15, 0.040, 1, 0.15, 0.035)
)

right_column <- cowplot::plot_grid(
  trend_map,
  trend_legend,
  ncol = 1,
  align = "v",
  axis = "lr",
  greedy = TRUE,
  rel_heights = c(2, 0.15)
)

# Explicit placement prevents the fixed sf aspect ratio from opening a large
# automatic gutter between the left and right columns.
Figure_1_gg <- cowplot::ggdraw() +
  cowplot::draw_plot(left_column, x = -0.042, y = 0.020, width = 0.425, height = 0.970) +
  cowplot::draw_plot(right_column, x = 0.255, y = 0.020, width = 0.840, height = 0.970)

# -----------------------------------------------------------------------------

map_manifest <- map_source_manifest(
  country_file, province_files, maritime_file,
  main_x_limits, main_y_limits, inset_bbox
)
geometry_manifest <- data.frame(
  dataset = c("mean_frequency", "trend"),
  input_rows = c(nrow(CMFD_freqs_means_sf), nrow(CMFD_all_trends_sf)),
  plotted_rows = c(nrow(CMFD_freqs_means_plot), nrow(CMFD_all_trends_plot)),
  plotting_simplification_m = county_svg_tolerance_m,
  values_or_rows_filtered = FALSE
)
if (!identical(Sys.getenv("HDW_SKIP_EXPORT"), "1")) export_bundle(
  Figure_1_gg,
  list(
    mean_frequency_map = CMFD_freqs_means_plot,
    trend_map = CMFD_all_trends_plot,
    significance_markers = signif_centroids,
    geometry_manifest = geometry_manifest,
    map_manifest = map_manifest
  ),
  "Figure_1", 13.5, 14.5
)
export_six(Figure_1_gg, "Figure_1", 13.5, 14.5)