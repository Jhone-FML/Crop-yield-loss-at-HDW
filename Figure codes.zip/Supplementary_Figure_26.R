# Supplementary Figure 26 -------------------------------------------------------------
# Direct Excel-based reproduction. This file does not source any other R script.
library(readxl)
ROOT = "F:/Post PHD documents/Crop yield loss at DHW/Submission/NF_proof_2026_09_01/Upload_Ready"
FIGURE_OUTPUT_DIR = file.path(ROOT,"Figures")
AMAP_DIR = "D:/Crop yield loss at DHW/amap"
FIGURE_FONT = "sans"
NF_LEGEND_TEXT_PT = 6.6; NF_LEGEND_TITLE_PT = 7.8
TIFF_DPI=600; PNG_DPI=450
MAP_YLIM=c(3200000,6024402)
INSET_LEFT=.170; INSET_RIGHT=.006; INSET_BOTTOM=.018
BASEMAP_TOLERANCE_M=10000
dir.create(FIGURE_OUTPUT_DIR,recursive=TRUE,showWarnings=FALSE)
check_packages=function(x){m=x[!vapply(x,requireNamespace,logical(1),quietly=TRUE)];if(length(m))stop("Install required package(s): ",paste(m,collapse=", "))}
check_packages(c("svglite","ragg","devEMF"))
if(requireNamespace("cowplot",quietly=TRUE)) cowplot::set_null_device("agg")
save_device=function(plot,device,file,...){device(file,...);id=dev.cur();on.exit(if(id %in% dev.list())dev.off(id),add=TRUE);print(plot);invisible(file)}
export_six=function(plot,name,width_cm,height_cm){prefix=file.path(FIGURE_OUTPUT_DIR,name);w=width_cm/2.54;h=height_cm/2.54;
 save_device(plot,function(file,...)cairo_pdf(filename=file,...),paste0(prefix,".pdf"),width=w,height=h,family=FIGURE_FONT,bg="transparent");
 save_device(plot,svglite::svglite,paste0(prefix,".svg"),width=w,height=h,bg="transparent");
 save_device(plot,svg,paste0(prefix,"_word_compatible.svg"),width=w,height=h,family="sans",pointsize=11,bg="transparent",onefile=TRUE);
 save_device(plot,devEMF::emf,paste0(prefix,".emf"),width=w,height=h,family="sans",pointsize=11,coordDPI=600,emfPlus=TRUE);
 save_device(plot,ragg::agg_tiff,paste0(prefix,".tiff"),width=width_cm,height=height_cm,units="cm",res=TIFF_DPI,compression="lzw",background="white");
 save_device(plot,ragg::agg_png,paste0(prefix,".png"),width=width_cm,height=height_cm,units="cm",res=PNG_DPI,background="white")}
export_bundle=function(plot,data,name,width_cm,height_cm)export_six(plot,name,width_cm,height_cm)
join_excel=function(geometry,values,keys,columns){for(k in keys){geometry[[k]]=as.character(geometry[[k]]);values[[k]]=as.character(values[[k]])};gk=do.call(paste,c(sf::st_drop_geometry(geometry)[keys],sep="
"));vk=do.call(paste,c(values[keys],sep="
"));i=match(gk,vk);if(anyNA(i))stop("Geometry cannot be matched to Excel: ",paste(keys,collapse=", "));for(to in names(columns))geometry[[to]]=values[[columns[[to]]]][i];geometry}

library(ggplot2)
Ph_gg_df=as.data.frame(read_excel(file.path(ROOT,"Supplementary_Figure_26_source_data.xlsx"),sheet="Supplementary Figure 26"))

# Supplementary Figure 26: observed versus predicted phenology --------------
check_packages(c("ggplot2", "ggpmisc", "RColorBrewer"))
if (!exists("Ph_gg_df", inherits = TRUE) || !is.data.frame(Ph_gg_df))
  stop("Ph_gg_df is missing or is not a data frame.", call. = FALSE)
need <- c("Obs", "predicted", "stage", "group"); miss <- setdiff(need, names(Ph_gg_df))
if (length(miss)) stop("Ph_gg_df is missing: ", paste(miss, collapse = ", "), call. = FALSE)
if (!is.numeric(Ph_gg_df$Obs) || !is.numeric(Ph_gg_df$predicted))
  stop("Ph_gg_df$Obs and Ph_gg_df$predicted must be numeric.", call. = FALSE)

plot_data <- Ph_gg_df
plot_data$stage <- factor(plot_data$stage, levels = unique(plot_data$stage))
plot_data$group <- factor(plot_data$group, levels = unique(plot_data$group))
stage_levels <- levels(plot_data$stage)
if (length(stage_levels) > 8L) stop("The Dark2 palette supports at most 8 stages.", call. = FALSE)
stage_colours <- setNames(RColorBrewer::brewer.pal(8, "Dark2")[seq_along(stage_levels)],
  stage_levels)
Supplementary_Figure_26 <- ggplot(
  plot_data, aes(x = Obs, y = predicted, fill = stage, colour = stage)) +
  stat_density_2d(aes(alpha = after_stat(level)), geom = "polygon",
    contour_var = "density", colour = NA, show.legend = FALSE) +
  geom_point(alpha = 0.28, size = 0.55, show.legend = FALSE) +
  geom_smooth(aes(group = 1), method = "lm", formula = y ~ x, se = TRUE,
    colour = "grey45", fill = "grey80", linewidth = 0.45, alpha = 0.30) +
  ggpmisc::stat_poly_eq(
    aes(label = after_stat(paste(eq.label, rr.label, sep = "*\", \"*"))),
    formula = y ~ x, method = "lm", parse = TRUE,
    label.x = "left", label.y = "top", hjust = 0, vjust = 1,
    colour = "black", size = 2.15, show.legend = FALSE) +
  scale_fill_manual(values = stage_colours, drop = FALSE) +
  scale_colour_manual(values = stage_colours, drop = FALSE) +
  scale_alpha_continuous(range = c(0.10, 0.52), guide = "none") +
  scale_x_continuous(breaks = scales::breaks_pretty(n = 4)) +
  scale_y_continuous(breaks = scales::breaks_pretty(n = 4)) +
  facet_wrap(stage ~ group, scales = "free", ncol = 4) +
  labs(x = "Observations", y = "Predictions") +
  theme_bw(base_family = "sans", base_size = 8) +
  theme(
    strip.text = element_text(size = 7),
    strip.background = element_rect(fill = "grey90", colour = NA),
    axis.title = element_text(size = 8),
    axis.title.x = element_text(margin = margin(t = 3)),
    axis.title.y = element_text(margin = margin(r = 3)), axis.text = element_text(size = 6.5),
    panel.grid.major = element_line(colour = "grey90", linewidth = 0.25),
    panel.grid.minor = element_blank(), panel.spacing = unit(1.4, "mm"),
    legend.position = "none", plot.background = element_rect(fill = "transparent", colour = NA),
    plot.margin = margin(1, 1, 1, 1, unit = "mm"))
filter_manifest <- data.frame(input_rows = nrow(plot_data),
  finite_pairs = sum(is.finite(plot_data$Obs) & is.finite(plot_data$predicted)),
  excluded_nonfinite = sum(!is.finite(plot_data$Obs) | !is.finite(plot_data$predicted)))
if (!identical(Sys.getenv("HDW_SKIP_EXPORT"), "1")) export_bundle(
  Supplementary_Figure_26,
  list(plot_data = plot_data, filter_manifest = filter_manifest),
  "Supplementary_Figure_26", 15, 10)


export_six(Supplementary_Figure_26,"Supplementary_Figure_26", 15, 10)