# Supplementary Figure 6 -------------------------------------------------------------
# Direct Excel-based reproduction. This file does not source any other R script.
library(readxl)
ROOT = "F:/Post PHD documents/Crop yield loss at DHW/Submission/NF_proof_2026_09_01/Upload_Ready"
FIGURE_OUTPUT_DIR = file.path(ROOT, "Figures")
AMAP_DIR = "D:/Crop yield loss at DHW/amap"
FIGURE_FONT = "sans"
NF_LEGEND_TEXT_PT = 6.6; NF_LEGEND_TITLE_PT = 7.8
TIFF_DPI = 600; PNG_DPI = 450
MAP_YLIM = c(3200000, 6024402)
INSET_LEFT = 0.170; INSET_RIGHT = 0.006; INSET_BOTTOM = 0.018
BASEMAP_TOLERANCE_M = 10000
dir.create(FIGURE_OUTPUT_DIR, recursive = TRUE, showWarnings = FALSE)
check_packages = function(x) {
  miss = x[!vapply(x, requireNamespace, logical(1), quietly = TRUE)]
  if (length(miss)) stop("Install required package(s): ", paste(miss, collapse = ", "))
}
check_packages(c("svglite", "ragg", "devEMF"))
if (requireNamespace("cowplot", quietly = TRUE)) cowplot::set_null_device("agg")
save_device = function(plot, device, file, ...) {
  device(file, ...); id = dev.cur(); on.exit(if (id %in% dev.list()) dev.off(id), add = TRUE)
  print(plot); invisible(file)
}
export_six = function(plot, name, width_cm, height_cm) {
  prefix = file.path(FIGURE_OUTPUT_DIR, name); w = width_cm / 2.54; h = height_cm / 2.54
  save_device(plot, function(file, ...) cairo_pdf(filename = file, ...), paste0(prefix, ".pdf"),
    width = w, height = h, family = FIGURE_FONT, bg = "transparent")
  save_device(plot, svglite::svglite, paste0(prefix, ".svg"), width = w, height = h, bg = "transparent")
  save_device(plot, svg, paste0(prefix, "_word_compatible.svg"), width = w, height = h,
    family = "sans", pointsize = 11, bg = "transparent", onefile = TRUE)
  save_device(plot, devEMF::emf, paste0(prefix, ".emf"), width = w, height = h,
    family = "sans", pointsize = 11, coordDPI = 600, emfPlus = TRUE)
  save_device(plot, ragg::agg_tiff, paste0(prefix, ".tiff"), width = width_cm, height = height_cm,
    units = "cm", res = TIFF_DPI, compression = "lzw", background = "white")
  save_device(plot, ragg::agg_png, paste0(prefix, ".png"), width = width_cm, height = height_cm,
    units = "cm", res = PNG_DPI, background = "white")
}
export_bundle = function(plot, data, name, width_cm, height_cm) export_six(plot, name, width_cm, height_cm)
map_source_manifest = function(...) data.frame()
join_excel = function(geometry, values, keys, columns) {
  for (k in keys) { geometry[[k]] = as.character(geometry[[k]]); values[[k]] = as.character(values[[k]]) }
  gkey = do.call(paste, c(sf::st_drop_geometry(geometry)[keys], sep = "
"))
  vkey = do.call(paste, c(values[keys], sep = "
")); idx = match(gkey, vkey)
  if (anyNA(idx)) stop("Geometry cannot be matched to Excel for key: ", paste(keys, collapse = ", "))
  for (to in names(columns)) geometry[[to]] = values[[columns[[to]]]][idx]
  geometry
}

library(ggplot2)
library(ggpattern)
DHW_gg_df = as.data.frame(read_excel(file.path(ROOT,"Supplementary_Figure_6_source_data.xlsx"),sheet="Supplementary Figure 6"))
names(DHW_gg_df)[names(DHW_gg_df)=="sd"]="Std..Error"; names(DHW_gg_df)[names(DHW_gg_df)=="P value"]="Pr...t.."
DHW_gg_df$Type=factor(DHW_gg_df$Type,levels=c("HTLH","PRWD","DTWD")); DHW_gg_df$TimePeriod=factor(DHW_gg_df$TimePeriod,levels=c("Early","Middle","Late"))
DHW_gg_df$col=paste(DHW_gg_df$Type,DHW_gg_df$Y_levle,sep="_")
DHW_gg_df$signif=ifelse(DHW_gg_df$Pr...t..<0.001,"***",ifelse(DHW_gg_df$Pr...t..<0.01,"**",ifelse(DHW_gg_df$Pr...t..<0.05,"*","ns")))
DHW_gg_df$y_position=ifelse(DHW_gg_df$Estimate<0,(DHW_gg_df$Estimate-DHW_gg_df$Std..Error)*100-1,(DHW_gg_df$Estimate+DHW_gg_df$Std..Error)*100+1)

# Supplementary Figure 6: sensitivity estimates by period
library(ggplot2)
library(ggpattern)
library(grid)
library(RColorBrewer)

# Unified typography; edit these values once to update the whole figure.
figure_font_family <- "sans"
font_axis_title <- 9
font_axis_text <- 8
font_strip <- 8
font_legend <- 6
font_significance <- 8

# Display PRWD as PRGW in facet strips without changing the source data.
DHW_facet_labeller <- function(labels) {
  labels[] <- lapply(
    labels,
    function(x) gsub("PRWD", "PRGW", as.character(x), fixed = TRUE)
  )
  label_parsed(labels)
}

DHW_SEN_sing_spy_gg <- ggplot(
  DHW_gg_df,
  aes(
    x = TimePeriod,
    y = Estimate * 100,
    color = col,
    fill = col
  )
) +
  geom_bar_pattern(
    stat = "identity",
    alpha = 0.6,
    lwd = 0.05,
    aes(pattern = col),
    position = position_dodge(0.9),
    color = "black",
    pattern_fill = "black",
    pattern_angle = 45,
    pattern_density = 0.000001,
    pattern_size = 0.05,
    pattern_spacing = 0.1,
    pattern_key_scale_factor = 0.1
  ) +
  geom_errorbar(
    aes(
      ymin = (Estimate - Std..Error) * 100,
      ymax = (Estimate + Std..Error) * 100
    ),
    width = 0.2,
    position = position_dodge(0.9)
  ) +
  guides(
    fill = guide_legend(ncol = 2, label.position = "top")
  ) +
  geom_text(
    aes(y = y_position, label = signif),
    position = position_dodge(0.9),
    size = font_significance / ggplot2::.pt,
    vjust = 0.5,
    color = "black"
  ) +
  scale_x_discrete(
    " ",
    labels = c(
      "HTLH" = bquote(DHW[HTLH]),
      "PRWD" = bquote(DHW[PRGW]),
      "DTWD" = bquote(DHW[DTWD])
    )
  ) +
  ylab("Yield loss per standard unit (%)") +
  scale_pattern_manual(
    values = c("none", "none", "stripe", "none", "stripe", "none"),
    name = ""
  ) +
  scale_fill_manual(
    values = c(
      "orange3", "orangered4", "brown4",
      "orangered3", "orangered2"
    ),
    name = "",
    label = c(
      "County level: HTLH", "Field trail: HTLH",
      "County level: PRGW", "Field trail: PRGW",
      "County level: DTWD"
    )
  ) +
  scale_color_manual(
    values = c(
      "orange3", "orangered4", "brown4",
      "orangered3", "orangered2"
    ),
    name = "",
    label = c(
      "County level: HTLH", "Field trail: HTLH",
      "County level: PRGW", "Field trail: PRGW",
      "County level: DTWD"
    )
  ) +
  facet_grid(
    Type + Y_levle ~ Model_formatted,
    scales = "free_x",
    labeller = DHW_facet_labeller
  ) +
  theme_bw(
    base_family = figure_font_family,
    base_size = font_axis_text
  ) +
  theme(
    strip.text = element_text(size = font_strip),
    legend.key.size = unit(0.15, "cm"),
    axis.text.x = element_text(
      size = font_axis_text,
      angle = 45,
      vjust = 0.5
    ),
    axis.text.y = element_text(
      size = font_axis_text,
      angle = 0,
      vjust = 0.5
    ),
    axis.title = element_text(size = font_axis_title),
    legend.position = c(10.3, 0.95),
    legend.key.height = unit(0.12, "cm"),
    legend.background = element_blank(),
    legend.text = element_text(size = font_legend),
    legend.title = element_text(size = font_legend),
    strip.background = element_rect(color = "transparent"),
    plot.background = element_rect(
      fill = "transparent",
      colour = NA_character_
    )
  )




if (!identical(Sys.getenv("HDW_SKIP_EXPORT"), "1")) export_bundle(
  DHW_SEN_sing_spy_gg, list(plot_data = DHW_gg_df),
  "Supplementary_Figure_6", 16, 12
)

export_six(DHW_SEN_sing_spy_gg,  "Supplementary_Figure_6", 16, 12)
