# Supplementary Figure 15 -------------------------------------------------------------
# Direct Excel-based reproduction. This file does not source any other R script.
library(readxl)
ROOT = "F:/Post PHD documents/Crop yield loss at DHW/Submission/NF_proof_2026_09_01/Upload_Ready"
FIGURE_OUTPUT_DIR = file.path(ROOT,"Figures")
AMAP_DIR = "D:/Crop yield loss at DHW/amap"
FIGURE_FONT = "sans"
NF_LEGEND_TEXT_PT = 6.6; NF_LEGEND_TITLE_PT = 7.8
TIFF_DPI=600; PNG_DPI=450
MAP_YLIM=c(3200000,6024402)
INSET_LEFT=.170; INSET_RIGHT=.006; INSET_BOTTOM=.018
BASEMAP_TOLERANCE_M=10000
dir.create(FIGURE_OUTPUT_DIR,recursive=TRUE,showWarnings=FALSE)
check_packages=function(x){m=x[!vapply(x,requireNamespace,logical(1),quietly=TRUE)];if(length(m))stop("Install required package(s): ",paste(m,collapse=", "))}
check_packages(c("svglite","ragg","devEMF"))
if(requireNamespace("cowplot",quietly=TRUE)) cowplot::set_null_device("agg")
save_device=function(plot,device,file,...){device(file,...);id=dev.cur();on.exit(if(id %in% dev.list())dev.off(id),add=TRUE);print(plot);invisible(file)}
export_six=function(plot,name,width_cm,height_cm){prefix=file.path(FIGURE_OUTPUT_DIR,name);w=width_cm/2.54;h=height_cm/2.54;
 save_device(plot,function(file,...)cairo_pdf(filename=file,...),paste0(prefix,".pdf"),width=w,height=h,family=FIGURE_FONT,bg="transparent");
 save_device(plot,svglite::svglite,paste0(prefix,".svg"),width=w,height=h,bg="transparent");
 save_device(plot,svg,paste0(prefix,"_word_compatible.svg"),width=w,height=h,family="sans",pointsize=11,bg="transparent",onefile=TRUE);
 save_device(plot,devEMF::emf,paste0(prefix,".emf"),width=w,height=h,family="sans",pointsize=11,coordDPI=600,emfPlus=TRUE);
 save_device(plot,ragg::agg_tiff,paste0(prefix,".tiff"),width=width_cm,height=height_cm,units="cm",res=TIFF_DPI,compression="lzw",background="white");
 save_device(plot,ragg::agg_png,paste0(prefix,".png"),width=width_cm,height=height_cm,units="cm",res=PNG_DPI,background="white")}
export_bundle=function(plot,data,name,width_cm,height_cm)export_six(plot,name,width_cm,height_cm)
join_excel=function(geometry,values,keys,columns){for(k in keys){geometry[[k]]=as.character(geometry[[k]]);values[[k]]=as.character(values[[k]])};gk=do.call(paste,c(sf::st_drop_geometry(geometry)[keys],sep="
"));vk=do.call(paste,c(values[keys],sep="
"));i=match(gk,vk);if(anyNA(i))stop("Geometry cannot be matched to Excel: ",paste(keys,collapse=", "));for(to in names(columns))geometry[[to]]=values[[columns[[to]]]][i];geometry}

prepare_latest_amap=local({cache=NULL;function(amap_dir=AMAP_DIR){if(!is.null(cache)&&identical(cache$amap_dir,amap_dir))return(cache);crs=sf::st_crs(paste("+proj=aea +lat_1=25 +lat_2=47 +lat_0=0 +lon_0=105","+datum=WGS84 +units=m +no_defs"));files=c(country=file.path(amap_dir,"land","100000.geojson"),maritime=file.path(amap_dir,"maritime","100000.geojson"),anhui=file.path(amap_dir,"province_land","340000.geojson"));pf=sort(list.files(file.path(amap_dir,"province_land"),"[.]geojson$",full.names=TRUE));readg=function(p)sf::st_sf(geometry=sf::st_geometry(sf::st_transform(sf::st_read(p,quiet=TRUE),4326)));country=readg(files["country"]);maritime=readg(files["maritime"]);anhui=readg(files["anhui"]);province=do.call(rbind,lapply(pf,readg));cut=unname(sf::st_bbox(anhui)["ymin"]);asline=function(x){if(any(grepl("POLYGON",as.character(sf::st_geometry_type(x)))))sf::st_geometry(x)=sf::st_boundary(sf::st_geometry(x));x};project=function(x){x=sf::st_transform(x,crs);x=suppressWarnings(sf::st_simplify(x,BASEMAP_TOLERANCE_M,preserveTopology=TRUE));x[!sf::st_is_empty(x),]};lines=lapply(list(country,province,maritime),asline);north=lapply(lines,project);main=sf::st_bbox(sf::st_transform(sf::st_as_sfc(sf::st_bbox(c(xmin=75.5,ymin=29,xmax=133.5,ymax=52.8),crs=sf::st_crs(4326))),crs));xlim=unname(main[c("xmin","xmax")]);ylim=MAP_YLIM;ylim[1]=min(ylim[1],unname(sf::st_bbox(sf::st_transform(anhui,crs))["ymin"])-30000);box=sf::st_bbox(c(xmin=73,ymin=3,xmax=135,ymax=cut),crs=sf::st_crs(4326));crop=function(x){g=sf::st_geometry(x);sf::st_crs(g)=NA;g=suppressWarnings(sf::st_crop(g,unclass(box)));g=suppressWarnings(sf::st_collection_extract(g,"LINESTRING"));sf::st_crs(g)=4326;project(sf::st_sf(geometry=g))};south=lapply(lines,crop);src=sf::st_bbox(do.call(rbind,south));pw=diff(xlim);ph=diff(ylim);xmin=xlim[2]-INSET_LEFT*pw;xmax=xlim[2]-INSET_RIGHT*pw;ymin=ylim[1]+INSET_BOTTOM*ph;sc=(xmax-xmin)/unname(src["xmax"]-src["xmin"]);ymax=ymin+sc*unname(src["ymax"]-src["ymin"]);inset=lapply(south,function(x){g=(sf::st_geometry(x)-unname(src[c("xmin","ymin")]))*sc+c(xmin,ymin);sf::st_sf(geometry=sf::st_set_crs(g,crs))});frame=sf::st_as_sf(sf::st_as_sfc(sf::st_bbox(c(xmin=xmin,ymin=ymin,xmax=xmax,ymax=ymax),crs=crs)));cache<<-list(amap_dir=amap_dir,crs=crs,xlim=xlim,ylim=ylim,north=north,inset=inset,frame=frame,south_cut_lat=cut,province_files=pf,country_file=files["country"],maritime_file=files["maritime"]);cache}})
latest_amap_layers=function(b){line=function(x,col,w)ggplot2::geom_sf(data=x,fill=NA,colour=col,linewidth=w,inherit.aes=FALSE,show.legend=FALSE);list(line(b$north[[2]],"grey55",.10),line(b$north[[1]],"grey45",.18),line(b$inset[[2]],"grey55",.08),line(b$inset[[1]],"grey45",.16),line(b$inset[[3]],"grey45",.14),line(b$frame,"grey45",.20))}
latest_amap_manifest=function(b)data.frame()

library(ggplot2)
library(sf)
library(cowplot)
a=as.data.frame(read_excel(file.path(ROOT,"Supplementary_Figure_15_source_data.xlsx"),sheet="Supplementary Figure 15 a"))
b=as.data.frame(read_excel(file.path(ROOT,"Supplementary_Figure_15_source_data.xlsx"),sheet="Supplementary Figure 15 b"))
a[["Mean yield (kg ha-1)"]]=suppressWarnings(as.numeric(a[["Mean yield (kg ha-1)"]]))
b[["sd (kg ha-1)"]]=suppressWarnings(as.numeric(b[["sd (kg ha-1)"]]))
Y_Mean_sf=st_read(file.path(ROOT,"Supplementary_Figure_15_geometry.gpkg"),layer="map",quiet=TRUE)
Y_Mean_sf=join_excel(Y_Mean_sf,a,"site",c(fn1="Mean yield (kg ha-1)"))
YYS_Mean=b;names(YYS_Mean)=c("year","fn1","fn2")

# Supplementary Figure 15: mean yield and annual variation ------------------
check_packages(c("ggplot2", "sf", "cowplot", "RColorBrewer", "scales"))
if (!exists("Y_Mean_sf", inherits = TRUE) || !inherits(Y_Mean_sf, "sf"))
  stop("Y_Mean_sf is missing or is not an sf object.", call. = FALSE)
if (!exists("YYS_Mean", inherits = TRUE) || !is.data.frame(YYS_Mean))
  stop("YYS_Mean is missing or is not a data frame.", call. = FALSE)
if (!"fn1" %in% names(Y_Mean_sf) || !is.numeric(sf::st_drop_geometry(Y_Mean_sf)$fn1))
  stop("Y_Mean_sf$fn1 must be numeric.", call. = FALSE)
need <- c("year", "fn1", "fn2"); miss <- setdiff(need, names(YYS_Mean))
if (length(miss)) stop("YYS_Mean is missing: ", paste(miss, collapse = ", "), call. = FALSE)
if (!all(vapply(YYS_Mean[need], is.numeric, logical(1))))
  stop("YYS_Mean$year, $fn1 and $fn2 must be numeric.", call. = FALSE)

basemap <- prepare_latest_amap()
yield_map <- suppressWarnings(sf::st_simplify(
  sf::st_transform(Y_Mean_sf, basemap$crs), 2500, preserveTopology = TRUE))
annual <- YYS_Mean; base_layers <- latest_amap_layers(basemap)
yield_breaks <- seq(0, 8000, 1000)
Y_mean_gg <- ggplot() +
  geom_sf(data = yield_map, aes(fill = fn1), colour = "grey85", linewidth = 0.035) +
  base_layers +
  scale_fill_stepsn(
    colours = RColorBrewer::brewer.pal(9, "YlGn"), breaks = yield_breaks,
    labels = yield_breaks, limits = range(yield_breaks), oob = scales::squish,
    na.value = "white", name = "kg ha⁻¹",
    guide = guide_colorsteps(direction = "vertical", title.position = "top",
      label.position = "right", barheight = unit(3.25, "cm"),
      barwidth = unit(0.23, "cm"), ticks = TRUE)) +
  labs(title = "(a) Mean yield, 1981-2018") +
  coord_sf(crs = basemap$crs, xlim = basemap$xlim, ylim = basemap$ylim,
    expand = FALSE, clip = "on", datum = sf::st_crs(4326)) +
  theme_bw(base_family = "sans", base_size = 8) +
  theme(
    plot.title = element_text(size = 9, hjust = 0.01),
    axis.title = element_blank(), axis.ticks = element_blank(), axis.text = element_blank(),
    panel.grid.major = element_line(colour = "grey90", linewidth = 0.28),
    panel.grid.minor = element_blank(), legend.position = "left",
    legend.direction = "vertical",
    legend.background = element_rect(fill = "transparent", colour = NA),
    legend.key = element_rect(fill = "transparent", colour = NA),
    legend.box.background = element_rect(fill = "transparent", colour = NA),
    legend.title = element_text(size = 6.5, hjust = 0.5),
    legend.text = element_text(size = 6),
    legend.margin = margin(0, 1, 0, 0, unit = "mm"),
    plot.background = element_rect(fill = "transparent", colour = NA),
    plot.margin = margin(0.5, 0.6, 0.5, 0.5, unit = "mm"))

YYS_Mean_gg <- ggplot(annual, aes(year, fn1)) +
  geom_errorbar(aes(ymin = fn1 - fn2, ymax = fn1 + fn2), width = 0.18,
    linewidth = 0.35, colour = "grey45") +
  geom_line(linewidth = 0.50, colour = "black") +
  geom_point(size = 1.15, shape = 21, fill = "white", colour = "black", stroke = 0.35) +
  scale_x_continuous(breaks = scales::breaks_pretty(n = 6),
    expand = expansion(mult = c(0.02, 0.02))) +
  scale_y_continuous(breaks = scales::breaks_pretty(n = 5),
    expand = expansion(mult = c(0.05, 0.08))) +
  labs(title = "(b)", x = "Year", y = "Yield (kg ha⁻¹)") +
  theme_bw(base_family = "sans", base_size = 8) +
  theme(
    plot.title = element_text(size = 9, hjust = 0.01), axis.title = element_text(size = 8),
    axis.title.x = element_text(margin = margin(t = 3)),
    axis.title.y = element_text(margin = margin(r = 3)), axis.text = element_text(size = 7),
    panel.grid.major = element_line(colour = "grey90", linewidth = 0.28),
    panel.grid.minor = element_blank(), legend.position = "none",
    plot.background = element_rect(fill = "transparent", colour = NA),
    plot.margin = margin(0.5, 0.5, 0.5, 0.6, unit = "mm"))

Supplementary_Figure_15 <- cowplot::plot_grid(
  Y_mean_gg, YYS_Mean_gg, nrow = 1, align = "hv", axis = "tblr",
  rel_widths = c(0.54, 0.46))
map_manifest <- latest_amap_manifest(basemap)
geometry_manifest <- data.frame(input_rows = nrow(Y_Mean_sf), plotted_rows = nrow(yield_map),
  plotting_simplification_m = 2500, values_or_rows_filtered = FALSE)
if (!identical(Sys.getenv("HDW_SKIP_EXPORT"), "1")) export_bundle(
  Supplementary_Figure_15,
  list(map = yield_map, annual = annual, geometry_manifest = geometry_manifest,
       map_manifest = map_manifest),
  "Supplementary_Figure_15", 16, 5.2)

export_six(Supplementary_Figure_15,"Supplementary_Figure_15",16, 5.2)
