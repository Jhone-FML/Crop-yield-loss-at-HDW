# Supplementary Figure 25 -------------------------------------------------------------
# Direct Excel-based reproduction. This file does not source any other R script.
library(readxl)
ROOT = "F:/Post PHD documents/Crop yield loss at DHW/Submission/NF_proof_2026_09_01/Upload_Ready"
FIGURE_OUTPUT_DIR = file.path(ROOT,"Figures")
AMAP_DIR = "D:/Crop yield loss at DHW/amap"
FIGURE_FONT = "sans"
NF_LEGEND_TEXT_PT = 6.6; NF_LEGEND_TITLE_PT = 7.8
TIFF_DPI=600; PNG_DPI=450
MAP_YLIM=c(3200000,6024402)
INSET_LEFT=.170; INSET_RIGHT=.006; INSET_BOTTOM=.018
BASEMAP_TOLERANCE_M=10000
dir.create(FIGURE_OUTPUT_DIR,recursive=TRUE,showWarnings=FALSE)
check_packages=function(x){m=x[!vapply(x,requireNamespace,logical(1),quietly=TRUE)];if(length(m))stop("Install required package(s): ",paste(m,collapse=", "))}
check_packages(c("svglite","ragg","devEMF"))
if(requireNamespace("cowplot",quietly=TRUE)) cowplot::set_null_device("agg")
save_device=function(plot,device,file,...){device(file,...);id=dev.cur();on.exit(if(id %in% dev.list())dev.off(id),add=TRUE);print(plot);invisible(file)}
export_six=function(plot,name,width_cm,height_cm){prefix=file.path(FIGURE_OUTPUT_DIR,name);w=width_cm/2.54;h=height_cm/2.54;
 save_device(plot,function(file,...)cairo_pdf(filename=file,...),paste0(prefix,".pdf"),width=w,height=h,family=FIGURE_FONT,bg="transparent");
 save_device(plot,svglite::svglite,paste0(prefix,".svg"),width=w,height=h,bg="transparent");
 save_device(plot,svg,paste0(prefix,"_word_compatible.svg"),width=w,height=h,family="sans",pointsize=11,bg="transparent",onefile=TRUE);
 save_device(plot,devEMF::emf,paste0(prefix,".emf"),width=w,height=h,family="sans",pointsize=11,coordDPI=600,emfPlus=TRUE);
 save_device(plot,ragg::agg_tiff,paste0(prefix,".tiff"),width=width_cm,height=height_cm,units="cm",res=TIFF_DPI,compression="lzw",background="white");
 save_device(plot,ragg::agg_png,paste0(prefix,".png"),width=width_cm,height=height_cm,units="cm",res=PNG_DPI,background="white")}
export_bundle=function(plot,data,name,width_cm,height_cm)export_six(plot,name,width_cm,height_cm)
join_excel=function(geometry,values,keys,columns){for(k in keys){geometry[[k]]=as.character(geometry[[k]]);values[[k]]=as.character(values[[k]])};gk=do.call(paste,c(sf::st_drop_geometry(geometry)[keys],sep="
"));vk=do.call(paste,c(values[keys],sep="
"));i=match(gk,vk);if(anyNA(i))stop("Geometry cannot be matched to Excel: ",paste(keys,collapse=", "));for(to in names(columns))geometry[[to]]=values[[columns[[to]]]][i];geometry}

library(ggplot2)
x=as.data.frame(read_excel(file.path(ROOT,"Supplementary_Figure_25_source_data.xlsx"),sheet="Supplementary Figure 25"))
names(x)[names(x)=="Rate (%)"]="Rate"
x$Province=factor(x$Province,levels=unique(x$Province));x$Varieties=factor(x$Varieties,levels=rev(unique(x$Varieties)))

Supplementary_Figure_25=ggplot(x,aes(Province,Varieties,size=Rate,colour=Year))+geom_point(alpha=.70)+scale_colour_gradient(low="#CFF09E",high="#79BD9A",limits=c(2007,2018),breaks=c(2007,2010,2013,2016),name="Year",guide=guide_colourbar(direction="vertical",barheight=unit(5,"cm"),barwidth=unit(1,"cm"),title.position="top",order=1))+scale_size_continuous(range=c(1,20),limits=c(0,70),breaks=c(20,40,60),name="Rate",guide=guide_legend(order=2))+labs(x="Province",y="Varieties")+theme_gray(base_family=FIGURE_FONT,base_size=20)+theme(axis.text.x=element_text(angle=45,hjust=1,vjust=1),panel.grid.major=element_line(colour="white",linewidth=.35),panel.grid.minor=element_blank(),legend.position="right",legend.title=element_text(size=NF_LEGEND_TITLE_PT,hjust=0),legend.text=element_text(size=NF_LEGEND_TEXT_PT),plot.margin=margin(4,6,4,4,unit="mm"))
export_six(Supplementary_Figure_25,"Supplementary_Figure_25",35.56,50.8)
