# Supplementary Figure 12 -------------------------------------------------------------
# Direct Excel-based reproduction. This file does not source any other R script.
library(readxl)
ROOT = "F:/Post PHD documents/Crop yield loss at DHW/Submission/NF_proof_2026_09_01/Upload_Ready"
FIGURE_OUTPUT_DIR = file.path(ROOT,"Figures")
AMAP_DIR = "D:/Crop yield loss at DHW/amap"
FIGURE_FONT = "sans"
NF_LEGEND_TEXT_PT = 6.6; NF_LEGEND_TITLE_PT = 7.8
TIFF_DPI=600; PNG_DPI=450
MAP_YLIM=c(3200000,6024402)
INSET_LEFT=.170; INSET_RIGHT=.006; INSET_BOTTOM=.018
BASEMAP_TOLERANCE_M=10000
dir.create(FIGURE_OUTPUT_DIR,recursive=TRUE,showWarnings=FALSE)
check_packages=function(x){m=x[!vapply(x,requireNamespace,logical(1),quietly=TRUE)];if(length(m))stop("Install required package(s): ",paste(m,collapse=", "))}
check_packages(c("svglite","ragg","devEMF"))
if(requireNamespace("cowplot",quietly=TRUE)) cowplot::set_null_device("agg")
save_device=function(plot,device,file,...){device(file,...);id=dev.cur();on.exit(if(id %in% dev.list())dev.off(id),add=TRUE);print(plot);invisible(file)}
export_six=function(plot,name,width_cm,height_cm){prefix=file.path(FIGURE_OUTPUT_DIR,name);w=width_cm/2.54;h=height_cm/2.54;
 save_device(plot,function(file,...)cairo_pdf(filename=file,...),paste0(prefix,".pdf"),width=w,height=h,family=FIGURE_FONT,bg="transparent");
 save_device(plot,svglite::svglite,paste0(prefix,".svg"),width=w,height=h,bg="transparent");
 save_device(plot,svg,paste0(prefix,"_word_compatible.svg"),width=w,height=h,family="sans",pointsize=11,bg="transparent",onefile=TRUE);
 save_device(plot,devEMF::emf,paste0(prefix,".emf"),width=w,height=h,family="sans",pointsize=11,coordDPI=600,emfPlus=TRUE);
 save_device(plot,ragg::agg_tiff,paste0(prefix,".tiff"),width=width_cm,height=height_cm,units="cm",res=TIFF_DPI,compression="lzw",background="white");
 save_device(plot,ragg::agg_png,paste0(prefix,".png"),width=width_cm,height=height_cm,units="cm",res=PNG_DPI,background="white")}
export_bundle=function(plot,data,name,width_cm,height_cm)export_six(plot,name,width_cm,height_cm)
join_excel=function(geometry,values,keys,columns){for(k in keys){geometry[[k]]=as.character(geometry[[k]]);values[[k]]=as.character(values[[k]])};gk=do.call(paste,c(sf::st_drop_geometry(geometry)[keys],sep="
"));vk=do.call(paste,c(values[keys],sep="
"));i=match(gk,vk);if(anyNA(i))stop("Geometry cannot be matched to Excel: ",paste(keys,collapse=", "));for(to in names(columns))geometry[[to]]=values[[columns[[to]]]][i];geometry}

library(ggplot2)
library(cowplot)
Response=as.data.frame(read_excel(file.path(ROOT,"Supplementary_Figure_12_source_data.xlsx"),sheet="Supplementary Figure 12 a"))
Response_f=as.data.frame(read_excel(file.path(ROOT,"Supplementary_Figure_12_source_data.xlsx"),sheet="Supplementary Figure 12 b"))

# Supplementary Figure 11: partial dependence of cost-related drivers

required_packages <- c("ggplot2", "cowplot", "svglite", "ragg")
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
]
if (length(missing_packages) > 0L) {
  stop(
    paste("Install required package(s):", paste(missing_packages, collapse = ", ")),
    call. = FALSE
  )
}
suppressPackageStartupMessages({
  library(ggplot2)
  library(cowplot)
})

required_objects <- c("Response", "Response_f")
missing_objects <- required_objects[
  !vapply(required_objects, exists, logical(1), inherits = TRUE)
]
if (length(missing_objects) > 0L) {
  stop(
    paste("Missing required object(s):", paste(missing_objects, collapse = ", ")),
    call. = FALSE
  )
}

required_columns <- function(data, columns, object_name) {
  missing_columns <- setdiff(columns, names(data))
  if (length(missing_columns) > 0L) {
    stop(
      paste(object_name, "is missing:", paste(missing_columns, collapse = ", ")),
      call. = FALSE
    )
  }
}
required_columns(Response, c("x", "y", "Variables", "ID"), "Response")
required_columns(Response_f, c("x", "y", "Variables", "ID"), "Response_f")

# Variables and order visible in the original Supplementary Figure 11.
cost_variables <- c("Fertilizer", "Irrigation", "Mechanization", "Seed")
curve_id_levels <- c(
  "HTLH_Early_change",
  "HTLH_Middle_change",
  "HTLH_Late_change",
  "PRGW_Early_change",
  "PRGW_Middle_change",
  "PRGW_Late_change"
)
curve_labels <- c(
  "HTLH-E", "HTLH-M", "HTLH-L",
  "PRGW-E", "PRGW-M", "PRGW-L"
)
curve_colours <- c(
  "#66C2A5", "#FC8D62", "#8DA0CB",
  "#E78AC3", "#A6D854", "#FFD92F"
)
names(curve_labels) <- curve_id_levels
names(curve_colours) <- curve_id_levels

prepare_response_data <- function(data, source_name) {
  keep_variable <- !is.na(data$Variables) &
    data$Variables %in% cost_variables
  selected <- data[keep_variable, , drop = FALSE]
  
  finite_pair <- is.finite(selected$x) & is.finite(selected$y)
  plotted <- selected[finite_pair, , drop = FALSE]
  plotted$Variables_display <- factor(
    as.character(plotted$Variables),
    levels = cost_variables
  )
  plotted$ID_display <- factor(
    unname(curve_labels[as.character(plotted$ID)]),
    levels = unname(curve_labels)
  )
  
  unmatched_ids <- unique(
    as.character(plotted$ID)[is.na(plotted$ID_display)]
  )
  unmatched_ids <- unmatched_ids[!is.na(unmatched_ids)]
  if (length(unmatched_ids) > 0L) {
    stop(
      paste(
        source_name,
        "contains unmapped ID value(s):",
        paste(unmatched_ids, collapse = ", ")
      ),
      call. = FALSE
    )
  }
  if (nrow(plotted) == 0L) {
    stop(paste(source_name, "has no plottable rows."), call. = FALSE)
  }
  
  list(
    data = plotted,
    manifest = data.frame(
      source_object = source_name,
      input_rows = nrow(data),
      selected_cost_rows = nrow(selected),
      plotted_rows = nrow(plotted),
      excluded_other_variables = sum(!keep_variable),
      excluded_non_finite = sum(!finite_pair),
      variable_rule = paste(cost_variables, collapse = ", "),
      stringsAsFactors = FALSE
    )
  )
}

county_prepared <- prepare_response_data(Response, "Response")
field_prepared <- prepare_response_data(Response_f, "Response_f")
Response_county_plot <- county_prepared$data
Response_field_plot <- field_prepared$data
filter_manifest <- rbind(
  county_prepared$manifest,
  field_prepared$manifest
)

# Publication font: Arial-compatible Helvetica/sans-serif fallback.
figure_font_family <- "sans"
font_panel_title <- 10
font_strip <- 9
font_axis_text <- 8.5
font_axis_title <- 9.5
font_legend <- 8

common_colour_scale <- scale_colour_manual(
  name = NULL,
  values = setNames(curve_colours, curve_labels),
  breaks = curve_labels,
  drop = FALSE
)

common_theme <- theme_bw(
  base_family = figure_font_family,
  base_size = font_axis_text
) +
  theme(
    strip.text = element_text(size = font_strip, colour = "black"),
    axis.text.x = element_text(size = font_axis_text),
    axis.text.y = element_text(size = font_axis_text),
    axis.title = element_text(size = font_axis_title, colour = "black"),
    panel.spacing.x = grid::unit(0.22, "cm"),
    strip.background = element_rect(colour = "transparent"),
    plot.background = element_rect(fill = "transparent", colour = NA),
    plot.margin = margin(2, 3, 2, 3, unit = "mm")
  )

county_base <- ggplot(
  Response_county_plot,
  aes(x = x, y = y, colour = ID_display, group = ID_display)
) +
  geom_line(linewidth = 0.70) +
  facet_wrap(
    ~Variables_display,
    ncol = 4,
    scales = "free_x",
    drop = FALSE
  ) +
  common_colour_scale +
  labs(
    x = "Trend of cost\u00A0(CNY year\u207B\u00B9 kg\u207B\u00B9 ha)",
    y = expression(
      italic(beta)[HDW %*% year]~(kg~ha^-1~hour^-1~year^-1)
    ),
    title = "(a) Partial dependence of the drivers at the county scale"
  ) +
  common_theme +
  theme(
    plot.title = element_text(
      size = font_panel_title,
      hjust = 0,
      margin = margin(b = 3)
    )
  )

field_base <- ggplot(
  Response_field_plot,
  aes(x = x, y = y, colour = ID_display, group = ID_display)
) +
  geom_line(linewidth = 0.70) +
  facet_wrap(
    ~Variables_display,
    ncol = 4,
    scales = "free_x",
    drop = FALSE
  ) +
  common_colour_scale +
  labs(
    x = "Trend of cost\u00A0(CNY year\u207B\u00B9 kg\u207B\u00B9 ha)",
    y = expression(
      italic(beta)[HDW %*% year]~(kg~ha^-1~hour^-1~year^-1)
    ),
    title = "(b) Partial dependence of the drivers at the field scale"
  ) +
  common_theme +
  theme(
    plot.title = element_text(
      size = font_panel_title,
      hjust = 0,
      margin = margin(b = 3)
    ),
    legend.position = "none"
  )

shared_legend <- cowplot::get_legend(
  county_base +
    guides(
      colour = guide_legend(
        ncol = 3,
        byrow = TRUE,
        override.aes = list(linewidth = 0.9)
      )
    ) +
    theme(
      legend.position = "top",
      legend.direction = "horizontal",
      legend.justification = "center",
      legend.text = element_text(size = font_legend),
      legend.key.width = grid::unit(0.42, "cm"),
      legend.key.height = grid::unit(0.22, "cm"),
      legend.margin = margin(0, 0, 0, 0),
      plot.margin = margin(0, 0, 0, 0)
    )
)

county_panel <- county_base + theme(legend.position = "none")

Supplementary_Figure_12_gg <- cowplot::plot_grid(
  shared_legend,
  county_panel,
  field_base,
  ncol = 1,
  rel_heights = c(0.16, 0.42, 0.42),
  align = "v",
  axis = "lr"
)



if (!identical(Sys.getenv("HDW_SKIP_EXPORT"), "1")) export_bundle(
  Supplementary_Figure_12_gg,
  list(county_response = Response_county_plot, field_response = Response_field_plot,
       filter_manifest = filter_manifest),
  "Supplementary_Figure_12", 18, 17
)
export_six(Supplementary_Figure_12_gg,"Supplementary_Figure_12",18,17)
