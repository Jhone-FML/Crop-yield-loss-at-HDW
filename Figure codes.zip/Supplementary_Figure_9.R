# Supplementary Figure 9 -------------------------------------------------------------
# Direct Excel-based reproduction. This file does not source any other R script.
library(readxl)
ROOT = "F:/Post PHD documents/Crop yield loss at DHW/Submission/NF_proof_2026_09_01/Upload_Ready"
FIGURE_OUTPUT_DIR = file.path(ROOT, "Figures")
AMAP_DIR = "D:/Crop yield loss at DHW/amap"
FIGURE_FONT = "sans"
NF_LEGEND_TEXT_PT = 6.6; NF_LEGEND_TITLE_PT = 7.8
TIFF_DPI = 600; PNG_DPI = 450
MAP_YLIM = c(3200000, 6024402)
INSET_LEFT = 0.170; INSET_RIGHT = 0.006; INSET_BOTTOM = 0.018
BASEMAP_TOLERANCE_M = 10000
dir.create(FIGURE_OUTPUT_DIR, recursive = TRUE, showWarnings = FALSE)
check_packages = function(x) {
  miss = x[!vapply(x, requireNamespace, logical(1), quietly = TRUE)]
  if (length(miss)) stop("Install required package(s): ", paste(miss, collapse = ", "))
}
check_packages(c("svglite", "ragg", "devEMF"))
if (requireNamespace("cowplot", quietly = TRUE)) cowplot::set_null_device("agg")
save_device = function(plot, device, file, ...) {
  device(file, ...); id = dev.cur(); on.exit(if (id %in% dev.list()) dev.off(id), add = TRUE)
  print(plot); invisible(file)
}
export_six = function(plot, name, width_cm, height_cm) {
  prefix = file.path(FIGURE_OUTPUT_DIR, name); w = width_cm / 2.54; h = height_cm / 2.54
  save_device(plot, function(file, ...) cairo_pdf(filename = file, ...), paste0(prefix, ".pdf"),
    width = w, height = h, family = FIGURE_FONT, bg = "transparent")
  save_device(plot, svglite::svglite, paste0(prefix, ".svg"), width = w, height = h, bg = "transparent")
  save_device(plot, svg, paste0(prefix, "_word_compatible.svg"), width = w, height = h,
    family = "sans", pointsize = 11, bg = "transparent", onefile = TRUE)
  save_device(plot, devEMF::emf, paste0(prefix, ".emf"), width = w, height = h,
    family = "sans", pointsize = 11, coordDPI = 600, emfPlus = TRUE)
  save_device(plot, ragg::agg_tiff, paste0(prefix, ".tiff"), width = width_cm, height = height_cm,
    units = "cm", res = TIFF_DPI, compression = "lzw", background = "white")
  save_device(plot, ragg::agg_png, paste0(prefix, ".png"), width = width_cm, height = height_cm,
    units = "cm", res = PNG_DPI, background = "white")
}
export_bundle = function(plot, data, name, width_cm, height_cm) export_six(plot, name, width_cm, height_cm)
map_source_manifest = function(...) data.frame()
join_excel = function(geometry, values, keys, columns) {
  for (k in keys) { geometry[[k]] = as.character(geometry[[k]]); values[[k]] = as.character(values[[k]]) }
  gkey = do.call(paste, c(sf::st_drop_geometry(geometry)[keys], sep = "
"))
  vkey = do.call(paste, c(values[keys], sep = "
")); idx = match(gkey, vkey)
  if (anyNA(idx)) stop("Geometry cannot be matched to Excel for key: ", paste(keys, collapse = ", "))
  for (to in names(columns)) geometry[[to]] = values[[columns[[to]]]][idx]
  geometry
}

library(ggplot2)
library(cowplot)
panel_a_data = as.data.frame(read_excel(file.path(ROOT,"Supplementary_Figure_9_source_data.xlsx"),sheet="Supplementary Figure 9 a"))
names(panel_a_data)[names(panel_a_data)=="value (kg ha-1 hour-1)"]="value"
panel_a_data$varbs=factor(panel_a_data$varbs,levels=c("HTLH","PRWD","PRGW")); panel_a_data$Model=factor(panel_a_data$Model)
panel_b_data = as.data.frame(read_excel(file.path(ROOT,"Supplementary_Figure_9_source_data.xlsx"),sheet="Supplementary Figure 9 b"))
names(panel_b_data)[names(panel_b_data)=="Estimate (kg ha-1 hour-1)"]="Estimate"; names(panel_b_data)[names(panel_b_data)=="sd (kg ha-1 hour-1)"]="Std..Error"
panel_b_data$Type=factor(panel_b_data$Type); panel_b_data$group=panel_b_data$Type
summarized_df_filtered=panel_a_data; FHW_ychange_gg_df=panel_b_data

# Supplementary Figure 9: field-level HDW sensitivity -----------------------

pkgs <- c("ggplot2", "ggdist", "cowplot", "RColorBrewer", "scales",
          "svglite", "ragg", "devEMF")
miss <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
if (length(miss)) stop("Install: ", paste(miss, collapse = ", "), call. = FALSE)

library(ggplot2)

# Inputs ---------------------------------------------------------------------
if (!exists("summarized_df_filtered", inherits = TRUE) ||
    !is.data.frame(summarized_df_filtered))
  stop("summarized_df_filtered is missing or is not a data frame.", call. = FALSE)
if (!exists("FHW_ychange_gg_df", inherits = TRUE) ||
    !is.data.frame(FHW_ychange_gg_df))
  stop("FHW_ychange_gg_df is missing or is not a data frame.", call. = FALSE)

check_cols <- function(x, need, object) {
  miss <- setdiff(need, names(x))
  if (length(miss)) stop(object, " is missing: ", paste(miss, collapse = ", "),
                         call. = FALSE)
}
check_cols(summarized_df_filtered, c("varbs", "Y_levle", "value", "Model"),
           "summarized_df_filtered")
check_cols(FHW_ychange_gg_df, c("Type", "model", "year", "Estimate", "Std..Error"),
           "FHW_ychange_gg_df")
if (!is.numeric(summarized_df_filtered$value) ||
    !all(vapply(FHW_ychange_gg_df[c("year", "Estimate", "Std..Error")],
                is.numeric, logical(1))))
  stop("value, year, Estimate and Std..Error must be numeric.", call. = FALSE)

# Keep the original filters and values; NA classification rows cannot be drawn.
keep_a <- with(summarized_df_filtered,
               !is.na(varbs) & varbs != "DTWD" &
                 !is.na(Y_levle) & Y_levle != "County")
keep_b <- with(FHW_ychange_gg_df,
               !is.na(Type) & Type != "DryWind" &
                 !is.na(model) & model == "TSCD")
panel_a_data <- summarized_df_filtered
panel_b_data <- FHW_ychange_gg_df
if (!nrow(panel_a_data) || !nrow(panel_b_data))
  stop("One of the two panels has no data after the original filters.", call. = FALSE)

# Preserve supplied ordering when it exists; otherwise preserve first appearance.
factor_order <- function(x) {
  observed <- unique(as.character(x))
  if (is.factor(x)) levels(x)[levels(x) %in% observed] else observed
}
panel_a_data$varbs <- factor(as.character(panel_a_data$varbs),
                             levels = factor_order(panel_a_data$varbs))
panel_a_data$Model <- factor(as.character(panel_a_data$Model),
                             levels = factor_order(panel_a_data$Model))
panel_b_data$Type <- factor(as.character(panel_b_data$Type),
                            levels = factor_order(panel_b_data$Type))
panel_b_data <- panel_b_data[order(panel_b_data$Type, panel_b_data$year), ]

set2 <- RColorBrewer::brewer.pal(8, "Set2")
dark2 <- RColorBrewer::brewer.pal(8, "Dark2")
a_levels <- levels(panel_a_data$varbs)
b_levels <- levels(panel_b_data$Type)
if (length(a_levels) > 8 || length(b_levels) > 8)
  stop("The selected Brewer palettes support at most eight categories.", call. = FALSE)
a_colours <- setNames(set2[seq_along(a_levels)], a_levels)
b_colours <- setNames(dark2[c(2, 1, 3:8)][seq_along(b_levels)], b_levels)

# Panel (a) ------------------------------------------------------------------
field_sens_change_sum_gg <- ggplot(panel_a_data, aes(varbs, value)) +
  geom_hline(yintercept = 0, linewidth = 0.45, linetype = "dashed") +
  ggdist::stat_halfeye(
    aes(fill = varbs), adjust = 0.6, width = 0.78, .width = 0,
    alpha = 0.58, justification = -0.17, point_colour = NA
  ) +
  ggdist::stat_pointinterval(
    aes(colour = varbs), justification = 0.17, size = 0.65, alpha = 0.72
  ) +
  stat_summary(
    aes(label = after_stat(round(y, 1)), colour = varbs), fun = median,
    geom = "label", size = 2.15, vjust = -0.85, linewidth = 0.12,
    label.padding = grid::unit(0.08, "lines"),
    label.r = grid::unit(0.08, "lines"), fill = "white", show.legend = FALSE
  ) +
  scale_colour_manual(values = a_colours, drop = FALSE) +
  scale_fill_manual(values = a_colours, drop = FALSE) +
  scale_y_continuous(expand = expansion(mult = c(0.07, 0.15))) +
  facet_wrap(~Model, ncol = 2) +
  labs(
    tag = "(a)", x = "Types of HDW",
    y = expression("Changes in yield sensitivity to HDW"~(kg~ha^-1~hour^-1))
  ) +
  theme_bw(base_family = "sans", base_size = 7.5) +
  theme(
    plot.tag = element_text(size = 9, face = "bold"),
    plot.tag.position = c(0.01, 1),
    strip.text = element_text(size = 7.5),
    strip.background = element_rect(fill = "grey88", colour = NA),
    axis.title = element_text(size = 8),
    axis.title.x = element_text(margin = margin(t = 3)),
    axis.title.y = element_text(margin = margin(r = 3)),
    axis.text = element_text(size = 7),
    panel.grid.minor = element_blank(),
    panel.grid.major = element_line(colour = "grey92", linewidth = 0.25),
    panel.spacing = grid::unit(1.5, "mm"),
    legend.position = "none",
    plot.background = element_rect(fill = "transparent", colour = NA),
    plot.margin = margin(4, 2, 2, 2, unit = "mm")
  )

# Panel (b): intervals remain Estimate +/- Std..Error, as in the supplied code.
FHW_ychange_gg <- ggplot(panel_b_data,
                         aes(year, Estimate, colour = Type, group = Type)) +
  geom_hline(yintercept = 0, linewidth = 0.4, linetype = "dashed",
             colour = "grey35") +
  geom_errorbar(
    aes(ymin = Estimate - Std..Error, ymax = Estimate + Std..Error),
    width = 0.25, linewidth = 0.45, alpha = 0.68
  ) +
  geom_line(linewidth = 0.55, alpha = 0.78) +
  geom_point(size = 1.5) +
  scale_colour_manual(values = b_colours, drop = FALSE) +
  scale_x_continuous(breaks = scales::breaks_pretty(n = 5),
                     expand = expansion(mult = c(0.035, 0.035))) +
  scale_y_continuous(expand = expansion(mult = c(0.07, 0.10))) +
  labs(
    tag = "(b)", x = "Release year of variety",
    y = expression(beta[HDW]~"("*kg~ha^-1~hour^-1*")"), colour = NULL
  ) +
  guides(colour = guide_legend(nrow = 1, byrow = TRUE,
                               override.aes = list(linewidth = 0.7))) +
  theme_bw(base_family = "sans", base_size = 7.5) +
  theme(
    plot.tag = element_text(size = 9, face = "bold"),
    plot.tag.position = c(0.01, 1),
    axis.title = element_text(size = 8),
    axis.title.x = element_text(margin = margin(t = 3)),
    axis.title.y = element_text(margin = margin(r = 3)),
    axis.text = element_text(size = 7),
    panel.grid.minor = element_blank(),
    panel.grid.major = element_line(colour = "grey92", linewidth = 0.25),
    legend.position = "inside",
    legend.position.inside = c(0.03, 0.98),
    legend.justification = c(0, 1),
    legend.direction = "horizontal",
    legend.key.width = grid::unit(5, "mm"),
    legend.key.height = grid::unit(3, "mm"),
    legend.text = element_text(size = 7),
    legend.spacing.x = grid::unit(1, "mm"),
    legend.background = element_rect(fill = "transparent", colour = NA),
    legend.key = element_rect(fill = "transparent", colour = NA),
    plot.background = element_rect(fill = "transparent", colour = NA),
    plot.margin = margin(4, 2, 2, 2, unit = "mm")
  )

Supplementary_Figure_9 <- cowplot::plot_grid(
  field_sens_change_sum_gg, FHW_ychange_gg,
  nrow = 1, rel_widths = c(1.08, 0.92), align = "h", axis = "tb"
)
Supplementary_Figure_9


filter_manifest <- data.frame(
  panel = c("a", "b"),
  input_rows = c(nrow(summarized_df_filtered), nrow(FHW_ychange_gg_df)),
  plotted_rows = c(nrow(panel_a_data), nrow(panel_b_data)),
  filter = c("varbs != DTWD; Y_levle != County", "Type != DryWind; model == TSCD"),
  stringsAsFactors = FALSE)
if (!identical(Sys.getenv("HDW_SKIP_EXPORT"), "1")) export_bundle(
  Supplementary_Figure_9,
  list(panel_a = panel_a_data, panel_b = panel_b_data, filter_manifest = filter_manifest),
  "Supplementary_Figure_9", 14.8, 8.3
)
export_six(Supplementary_Figure_9, "Supplementary_Figure_9", 14.8, 8.3)
