# Supplementary Figure 2 -------------------------------------------------------------
# Direct Excel-based reproduction. This file does not source any other R script.
library(readxl)
ROOT = "F:/Post PHD documents/Crop yield loss at DHW/Submission/NF_proof_2026_09_01/Upload_Ready"
FIGURE_OUTPUT_DIR = file.path(ROOT, "Figures")
AMAP_DIR = "D:/Crop yield loss at DHW/amap"
FIGURE_FONT = "sans"
NF_LEGEND_TEXT_PT = 6.6; NF_LEGEND_TITLE_PT = 7.8
TIFF_DPI = 600; PNG_DPI = 450
MAP_YLIM = c(3200000, 6024402)
INSET_LEFT = 0.170; INSET_RIGHT = 0.006; INSET_BOTTOM = 0.018
BASEMAP_TOLERANCE_M = 10000
dir.create(FIGURE_OUTPUT_DIR, recursive = TRUE, showWarnings = FALSE)
check_packages = function(x) {
  miss = x[!vapply(x, requireNamespace, logical(1), quietly = TRUE)]
  if (length(miss)) stop("Install required package(s): ", paste(miss, collapse = ", "))
}
check_packages(c("svglite", "ragg", "devEMF"))
if (requireNamespace("cowplot", quietly = TRUE)) cowplot::set_null_device("agg")
save_device = function(plot, device, file, ...) {
  device(file, ...); id = dev.cur(); on.exit(if (id %in% dev.list()) dev.off(id), add = TRUE)
  print(plot); invisible(file)
}
export_six = function(plot, name, width_cm, height_cm) {
  prefix = file.path(FIGURE_OUTPUT_DIR, name); w = width_cm / 2.54; h = height_cm / 2.54
  save_device(plot, function(file, ...) cairo_pdf(filename = file, ...), paste0(prefix, ".pdf"),
    width = w, height = h, family = FIGURE_FONT, bg = "transparent")
  save_device(plot, svglite::svglite, paste0(prefix, ".svg"), width = w, height = h, bg = "transparent")
  save_device(plot, svg, paste0(prefix, "_word_compatible.svg"), width = w, height = h,
    family = "sans", pointsize = 11, bg = "transparent", onefile = TRUE)
  save_device(plot, devEMF::emf, paste0(prefix, ".emf"), width = w, height = h,
    family = "sans", pointsize = 11, coordDPI = 600, emfPlus = TRUE)
  save_device(plot, ragg::agg_tiff, paste0(prefix, ".tiff"), width = width_cm, height = height_cm,
    units = "cm", res = TIFF_DPI, compression = "lzw", background = "white")
  save_device(plot, ragg::agg_png, paste0(prefix, ".png"), width = width_cm, height = height_cm,
    units = "cm", res = PNG_DPI, background = "white")
}
export_bundle = function(plot, data, name, width_cm, height_cm) export_six(plot, name, width_cm, height_cm)
map_source_manifest = function(...) data.frame()
join_excel = function(geometry, values, keys, columns) {
  for (k in keys) { geometry[[k]] = as.character(geometry[[k]]); values[[k]] = as.character(values[[k]]) }
  gkey = do.call(paste, c(sf::st_drop_geometry(geometry)[keys], sep = "
"))
  vkey = do.call(paste, c(values[keys], sep = "
")); idx = match(gkey, vkey)
  if (anyNA(idx)) stop("Geometry cannot be matched to Excel for key: ", paste(keys, collapse = ", "))
  for (to in names(columns)) geometry[[to]] = values[[columns[[to]]]][idx]
  geometry
}

library(sf)
x = as.data.frame(read_excel(file.path(ROOT,"Supplementary_Figure_2_source_data.xlsx"),sheet="Supplementary Figure 2"))
x[["Frequency (%)"]] = suppressWarnings(as.numeric(x[["Frequency (%)"]]))
g = st_read(file.path(ROOT,"Supplementary_Figure_2_geometry.gpkg"),layer="frequency_map",quiet=TRUE)
CMFD_freqs_means_period_sf = join_excel(g,x,c("site","Type","Period"),c(freq_percent="Frequency (%)"))
CMFD_freqs_means_period_sf$freq_years = CMFD_freqs_means_period_sf$freq_percent/100

# Supplementary Figure 2: HDW frequency by period and type -------------------

pkgs <- c("ggplot2", "sf", "RColorBrewer", "scales", "svglite", "ragg")
miss <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
if (length(miss)) stop("Install: ", paste(miss, collapse = ", "), call. = FALSE)
library(ggplot2); library(sf); library(grid)

if (!exists("CMFD_freqs_means_period_sf", inherits = TRUE))
  stop("CMFD_freqs_means_period_sf is missing.", call. = FALSE)
need <- c("freq_years", "Period", "Type")
miss <- setdiff(need, names(CMFD_freqs_means_period_sf))
if (length(miss)) stop("Missing column(s): ", paste(miss, collapse = ", "), call. = FALSE)

# Data and Figure 3 map range ------------------------------------------------------------
d <- CMFD_freqs_means_period_sf
source_crs <- st_crs(d)
if (!inherits(d, "sf") || is.na(source_crs))
  stop("The data must be an sf object with a valid CRS.", call. = FALSE)
map_crs <- st_crs(paste(
  "+proj=aea +lat_1=25 +lat_2=47 +lat_0=0 +lon_0=105",
  "+datum=WGS84 +units=m +no_defs"
))
effects <- st_transform(d, map_crs)
effects$freq_percent <- effects$freq_years * 100

amap <- AMAP_DIR
country_file <- file.path(amap, "land", "100000.geojson")
maritime_file <- file.path(amap, "maritime", "100000.geojson")
province_dir <- file.path(amap, "province_land")
province_files <- sort(list.files(province_dir, pattern = "[.]geojson$", full.names = TRUE))
if (!file.exists(country_file) || !file.exists(maritime_file) || !length(province_files))
  stop("The AMap basemap files are incomplete.", call. = FALSE)

read_geom <- function(f) {
  x <- st_transform(st_read(f, quiet = TRUE), 4326)
  st_sf(geometry = st_geometry(x))
}
map_line <- function(x) {
  if (any(grepl("POLYGON", as.character(st_geometry_type(x)))))
    st_geometry(x) <- st_boundary(st_geometry(x))
  x
}
project_map <- function(x) {
  x <- st_transform(x, map_crs)
  x <- suppressWarnings(st_simplify(x, 10000, preserveTopology = TRUE))
  x[!st_is_empty(x), , drop = FALSE]
}

country_wgs84 <- read_geom(country_file)
province_wgs84 <- do.call(rbind, lapply(province_files, read_geom))
maritime_wgs84 <- read_geom(maritime_file)
anhui_wgs84 <- read_geom(file.path(province_dir, "340000.geojson"))
country_line <- project_map(map_line(country_wgs84))
province_line <- project_map(map_line(province_wgs84))
maritime <- project_map(map_line(maritime_wgs84))

main_box_ll <- st_bbox(c(xmin = 75.5, ymin = 29, xmax = 133.5, ymax = 52.8),
                       crs = st_crs(4326))
main_box <- st_bbox(st_transform(st_as_sfc(main_box_ll), map_crs))
main_xlim <- unname(main_box[c("xmin", "xmax")])
main_ylim <- MAP_YLIM
main_ylim[1] <- min(main_ylim[1],
  unname(st_bbox(st_transform(anhui_wgs84, map_crs))["ymin"]) - 30000)

south_cut <- unname(st_bbox(anhui_wgs84)["ymin"])
south_box <- st_bbox(c(xmin = 73, ymin = 3, xmax = 135, ymax = south_cut),
                      crs = st_crs(4326))
crop_south <- function(x) {
  g <- st_geometry(map_line(x)); st_crs(g) <- NA
  g <- suppressWarnings(st_crop(g, unclass(south_box)))
  g <- suppressWarnings(st_collection_extract(g, "LINESTRING")); st_crs(g) <- 4326
  project_map(st_sf(geometry = g))
}
country_south <- crop_south(country_wgs84)
province_south <- crop_south(province_wgs84)
maritime_south <- crop_south(maritime_wgs84)
south <- list(country_south, province_south, maritime_south)
if (any(vapply(south, nrow, integer(1)) == 0L))
  stop("A southern inset layer is empty.", call. = FALSE)

source_bbox <- st_bbox(do.call(rbind, south))
pw <- diff(main_xlim); ph <- diff(main_ylim)
inset_xmin <- main_xlim[2] - INSET_LEFT * pw
inset_xmax <- main_xlim[2] - INSET_RIGHT * pw
inset_ymin <- main_ylim[1] + INSET_BOTTOM * ph
inset_scale <- (inset_xmax - inset_xmin) /
  unname(source_bbox["xmax"] - source_bbox["xmin"])
inset_ymax <- inset_ymin + inset_scale *
  unname(source_bbox["ymax"] - source_bbox["ymin"])
target_bbox <- c(xmin = inset_xmin, ymin = inset_ymin,
                  xmax = inset_xmax, ymax = inset_ymax)

move_bbox <- function(x, from, to) {
  old_mid <- c(mean(from[c("xmin", "xmax")]), mean(from[c("ymin", "ymax")]))
  new_mid <- c(mean(to[c("xmin", "xmax")]), mean(to[c("ymin", "ymax")]))
  k <- (to["xmax"] - to["xmin"]) / (from["xmax"] - from["xmin"])
  g <- (st_geometry(x) - old_mid) * k + new_mid
  st_geometry(x) <- st_set_crs(g, map_crs)
  x
}
inset <- lapply(south, move_bbox, from = source_bbox, to = target_bbox)
inset_frame <- st_as_sf(st_as_sfc(st_bbox(target_bbox, crs = map_crs)))

# Plot ---------------------------------------------------------------
line_layer <- function(x, colour, width) geom_sf(
  data = x, fill = NA, colour = colour, linewidth = width,
  inherit.aes = FALSE, show.legend = FALSE
)

breaks <- seq(0, 100, 10)
colours <- colorRampPalette(RColorBrewer::brewer.pal(9, "BuPu"))(length(breaks))

Supplementary_Figure_2 <- ggplot() +
  geom_sf(data = effects, aes(fill = freq_percent), colour = NA, linewidth = 0) +
  line_layer(province_line, "grey55", 0.10) +
  line_layer(country_line, "grey45", 0.18) +
  line_layer(inset[[2]], "grey55", 0.08) +
  line_layer(inset[[1]], "grey45", 0.16) +
  line_layer(inset[[3]], "grey45", 0.14) +
  line_layer(inset_frame, "grey45", 0.20) +
  scale_fill_stepsn(
    colours = colours, breaks = breaks, limits = c(0, 100),
    values = scales::rescale(breaks), na.value = "white", name = "Frequency (%)",
    guide = guide_colorsteps(
      direction = "horizontal", title.position = "left", title.hjust = 1,
      label.position = "bottom", barwidth = unit(8, "cm"),
      barheight = unit(0.24, "cm"), ticks = TRUE, even.steps = TRUE
    )
  ) +
  labs(subtitle = bquote(HDW[HD-MT]~frequency)) +
  facet_grid(Period ~ Type, labeller = labeller(
    Type = function(x) gsub("PRWD", "PRGW", x, fixed = TRUE)
  )) +
  coord_sf(crs = map_crs, xlim = main_xlim, ylim = main_ylim, expand = FALSE,
           clip = "on", datum = st_crs(4326)) +
  theme_bw(base_family = "sans", base_size = 8) +
  theme(
    plot.subtitle = element_text(size = 9, hjust = 0.015, vjust = 1.3),
    strip.text = element_text(size = 8),
    strip.background = element_rect(fill = "grey85", colour = NA),
    axis.title = element_blank(), axis.ticks = element_blank(), axis.text = element_blank(),
    panel.grid.major = element_line(colour = "grey90", linewidth = 0.30),
    panel.grid.minor = element_blank(),
    panel.spacing.x = unit(1.4, "mm"), panel.spacing.y = unit(2.8, "mm"),
    legend.position = "inside", legend.position.inside = c(0.68, 1.115),
    legend.justification = c(0.5, 0.5), legend.direction = "horizontal",
    legend.background = element_blank(), legend.text = element_text(size = 6.2),
    legend.title = element_text(size = 6.5, margin = margin(r = 3)),
    legend.margin = margin(0, 0, 0, 0), legend.box.spacing = unit(0, "mm"),
    plot.background = element_rect(fill = "transparent", colour = NA),
    plot.margin = margin(0.8, 0.5, 0.5, 0.5, unit = "mm")
  )

Supplementary_Figure_2


map_manifest <- map_source_manifest(
  country_file, province_files, maritime_file, main_xlim, main_ylim, target_bbox
)
geometry_manifest <- data.frame(
  dataset = "frequency_by_period", input_rows = nrow(CMFD_freqs_means_period_sf),
  plotted_rows = nrow(effects), plotting_simplification_m = 6000,
  values_or_rows_filtered = FALSE
)
if (!identical(Sys.getenv("HDW_SKIP_EXPORT"), "1")) export_bundle(
  Supplementary_Figure_2,
  list(frequency_map = effects, geometry_manifest = geometry_manifest,
       map_manifest = map_manifest),
  "Supplementary_Figure_2", 15, 9.2
)
export_six(Supplementary_Figure_2, "Supplementary_Figure_2", 15, 9.2)