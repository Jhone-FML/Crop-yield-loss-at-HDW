# Supplementary Figure 8 -------------------------------------------------------------
# Direct Excel-based reproduction. This file does not source any other R script.
library(readxl)
ROOT = "F:/Post PHD documents/Crop yield loss at DHW/Submission/NF_proof_2026_09_01/Upload_Ready"
FIGURE_OUTPUT_DIR = file.path(ROOT, "Figures")
AMAP_DIR = "D:/Crop yield loss at DHW/amap"
FIGURE_FONT = "sans"
NF_LEGEND_TEXT_PT = 6.6; NF_LEGEND_TITLE_PT = 7.8
TIFF_DPI = 600; PNG_DPI = 450
MAP_YLIM = c(3200000, 6024402)
INSET_LEFT = 0.170; INSET_RIGHT = 0.006; INSET_BOTTOM = 0.018
BASEMAP_TOLERANCE_M = 10000
dir.create(FIGURE_OUTPUT_DIR, recursive = TRUE, showWarnings = FALSE)
check_packages = function(x) {
  miss = x[!vapply(x, requireNamespace, logical(1), quietly = TRUE)]
  if (length(miss)) stop("Install required package(s): ", paste(miss, collapse = ", "))
}
check_packages(c("svglite", "ragg", "devEMF"))
if (requireNamespace("cowplot", quietly = TRUE)) cowplot::set_null_device("agg")
save_device = function(plot, device, file, ...) {
  device(file, ...); id = dev.cur(); on.exit(if (id %in% dev.list()) dev.off(id), add = TRUE)
  print(plot); invisible(file)
}
export_six = function(plot, name, width_cm, height_cm) {
  prefix = file.path(FIGURE_OUTPUT_DIR, name); w = width_cm / 2.54; h = height_cm / 2.54
  save_device(plot, function(file, ...) cairo_pdf(filename = file, ...), paste0(prefix, ".pdf"),
    width = w, height = h, family = FIGURE_FONT, bg = "transparent")
  save_device(plot, svglite::svglite, paste0(prefix, ".svg"), width = w, height = h, bg = "transparent")
  save_device(plot, svg, paste0(prefix, "_word_compatible.svg"), width = w, height = h,
    family = "sans", pointsize = 11, bg = "transparent", onefile = TRUE)
  save_device(plot, devEMF::emf, paste0(prefix, ".emf"), width = w, height = h,
    family = "sans", pointsize = 11, coordDPI = 600, emfPlus = TRUE)
  save_device(plot, ragg::agg_tiff, paste0(prefix, ".tiff"), width = width_cm, height = height_cm,
    units = "cm", res = TIFF_DPI, compression = "lzw", background = "white")
  save_device(plot, ragg::agg_png, paste0(prefix, ".png"), width = width_cm, height = height_cm,
    units = "cm", res = PNG_DPI, background = "white")
}
export_bundle = function(plot, data, name, width_cm, height_cm) export_six(plot, name, width_cm, height_cm)
map_source_manifest = function(...) data.frame()
join_excel = function(geometry, values, keys, columns) {
  for (k in keys) { geometry[[k]] = as.character(geometry[[k]]); values[[k]] = as.character(values[[k]]) }
  gkey = do.call(paste, c(sf::st_drop_geometry(geometry)[keys], sep = "
"))
  vkey = do.call(paste, c(values[keys], sep = "
")); idx = match(gkey, vkey)
  if (anyNA(idx)) stop("Geometry cannot be matched to Excel for key: ", paste(keys, collapse = ", "))
  for (to in names(columns)) geometry[[to]] = values[[columns[[to]]]][idx]
  geometry
}

library(ggplot2)
Sens_fit_df_dhw_filtered = as.data.frame(read_excel(file.path(ROOT,"Supplementary_Figure_8_source_data.xlsx"),sheet="Supplementary Figure 8"))

# Supplementary Figure 8
required_packages <- c(
  "ggplot2", "ggdist", "RColorBrewer", "dplyr", "stringr",
  "svglite", "ragg"
)
missing_packages <- required_packages[!vapply(
  required_packages, requireNamespace, logical(1), quietly = TRUE
)]
if (length(missing_packages) > 0) {
  stop(
    "Install the required package(s): ", paste(missing_packages, collapse = ", "),
    "\nRun: install.packages(c(",
    paste(sprintf('"%s"', missing_packages), collapse = ", "), "))",
    call. = FALSE
  )
}

if (!exists("Sens_fit_df_dhw_filtered", inherits = TRUE)) {
  stop("Sens_fit_df_dhw_filtered is missing.", call. = FALSE)
}
required_columns <- c("Breeding", "cols", "value", "fact")
missing_columns <- setdiff(required_columns, names(Sens_fit_df_dhw_filtered))
if (length(missing_columns) > 0) {
  stop(
    "Sens_fit_df_dhw_filtered is missing: ",
    paste(missing_columns, collapse = ", "),
    call. = FALSE
  )
}
if (!is.numeric(Sens_fit_df_dhw_filtered$value)) {
  stop("Sens_fit_df_dhw_filtered$value must be numeric.", call. = FALSE)
}

plot_data <- Sens_fit_df_dhw_filtered |>
  dplyr::filter(Breeding == "No") |>
  dplyr::filter(!stringr::str_detect(cols, "DTWD"))
if (nrow(plot_data) == 0) {
  stop("No observations remain after Breeding == 'No' and DTWD exclusion.", call. = FALSE)
}

x_levels <- c(
  "HTLH_Early", "HTLH_Middle", "HTLH_Late",
  "PRGW_Early", "PRGW_Middle", "PRGW_Late"
)
set2 <- RColorBrewer::brewer.pal(8, "Set2")
dhw_colours <- c(set2[1], set2[1], set2[1], set2[2], set2[2], set2[2])
x_labels <- c(
  "HTLH_Early" = "HTLH-E",
  "HTLH_Middle" = "HTLH-M",
  "HTLH_Late" = "HTLH-L",
  "PRGW_Early" = "PRGW-E",
  "PRGW_Middle" = "PRGW-M",
  "PRGW_Late" = "PRGW-L"
)

figure_font <- "sans"

Supplementary_Figure_8_gg <- ggplot2::ggplot(
  plot_data,
  ggplot2::aes(x = cols, y = value)
) +
  ggdist::stat_halfeye(
    ggplot2::aes(fill = cols),
    adjust = 0.6,
    width = 1,
    .width = 0,
    alpha = 0.6,
    justification = -0.10,
    point_colour = NA
  ) +
  ggdist::stat_pointinterval(
    ggplot2::aes(colour = cols),
    size = 1.5,
    position = ggplot2::position_dodge(width = 0.7, preserve = "single")
  ) +
  ggplot2::geom_hline(
    yintercept = 0,
    linewidth = 0.5,
    linetype = "dashed",
    colour = "black"
  ) +
  ggplot2::stat_summary(
    ggplot2::aes(label = after_stat(round(y, 1)), colour = cols),
    fun = mean,
    geom = "text",
    hjust = -0.12,
    vjust = 1.35,
    size = 3,
    show.legend = FALSE
  ) +
  ggplot2::scale_colour_manual(name = NULL, values = dhw_colours) +
  ggplot2::scale_fill_manual(name = NULL, values = dhw_colours) +
  ggplot2::scale_x_discrete(
    limits = x_levels,
    labels = x_labels
  ) +
  ggplot2::facet_wrap(~fact, scales = "free", ncol = 2) +
  ggplot2::labs(
    x = "Types of HDW across three phases in HD-MT",
    y = "Changes in yield sensitivity to DHW\u00A0\u00A0(kg ha\u207B\u00B9 hour\u207B\u00B9)"
  ) +
  ggplot2::coord_cartesian(clip = "off") +
  ggplot2::theme_bw(base_family = figure_font, base_size = 9) +
  ggplot2::theme(
    strip.text = ggplot2::element_text(size = 9),
    strip.background = ggplot2::element_rect(fill = "grey85", colour = NA),
    axis.text.x = ggplot2::element_text(
      size = 8,
      angle = 45,
      hjust = 1,
      vjust = 1
    ),
    axis.text.y = ggplot2::element_text(size = 8),
    axis.title.x = ggplot2::element_text(size = 9.5, margin = ggplot2::margin(t = 5)),
    axis.title.y = ggplot2::element_text(
      size = 9.5,
      margin = ggplot2::margin(r = 8)
    ),
    legend.position = "none",
    panel.spacing.x = grid::unit(0.55, "cm"),
    panel.spacing.y = grid::unit(0.45, "cm"),
    plot.margin = ggplot2::margin(5, 7, 5, 8, unit = "mm"),
    plot.background = ggplot2::element_rect(fill = "transparent", colour = NA)
  )



filter_manifest <- data.frame(
  input_rows = nrow(Sens_fit_df_dhw_filtered), plotted_rows = nrow(plot_data),
  rule = "Breeding == No and cols does not contain DTWD", stringsAsFactors = FALSE)
mean_check <- stats::aggregate(value ~ fact + cols, data = plot_data, FUN = mean)
if (!identical(Sys.getenv("HDW_SKIP_EXPORT"), "1")) export_bundle(
  Supplementary_Figure_8_gg,
  list(plot_data = plot_data, mean_check = mean_check, filter_manifest = filter_manifest),
  "Supplementary_Figure_8", 14.8, 18
)
export_six(Supplementary_Figure_8_gg, "Supplementary_Figure_8", 14.8, 18)

