# Supplementary Figure 4 -------------------------------------------------------------
# Direct Excel-based reproduction. This file does not source any other R script.
library(readxl)
ROOT = "F:/Post PHD documents/Crop yield loss at DHW/Submission/NF_proof_2026_09_01/Upload_Ready"
FIGURE_OUTPUT_DIR = file.path(ROOT, "Figures")
AMAP_DIR = "D:/Crop yield loss at DHW/amap"
FIGURE_FONT = "sans"
NF_LEGEND_TEXT_PT = 6.6; NF_LEGEND_TITLE_PT = 7.8
TIFF_DPI = 600; PNG_DPI = 450
MAP_YLIM = c(3200000, 6024402)
INSET_LEFT = 0.170; INSET_RIGHT = 0.006; INSET_BOTTOM = 0.018
BASEMAP_TOLERANCE_M = 10000
dir.create(FIGURE_OUTPUT_DIR, recursive = TRUE, showWarnings = FALSE)
check_packages = function(x) {
  miss = x[!vapply(x, requireNamespace, logical(1), quietly = TRUE)]
  if (length(miss)) stop("Install required package(s): ", paste(miss, collapse = ", "))
}
check_packages(c("svglite", "ragg", "devEMF"))
if (requireNamespace("cowplot", quietly = TRUE)) cowplot::set_null_device("agg")
save_device = function(plot, device, file, ...) {
  device(file, ...); id = dev.cur(); on.exit(if (id %in% dev.list()) dev.off(id), add = TRUE)
  print(plot); invisible(file)
}
export_six = function(plot, name, width_cm, height_cm) {
  prefix = file.path(FIGURE_OUTPUT_DIR, name); w = width_cm / 2.54; h = height_cm / 2.54
  save_device(plot, function(file, ...) cairo_pdf(filename = file, ...), paste0(prefix, ".pdf"),
    width = w, height = h, family = FIGURE_FONT, bg = "transparent")
  save_device(plot, svglite::svglite, paste0(prefix, ".svg"), width = w, height = h, bg = "transparent")
  save_device(plot, svg, paste0(prefix, "_word_compatible.svg"), width = w, height = h,
    family = "sans", pointsize = 11, bg = "transparent", onefile = TRUE)
  save_device(plot, devEMF::emf, paste0(prefix, ".emf"), width = w, height = h,
    family = "sans", pointsize = 11, coordDPI = 600, emfPlus = TRUE)
  save_device(plot, ragg::agg_tiff, paste0(prefix, ".tiff"), width = width_cm, height = height_cm,
    units = "cm", res = TIFF_DPI, compression = "lzw", background = "white")
  save_device(plot, ragg::agg_png, paste0(prefix, ".png"), width = width_cm, height = height_cm,
    units = "cm", res = PNG_DPI, background = "white")
}
export_bundle = function(plot, data, name, width_cm, height_cm) export_six(plot, name, width_cm, height_cm)
map_source_manifest = function(...) data.frame()
join_excel = function(geometry, values, keys, columns) {
  for (k in keys) { geometry[[k]] = as.character(geometry[[k]]); values[[k]] = as.character(values[[k]]) }
  gkey = do.call(paste, c(sf::st_drop_geometry(geometry)[keys], sep = "
"))
  vkey = do.call(paste, c(values[keys], sep = "
")); idx = match(gkey, vkey)
  if (anyNA(idx)) stop("Geometry cannot be matched to Excel for key: ", paste(keys, collapse = ", "))
  for (to in names(columns)) geometry[[to]] = values[[columns[[to]]]][idx]
  geometry
}

library(dplyr)
library(tidyr)
library(ggplot2)
library(ggridges)
x = as.data.frame(read_excel(file.path(ROOT,"Supplementary_Figure_4_source_data.xlsx"),sheet="Supplementary Figure 4"))
df_long = x |> tidyr::pivot_longer(c("HDW occurrence (doy)","Jointing (doy)","Heading (doy)","Maturity (doy)"),names_to="Variable",values_to="Days") |>
  dplyr::mutate(Variable=dplyr::recode(Variable,"HDW occurrence (doy)"="HDW occurrence","Jointing (doy)"="JT","Heading (doy)"="HD","Maturity (doy)"="MT"),
    wtype=dplyr::case_when(Variable %in% c("MT","HDW occurrence","HD") & Days<150 ~ "Spring wheat",Variable=="JT" & Days<100 ~ "Spring wheat",TRUE ~ "Winter wheat"),
    Type_label=dplyr::case_when(Type=="HighTempLowHumidity" ~ "HDW[HTLH]",Type %in% c("PostRainScorch","PostRainWilt") ~ "HDW[PRGW]",Type=="DryWind" ~ "HDW[DTWD]"),
    Variable=factor(Variable,levels=c("HDW occurrence","JT","HD","MT")),Type_label=factor(Type_label,levels=c("HDW[HTLH]","HDW[PRGW]","HDW[DTWD]")),
    wtype=factor(wtype,levels=c("Spring wheat","Winter wheat")),group=factor(group,levels=c("1981-2008","2009-2018")))
median_df = df_long |> dplyr::group_by(Type_label,Variable,group,wtype) |> dplyr::summarise(value=median(Days,na.rm=TRUE),.groups="drop") |>
  dplyr::mutate(x_pos=dplyr::case_when(wtype=="Spring wheat" & group=="1981-2008"~140,wtype=="Spring wheat" & group=="2009-2018"~40,wtype=="Winter wheat" & group=="1981-2008"~280,TRUE~150),hjust=ifelse(group=="1981-2008",0,1))

my_cols <- c("1981-2008" = "#1b9e77", "2009-2018" = "#e55f09")
ridge_scale <- 0.7
figure_font <- "sans"

Supplementary_Figure_4_gg <- ggplot2::ggplot(
  df_long,
  ggplot2::aes(
    x = Days,
    y = factor(Variable, levels = rev(levels(Variable))),
    fill = group,
    colour = group
  )
) +
  ggridges::geom_density_ridges(
    alpha = 0.4,
    scale = ridge_scale,
    quantile_lines = TRUE,
    quantiles = 2,
    linewidth = 0.45
  ) +
  ggplot2::geom_text(
    data = median_df,
    ggplot2::aes(
      x = x_pos,
      y = as.numeric(factor(Variable, levels = rev(levels(df_long$Variable)))) + 0.30,
      label = value,
      colour = group,
      hjust = hjust
    ),
    inherit.aes = FALSE,
    size = 2.8,
    show.legend = FALSE
  ) +
  ggplot2::facet_grid(
    Type_label ~ wtype,
    scales = "free",
    labeller = ggplot2::labeller(Type_label = ggplot2::label_parsed)
  ) +
  ggplot2::scale_fill_manual(values = my_cols, name = NULL) +
  ggplot2::scale_colour_manual(values = my_cols, name = NULL) +
  ggplot2::guides(
    fill = ggplot2::guide_legend(nrow = 1, byrow = TRUE),
    colour = ggplot2::guide_legend(nrow = 1, byrow = TRUE)
  ) +
  ggplot2::labs(x = "Day after planting (days)", y = NULL) +
  ggplot2::theme_bw(base_family = figure_font, base_size = 9) +
  ggplot2::theme(
    strip.text = ggplot2::element_text(size = 9),
    strip.background = ggplot2::element_rect(fill = "grey85", colour = NA),
    axis.text.x = ggplot2::element_text(size = 8.5),
    axis.text.y = ggplot2::element_text(size = 8.5),
    axis.title.x = ggplot2::element_text(size = 10, margin = ggplot2::margin(t = 5)),
    legend.position = "bottom",
    legend.justification = "center",
    legend.direction = "horizontal",
    legend.key.height = grid::unit(0.25, "cm"),
    legend.key.width = grid::unit(0.45, "cm"),
    legend.margin = ggplot2::margin(t = 1, r = 0, b = 0, l = 0, unit = "mm"),
    legend.background = ggplot2::element_blank(),
    legend.text = ggplot2::element_text(size = 9),
    panel.spacing = grid::unit(0.35, "cm"),
    plot.margin = ggplot2::margin(4, 5, 4, 5, unit = "mm"),
    plot.background = ggplot2::element_rect(fill = "transparent", colour = NA)
  )



export_six(Supplementary_Figure_4_gg,"Supplementary_Figure_4",18,14)
