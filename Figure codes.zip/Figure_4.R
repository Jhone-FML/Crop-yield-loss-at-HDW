# Figure 4 -------------------------------------------------------------
# Direct Excel-based reproduction. This file does not source any other R script.
library(readxl)
ROOT = "F:/Post PHD documents/Crop yield loss at DHW/Submission/NF_proof_2026_09_01/Upload_Ready"
FIGURE_OUTPUT_DIR = file.path(ROOT, "Figures")
AMAP_DIR = "D:/Crop yield loss at DHW/amap"
FIGURE_FONT = "sans"
NF_LEGEND_TEXT_PT = 6.2; NF_LEGEND_TITLE_PT = 7.0
TIFF_DPI = 600; PNG_DPI = 450
MAP_YLIM = c(3200000, 6024402)
INSET_LEFT = 0.170; INSET_RIGHT = 0.006; INSET_BOTTOM = 0.018
BASEMAP_TOLERANCE_M = 10000
dir.create(FIGURE_OUTPUT_DIR, recursive = TRUE, showWarnings = FALSE)
check_packages = function(x) {
  miss = x[!vapply(x, requireNamespace, logical(1), quietly = TRUE)]
  if (length(miss)) stop("Install required package(s): ", paste(miss, collapse = ", "))
}
check_packages(c("svglite", "ragg", "devEMF"))
if (requireNamespace("cowplot", quietly = TRUE)) cowplot::set_null_device("agg")
save_device = function(plot, device, file, ...) {
  device(file, ...); id = dev.cur(); on.exit(if (id %in% dev.list()) dev.off(id), add = TRUE)
  print(plot); invisible(file)
}
export_six = function(plot, name, width_cm, height_cm) {
  prefix = file.path(FIGURE_OUTPUT_DIR, name); w = width_cm / 2.54; h = height_cm / 2.54
  save_device(plot, function(file, ...) cairo_pdf(filename = file, ...), paste0(prefix, ".pdf"),
    width = w, height = h, family = FIGURE_FONT, bg = "transparent")
  save_device(plot, svglite::svglite, paste0(prefix, ".svg"), width = w, height = h, bg = "transparent")
  save_device(plot, svg, paste0(prefix, "_word_compatible.svg"), width = w, height = h,
    family = "sans", pointsize = 11, bg = "transparent", onefile = TRUE)
  save_device(plot, devEMF::emf, paste0(prefix, ".emf"), width = w, height = h,
    family = "sans", pointsize = 11, coordDPI = 600, emfPlus = TRUE)
  save_device(plot, ragg::agg_tiff, paste0(prefix, ".tiff"), width = width_cm, height = height_cm,
    units = "cm", res = TIFF_DPI, compression = "lzw", background = "white")
  save_device(plot, ragg::agg_png, paste0(prefix, ".png"), width = width_cm, height = height_cm,
    units = "cm", res = PNG_DPI, background = "white")
}
export_bundle = function(plot, data, name, width_cm, height_cm) export_six(plot, name, width_cm, height_cm)
map_source_manifest = function(...) data.frame()
join_excel = function(geometry, values, keys, columns) {
  for (k in keys) { geometry[[k]] = as.character(geometry[[k]]); values[[k]] = as.character(values[[k]]) }
  gkey = do.call(paste, c(sf::st_drop_geometry(geometry)[keys], sep = "
"))
  vkey = do.call(paste, c(values[keys], sep = "
")); idx = match(gkey, vkey)
  if (anyNA(idx)) stop("Geometry cannot be matched to Excel for key: ", paste(keys, collapse = ", "))
  for (to in names(columns)) geometry[[to]] = values[[columns[[to]]]][idx]
  geometry
}

# Latest AMap north map and compact south inset.
prepare_latest_amap = local({ cache = NULL; function(amap_dir = AMAP_DIR) {
  if (!is.null(cache) && identical(cache$amap_dir, amap_dir)) return(cache)
  crs = sf::st_crs(paste("+proj=aea +lat_1=25 +lat_2=47 +lat_0=0 +lon_0=105",
    "+datum=WGS84 +units=m +no_defs"))
  files = c(country = file.path(amap_dir,"land","100000.geojson"),
    maritime = file.path(amap_dir,"maritime","100000.geojson"),
    anhui = file.path(amap_dir,"province_land","340000.geojson"))
  province_files = sort(list.files(file.path(amap_dir,"province_land"), "[.]geojson$", full.names=TRUE))
  read_geometry = function(p) sf::st_sf(geometry=sf::st_geometry(sf::st_transform(sf::st_read(p,quiet=TRUE),4326)))
  country=read_geometry(files["country"]); maritime=read_geometry(files["maritime"]); anhui=read_geometry(files["anhui"])
  province=do.call(rbind,lapply(province_files,read_geometry)); south_cut=unname(sf::st_bbox(anhui)["ymin"])
  as_lines=function(x){if(any(grepl("POLYGON",as.character(sf::st_geometry_type(x))))) sf::st_geometry(x)=sf::st_boundary(sf::st_geometry(x)); x}
  project=function(x){x=sf::st_transform(x,crs); x=suppressWarnings(sf::st_simplify(x,BASEMAP_TOLERANCE_M,preserveTopology=TRUE)); x[!sf::st_is_empty(x),]}
  lines=lapply(list(country,province,maritime),as_lines); north=lapply(lines,project)
  main=sf::st_bbox(sf::st_transform(sf::st_as_sfc(sf::st_bbox(c(xmin=75.5,ymin=29,xmax=133.5,ymax=52.8),crs=sf::st_crs(4326))),crs))
  xlim=unname(main[c("xmin","xmax")]); ylim=MAP_YLIM; ylim[1]=min(ylim[1],unname(sf::st_bbox(sf::st_transform(anhui,crs))["ymin"])-30000)
  south_box=sf::st_bbox(c(xmin=73,ymin=3,xmax=135,ymax=south_cut),crs=sf::st_crs(4326))
  crop=function(x){g=sf::st_geometry(x); sf::st_crs(g)=NA; g=suppressWarnings(sf::st_crop(g,unclass(south_box))); g=suppressWarnings(sf::st_collection_extract(g,"LINESTRING")); sf::st_crs(g)=4326; project(sf::st_sf(geometry=g))}
  south=lapply(lines,crop); source=sf::st_bbox(do.call(rbind,south)); pw=diff(xlim); ph=diff(ylim)
  xmin=xlim[2]-INSET_LEFT*pw; xmax=xlim[2]-INSET_RIGHT*pw; ymin=ylim[1]+INSET_BOTTOM*ph
  scale=(xmax-xmin)/unname(source["xmax"]-source["xmin"]); ymax=ymin+scale*unname(source["ymax"]-source["ymin"])
  inset=lapply(south,function(x){g=(sf::st_geometry(x)-unname(source[c("xmin","ymin")]))*scale+c(xmin,ymin); sf::st_sf(geometry=sf::st_set_crs(g,crs))})
  frame=sf::st_as_sf(sf::st_as_sfc(sf::st_bbox(c(xmin=xmin,ymin=ymin,xmax=xmax,ymax=ymax),crs=crs)))
  cache <<- list(amap_dir=amap_dir,crs=crs,xlim=xlim,ylim=ylim,north=north,inset=inset,frame=frame,
    south_cut_lat=south_cut,province_files=province_files,country_file=files["country"],maritime_file=files["maritime"]); cache
}})
latest_amap_layers = function(b) { line=function(x,col,w) ggplot2::geom_sf(data=x,fill=NA,colour=col,linewidth=w,inherit.aes=FALSE,show.legend=FALSE); list(
  line(b$north[[2]],"grey55",.10),line(b$north[[1]],"grey45",.18),line(b$inset[[2]],"grey55",.08),
  line(b$inset[[1]],"grey45",.16),line(b$inset[[3]],"grey45",.14),line(b$frame,"grey45",.20)) }

library(sf)
library(ggplot2)
library(cowplot)
a = as.data.frame(read_excel(file.path(ROOT,"Figure_4_source_data.xlsx"),sheet="Figure 4 a"))
names(a)[names(a)=="Sensitivity change (kg ha-1 hour-1)"] = "value"
county_sensitivity_data = a
b = as.data.frame(read_excel(file.path(ROOT,"Figure_4_source_data.xlsx"),sheet="Figure 4 b"))
b[["Province-specific changes in sensitivity (kg ha-1 hour-1)"]] = suppressWarnings(as.numeric(b[["Province-specific changes in sensitivity (kg ha-1 hour-1)"]]))
b$Type = gsub("PRWD","PRGW",b$Type,fixed=TRUE)
sensitivity_map_plot = st_read(file.path(ROOT,"Figure_4_geometry.gpkg"),layer="panel_b_map",quiet=TRUE)
sensitivity_map_plot$Type = gsub("PRWD","PRGW",as.character(sensitivity_map_plot$Type),fixed=TRUE)
sensitivity_map_plot = join_excel(sensitivity_map_plot,b,c("ENAME","Type"),c(mean_value.y="Province-specific changes in sensitivity (kg ha-1 hour-1)"))
sensitivity_map_plot$Type_display = factor(gsub("PRWD","PRGW",sensitivity_map_plot$Type,fixed=TRUE),levels=c("HTLH","PRGW"))
basemap = prepare_latest_amap()

figure_font_family <- "sans"
font_panel_label <- 9
font_strip <- 7.5
font_axis_text <- 7
font_axis_title <- 8
font_legend <- NF_LEGEND_TEXT_PT

# Display PRWD as PRGW without modifying either source object.
display_prgw <- function(x) {
  gsub("PRWD", "PRGW", as.character(x), fixed = TRUE)
}

# -----------------------------------------------------------------------------
# Panel (a): county-level sensitivity-change distributions
# -----------------------------------------------------------------------------

county_label_source <- county_sensitivity_data[is.finite(county_sensitivity_data$value), , drop = FALSE]
county_label_df <- do.call(rbind, lapply(split(county_label_source, interaction(county_label_source$Model, county_label_source$varbs, drop = TRUE)), function(z) {
  m <- as.character(z$Model[1]); v <- as.character(z$varbs[1])
  yr <- range(county_label_source$value[as.character(county_label_source$Model) == m], na.rm = TRUE); dy <- diff(yr)
  if (!is.finite(dy) || dy == 0) dy <- max(abs(yr), 1, na.rm = TRUE)
  med <- stats::median(z$value, na.rm = TRUE); q975 <- as.numeric(stats::quantile(z$value, 0.975, na.rm = TRUE))
  pos <- if (grepl("PRG|PRW", v, ignore.case = TRUE)) "left_pointinterval" else "top_halfeye"
  data.frame(Model = z$Model[1], varbs = z$varbs[1], label_position = pos,
             y_lab = 75,
             label = formatC(med, format = "f", digits = 1), stringsAsFactors = FALSE)
}))
county_label_space_df <- do.call(rbind, lapply(split(county_label_source, county_label_source$Model, drop = TRUE), function(z) {
  m <- as.character(z$Model[1]); yr <- range(z$value, na.rm = TRUE); dy <- diff(yr)
  if (!is.finite(dy) || dy == 0) dy <- max(abs(yr), 1, na.rm = TRUE)
  data.frame(Model = z$Model[1], varbs = z$varbs[1], y_space = max(yr[2], 82, na.rm = TRUE) + dy * 0.02)
}))
county_label_top_df <- county_label_df[county_label_df$label_position == "top_halfeye", , drop = FALSE]
county_label_left_df <- county_label_df[county_label_df$label_position == "left_pointinterval", , drop = FALSE]
county_sens_change_sum_gg <- ggplot(
  county_sensitivity_data,
  aes(x = varbs, y = value)
) +
  ggdist::stat_halfeye(
    aes(fill = varbs),
    adjust = 0.6,
    width = 0.8,
    .width = 0,
    alpha = 0.6,
    position = position_dodge(width = 1),
    justification = -0.2,
    point_colour = NA
  ) +
  ggdist::stat_pointinterval(
    aes(colour = varbs),
    point_interval = "median_qi", .width = c(0.66, 0.95),
    justification = 0.2,
    size = 0.65,
    position = position_dodge(width = 1),
    alpha = 0.6
  ) +
  geom_hline(
    yintercept = 0,
    linewidth = 0.45,
    linetype = "dashed",
    colour = "black"
  ) +
  geom_blank(data = county_label_space_df, aes(x = varbs, y = y_space), inherit.aes = FALSE) +
  geom_label(data = county_label_top_df,
             aes(x = varbs, y = y_lab, label = label, colour = varbs),
             inherit.aes = FALSE, size = 2.10, hjust = 0.5, vjust = 0.5,
             linewidth = 0.12, fill = "white", label.r = grid::unit(0.10, "lines"),
             label.padding = grid::unit(0.08, "lines"), show.legend = FALSE) +
  geom_label(data = county_label_left_df,
             aes(x = varbs, y = y_lab, label = label, colour = varbs),
             inherit.aes = FALSE, position = position_nudge(x = -0.24),
             size = 2.10, hjust = 1, vjust = 0.5, linewidth = 0.12,
             fill = "white", label.r = grid::unit(0.10, "lines"),
             label.padding = grid::unit(0.08, "lines"), show.legend = FALSE) +
  scale_colour_manual(
    name = NULL,
    values = RColorBrewer::brewer.pal(8, "Set2")
  ) +
  scale_fill_manual(
    name = NULL,
    values = RColorBrewer::brewer.pal(8, "Set2")
  ) +
  scale_x_discrete(
    labels = function(x) display_prgw(x)
  ) +
  facet_wrap(~Model, ncol = 2) +
  labs(
    x = "Types of HDW",
    y = expression(
      "Changes in yield sensitivity to HDW"~(kg~ha^-1~hour^-1)
    ),
    subtitle = "(a)"
  ) +
  theme_bw(base_family = figure_font_family, base_size = font_axis_text) +
  theme(
    plot.subtitle = element_text(
      size = font_panel_label,
      hjust = 0.02,
      vjust = 1.2,
    ),
    strip.text = element_text(size = font_strip),
    axis.text.x = element_text(
      size = font_axis_text,
      angle = 0,
      vjust = 1,
      hjust = 0.5
    ),
    axis.text.y = element_text(size = font_axis_text),
    axis.title = element_text(size = font_axis_title),
    legend.position = "none",
    panel.spacing = grid::unit(0.55, "lines"),
    strip.background = element_rect(colour = "transparent"),
    plot.background = element_rect(fill = "transparent", colour = NA),
    plot.margin = margin(1.5, 1.5, 1.5, 1.5, unit = "mm")
  )

sensity_change_sp_gg <- ggplot() +
  geom_sf(data = sensitivity_map_plot, aes(fill = mean_value.y),
          colour = "transparent", linewidth = 0) +
  scale_fill_stepsn(
    colors = RColorBrewer::brewer.pal(11, "BrBG")[2:10],
    breaks = seq(-40, 40, 10), labels = function(x) format(x, trim = TRUE),
    limits = c(-40, 40), na.value = "white",
    values = scales::rescale(seq(-40, 40, 10)),
    name = expression("Sensitivity change"~(kg~ha^-1~hour^-1)),
    guide = guide_coloursteps(even.steps = TRUE, show.limits = TRUE,
                              theme = theme(legend.title.position = "top"))) +
  latest_amap_layers(basemap) +
  facet_wrap(~Type_display, ncol = 1, drop = FALSE) +
  coord_sf(crs = basemap$crs, xlim = basemap$xlim, ylim = basemap$ylim,
           expand = FALSE, clip = "on", datum = sf::st_crs(4326)) +
  labs(
    y = expression("Changes in yield sensitivity to HDW"~(kg~ha^-1~hour^-1)),
    x = NULL, subtitle = "(b)") +
  theme_bw(base_family = figure_font_family, base_size = font_axis_text) +
  theme(
    plot.subtitle = element_text(size = font_panel_label, hjust = 0.02, vjust = 1.2),
    strip.text = element_text(size = font_strip),
    axis.ticks = element_blank(), axis.text = element_blank(),
    axis.title = element_text(size = font_axis_title),
    legend.position = "bottom", legend.direction = "horizontal",
    legend.key.width = grid::unit(1.0, "cm"),
    legend.key.height = grid::unit(0.18, "cm"),
    legend.text = element_text(size = font_legend, angle = 0, hjust = 0.5, vjust = 1),
    legend.title = element_text(hjust = 0.5,size = NF_LEGEND_TITLE_PT),
    legend.background = element_rect(fill = "transparent", colour = NA),
    panel.grid.major = element_line(colour = "grey90", linewidth = 0.30),
    panel.grid.minor = element_blank(),
    strip.background = element_rect(colour = "transparent"),
    plot.background = element_rect(fill = "transparent", colour = NA),
    plot.margin = margin(1.5, 1.5, 1.5, 1.5, unit = "mm"))

Figure_4_gg <- cowplot::ggdraw() +
  cowplot::draw_plot(county_sens_change_sum_gg,
                     x = 0, y = 0, width = 0.525, height = 1) +
  cowplot::draw_plot(sensity_change_sp_gg,
                     x = 0.525, y = 0, width = 0.475, height = 1)
# Six output formats.
export_six(Figure_4_gg, "Figure_4", 14.6, 9)

